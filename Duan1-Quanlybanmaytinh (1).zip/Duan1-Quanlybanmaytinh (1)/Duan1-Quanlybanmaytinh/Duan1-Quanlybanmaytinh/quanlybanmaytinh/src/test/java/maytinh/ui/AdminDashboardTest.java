package maytinh.ui;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;
import java.sql.Date;
import java.time.LocalDate;

/**
 * Test class cho manhinhchinhadmin - Kiểm tra tính chính xác của doanh thu và biểu đồ
 * @author Cong Nam
 */
public class AdminDashboardTest {
    
    private manhinhchinhadmin adminDashboard;
    
    @BeforeEach
    void setUp() {
        // Khởi tạo đối tượng test (không hiển thị giao diện)
        adminDashboard = new manhinhchinhadmin(null, false);
    }
    
    @Test
    @DisplayName("Test tính toán doanh thu theo khoảng thời gian")
    void testTinhTongDoanhThu() {
        // Arrange
        LocalDate today = LocalDate.now();
        LocalDate startOfMonth = today.withDayOfMonth(1);
        Date tuNgay = Date.valueOf(startOfMonth);
        Date denNgay = Date.valueOf(today);
        
        // Act
        double doanhThu = adminDashboard.tinhTongDoanhThu(tuNgay, denNgay);
        
        // Assert
        assertTrue(doanhThu >= 0, "Doanh thu không được âm");
        System.out.println("✅ Test doanh thu tháng này: " + String.format("%,.0f VNĐ", doanhThu));
    }
    
    @Test
    @DisplayName("Test tính số lượng đơn hàng theo khoảng thời gian")
    void testTinhTongSoDonHang() {
        // Arrange
        LocalDate today = LocalDate.now();
        LocalDate startOfMonth = today.withDayOfMonth(1);
        Date tuNgay = Date.valueOf(startOfMonth);
        Date denNgay = Date.valueOf(today);
        
        // Act
        int soDonHang = adminDashboard.tinhTongSoDonHang(tuNgay, denNgay);
        
        // Assert
        assertTrue(soDonHang >= 0, "Số đơn hàng không được âm");
        System.out.println("✅ Test số đơn hàng tháng này: " + soDonHang);
    }
    
    @Test
    @DisplayName("Test doanh thu hôm nay")
    void testDoanhThuHomNay() {
        // Arrange
        LocalDate today = LocalDate.now();
        Date homNay = Date.valueOf(today);
        
        // Act
        double doanhThuHomNay = adminDashboard.tinhTongDoanhThu(homNay, homNay);
        int donHangHomNay = adminDashboard.tinhTongSoDonHang(homNay, homNay);
        
        // Assert
        assertTrue(doanhThuHomNay >= 0, "Doanh thu hôm nay không được âm");
        assertTrue(donHangHomNay >= 0, "Số đơn hàng hôm nay không được âm");
        
        System.out.println("✅ Test hôm nay (" + today + "):");
        System.out.println("   - Doanh thu: " + String.format("%,.0f VNĐ", doanhThuHomNay));
        System.out.println("   - Đơn hàng: " + donHangHomNay);
    }
    
    @Test
    @DisplayName("Test tính nhất quán dữ liệu")
    void testTinhNhatQuanDuLieu() {
        // Arrange
        LocalDate today = LocalDate.now();
        LocalDate startOfYear = today.withDayOfYear(1);
        Date tuNgay = Date.valueOf(startOfYear);
        Date denNgay = Date.valueOf(today);
        
        // Act
        double doanhThuNam = adminDashboard.tinhTongDoanhThu(tuNgay, denNgay);
        int donHangNam = adminDashboard.tinhTongSoDonHang(tuNgay, denNgay);
        
        // Assert
        if (donHangNam > 0) {
            assertTrue(doanhThuNam > 0, "Nếu có đơn hàng thì phải có doanh thu");
            double doanhThuTrungBinh = doanhThuNam / donHangNam;
            assertTrue(doanhThuTrungBinh > 0, "Doanh thu trung bình mỗi đơn hàng phải > 0");
            
            System.out.println("✅ Test tính nhất quán dữ liệu năm " + today.getYear() + ":");
            System.out.println("   - Tổng doanh thu: " + String.format("%,.0f VNĐ", doanhThuNam));
            System.out.println("   - Tổng đơn hàng: " + donHangNam);
            System.out.println("   - Doanh thu TB/đơn: " + String.format("%,.0f VNĐ", doanhThuTrungBinh));
        } else {
            System.out.println("⚠️ Chưa có đơn hàng nào trong năm " + today.getYear());
        }
    }
    
    @Test
    @DisplayName("Test hiển thị biểu đồ không bị lỗi")
    void testHienThiBieuDo() {
        // Act & Assert - Chỉ kiểm tra không bị exception
        assertDoesNotThrow(() -> {
            adminDashboard.hienThiBieuDoBanChay();
            System.out.println("✅ Test hiển thị biểu đồ top sản phẩm: OK");
        }, "Hiển thị biểu đồ top sản phẩm không được gây lỗi");
        
        assertDoesNotThrow(() -> {
            LocalDate today = LocalDate.now();
            Date homNay = Date.valueOf(today);
            adminDashboard.hienThiBieuDoPieTheoNgay(homNay, homNay);
            System.out.println("✅ Test hiển thị biểu đồ pie doanh thu: OK");
        }, "Hiển thị biểu đồ pie doanh thu không được gây lỗi");
    }
}
