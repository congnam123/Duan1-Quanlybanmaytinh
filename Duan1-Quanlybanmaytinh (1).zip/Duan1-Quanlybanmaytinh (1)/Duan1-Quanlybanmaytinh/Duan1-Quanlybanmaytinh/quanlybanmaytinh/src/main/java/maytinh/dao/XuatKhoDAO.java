package maytinh.dao;

import maytinh.entity.XuatKho;
import java.util.List;
import java.util.Date;

/**
 * DAO interface cho XuatKho
 * @author Cong Nam
 */
public interface XuatKhoDAO extends CrudDao<XuatKho, String> {
    
    /**
     * Tìm phiếu xuất theo mã kho
     * @param maKho Mã kho
     * @return List<XuatKho>
     */
    List<XuatKho> findByMaKho(String maKho);
    
    /**
     * Tìm phiếu xuất theo mã sản phẩm
     * @param maSanPham Mã sản phẩm
     * @return List<XuatKho>
     */
    List<XuatKho> findByMaSanPham(String maSanPham);
    
    /**
     * Tìm phiếu xuất theo trạng thái
     * @param trangThai Trạng thái
     * @return List<XuatKho>
     */
    List<XuatKho> findByTrangThai(String trangThai);
    
    /**
     * Tìm phiếu xuất theo người xuất
     * @param nguoiXuat Người xuất
     * @return List<XuatKho>
     */
    List<XuatKho> findByNguoiXuat(String nguoiXuat);
    
    /**
     * Tìm phiếu xuất theo khách hàng
     * @param khachHang Khách hàng
     * @return List<XuatKho>
     */
    List<XuatKho> findByKhachHang(String khachHang);
    
    /**
     * Tìm phiếu xuất theo lý do xuất
     * @param lyDoXuat Lý do xuất
     * @return List<XuatKho>
     */
    List<XuatKho> findByLyDoXuat(String lyDoXuat);
    
    /**
     * Tìm phiếu xuất theo khoảng thời gian
     * @param tuNgay Từ ngày
     * @param denNgay Đến ngày
     * @return List<XuatKho>
     */
    List<XuatKho> findByDateRange(Date tuNgay, Date denNgay);
    
    /**
     * Tìm kiếm phiếu xuất theo từ khóa
     * @param keyword Từ khóa
     * @return List<XuatKho>
     */
    List<XuatKho> search(String keyword);
    
    /**
     * Cập nhật trạng thái phiếu xuất
     * @param maPhieuXuat Mã phiếu xuất
     * @param trangThai Trạng thái mới
     */
    void updateTrangThai(String maPhieuXuat, String trangThai);
    
    /**
     * Lấy danh sách phiếu xuất theo phân trang
     * @param page Trang (bắt đầu từ 0)
     * @param size Số lượng bản ghi mỗi trang
     * @return List<XuatKho>
     */
    List<XuatKho> findByPage(int page, int size);
    
    /**
     * Đếm tổng số phiếu xuất
     * @return Số lượng phiếu xuất
     */
    long count();
    
    /**
     * Đếm số phiếu xuất theo trạng thái
     * @param trangThai Trạng thái
     * @return Số lượng phiếu xuất
     */
    long countByTrangThai(String trangThai);
    
    /**
     * Kiểm tra mã phiếu xuất có tồn tại không
     * @param maPhieuXuat Mã phiếu xuất
     * @return true nếu tồn tại
     */
    boolean existsByMaPhieuXuat(String maPhieuXuat);
    
    /**
     * Lấy tổng số lượng xuất theo sản phẩm
     * @param maSanPham Mã sản phẩm
     * @return Tổng số lượng xuất
     */
    int getTongSoLuongXuatBySanPham(String maSanPham);
    
    /**
     * Lấy tổng giá trị xuất theo kho
     * @param maKho Mã kho
     * @return Tổng giá trị xuất
     */
    double getTongGiaTriXuatByKho(String maKho);
}
