package maytinh.impl;

import maytinh.dao.TonKhoDAO;
import maytinh.entity.TonKho;
import maytinh.util.XJdbc;
import maytinh.util.XQuery;
import java.util.List;

/**
 * Implementation của TonKhoDAO
 */
public class TonKhoDAOImpl implements TonKhoDAO {

    @Override
    public TonKho create(TonKho entity) {
        String sql = "INSERT INTO TonKho (MaKho, MaSanPham, TenSanPham, SoLuongTon, SoLuongNhap, SoLuongXuat, GiaTriTon, DonGiaTrungBinh, TrangThai) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        XJdbc.executeUpdate(sql, 
            entity.getMaKho(),
            entity.getMaSanPham(),
            entity.getTenSanPham(),
            entity.getSoLuongTon(),
            entity.getSoLuongNhap(),
            entity.getSoLuongXuat(),
            entity.getGiaTriTon(),
            entity.getDonGiaTrungBinh(),
            entity.getTrangThai()
        );
        return entity;
    }

    @Override
    public void update(TonKho entity) {
        String sql = "UPDATE TonKho SET TenSanPham=?, SoLuongTon=?, SoLuongNhap=?, SoLuongXuat=?, GiaTriTon=?, DonGiaTrungBinh=?, TrangThai=?, NgayCapNhat=GETDATE() WHERE MaKho=? AND MaSanPham=?";
        XJdbc.executeUpdate(sql,
            entity.getTenSanPham(),
            entity.getSoLuongTon(),
            entity.getSoLuongNhap(),
            entity.getSoLuongXuat(),
            entity.getGiaTriTon(),
            entity.getDonGiaTrungBinh(),
            entity.getTrangThai(),
            entity.getMaKho(),
            entity.getMaSanPham()
        );
    }

    @Override
    public void deleteById(String id) {
        // TonKho có composite key, cần override phương thức này
        throw new UnsupportedOperationException("Sử dụng deleteByKhoAndSanPham thay thế");
    }
    
    public void deleteByKhoAndSanPham(String maKho, String maSanPham) {
        String sql = "DELETE FROM TonKho WHERE MaKho=? AND MaSanPham=?";
        XJdbc.executeUpdate(sql, maKho, maSanPham);
    }

    @Override
    public TonKho findById(String id) {
        // TonKho có composite key, cần override phương thức này
        throw new UnsupportedOperationException("Sử dụng findByKhoAndSanPham thay thế");
    }

    @Override
    public List<TonKho> findAll() {
        String sql = "SELECT * FROM TonKho ORDER BY MaKho, MaSanPham";
        return XQuery.getBeanList(TonKho.class, sql);
    }

    @Override
    public TonKho findByKhoAndSanPham(String maKho, String maSanPham) {
        String sql = "SELECT * FROM TonKho WHERE MaKho=? AND MaSanPham=?";
        return XQuery.getSingleBean(TonKho.class, sql, maKho, maSanPham);
    }

    @Override
    public List<TonKho> findByKho(String maKho) {
        String sql = "SELECT * FROM TonKho WHERE MaKho=? ORDER BY MaSanPham";
        return XQuery.getBeanList(TonKho.class, sql, maKho);
    }

    @Override
    public List<TonKho> findBySanPham(String maSanPham) {
        String sql = "SELECT * FROM TonKho WHERE MaSanPham=? ORDER BY MaKho";
        return XQuery.getBeanList(TonKho.class, sql, maSanPham);
    }

    @Override
    public List<TonKho> findByTrangThai(String trangThai) {
        String sql = "SELECT * FROM TonKho WHERE TrangThai=? ORDER BY MaKho, MaSanPham";
        return XQuery.getBeanList(TonKho.class, sql, trangThai);
    }

    @Override
    public void updateSoLuongTon(String maKho, String maSanPham, int soLuongMoi) {
        String sql = "UPDATE TonKho SET SoLuongTon=?, NgayCapNhat=GETDATE() WHERE MaKho=? AND MaSanPham=?";
        XJdbc.executeUpdate(sql, soLuongMoi, maKho, maSanPham);
    }

    @Override
    public List<TonKho> search(String keyword) {
        String sql = "SELECT * FROM TonKho WHERE MaKho LIKE ? OR MaSanPham LIKE ? OR TenSanPham LIKE ? ORDER BY MaKho, MaSanPham";
        String pattern = "%" + keyword + "%";
        return XQuery.getBeanList(TonKho.class, sql, pattern, pattern, pattern);
    }
}
