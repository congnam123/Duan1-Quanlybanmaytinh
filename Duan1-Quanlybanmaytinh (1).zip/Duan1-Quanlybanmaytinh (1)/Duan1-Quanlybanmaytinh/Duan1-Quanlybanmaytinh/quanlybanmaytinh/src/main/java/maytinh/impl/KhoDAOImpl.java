package maytinh.impl;

import maytinh.dao.KhoDAO;
import maytinh.entity.Kho;
import maytinh.util.XJdbc;
import maytinh.util.XQuery;
import java.util.List;

/**
 * Implementation của KhoDAO
 * @author Cong Nam
 */
public class KhoDAOImpl implements KhoDAO {
    
    // SQL Statements
    private final String INSERT_SQL = "INSERT INTO Kho (MaKho, TenKho, DiaChi, NguoiQuanLy, SoDienThoai, Email, MoTa, NgayTao, NgayCapNhat, TrangThai, TongSanPham, TongGiaTri) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private final String UPDATE_SQL = "UPDATE Kho SET TenKho=?, DiaChi=?, NguoiQuanLy=?, SoDienThoai=?, Email=?, MoTa=?, NgayCapNhat=?, TrangThai=?, TongSanPham=?, TongGiaTri=? WHERE MaKho=?";
    
    private final String DELETE_SQL = "DELETE FROM Kho WHERE MaKho=?";
    
    private final String SELECT_ALL_SQL = "SELECT * FROM Kho ORDER BY NgayCapNhat DESC";
    
    private final String SELECT_BY_ID_SQL = "SELECT * FROM Kho WHERE MaKho=?";
    
    private final String SELECT_BY_TEN_SQL = "SELECT * FROM Kho WHERE TenKho LIKE ?";
    
    private final String SELECT_BY_NGUOI_QUAN_LY_SQL = "SELECT * FROM Kho WHERE NguoiQuanLy LIKE ?";
    
    private final String SELECT_BY_TRANG_THAI_SQL = "SELECT * FROM Kho WHERE TrangThai=?";
    
    private final String SELECT_BY_DIA_CHI_SQL = "SELECT * FROM Kho WHERE DiaChi LIKE ?";
    
    private final String SELECT_ACTIVE_SQL = "SELECT * FROM Kho WHERE TrangThai=1 ORDER BY TenKho";
    
    private final String SEARCH_SQL = "SELECT * FROM Kho WHERE TenKho LIKE ? OR DiaChi LIKE ? OR NguoiQuanLy LIKE ? OR MoTa LIKE ?";
    
    private final String UPDATE_TONG_SAN_PHAM_SQL = "UPDATE Kho SET TongSanPham=?, NgayCapNhat=GETDATE() WHERE MaKho=?";
    
    private final String UPDATE_TONG_GIA_TRI_SQL = "UPDATE Kho SET TongGiaTri=?, NgayCapNhat=GETDATE() WHERE MaKho=?";
    
    private final String UPDATE_TRANG_THAI_SQL = "UPDATE Kho SET TrangThai=?, NgayCapNhat=GETDATE() WHERE MaKho=?";
    
    private final String EXISTS_BY_MA_SQL = "SELECT COUNT(*) FROM Kho WHERE MaKho=?";
    
    private final String COUNT_SQL = "SELECT COUNT(*) FROM Kho";
    
    private final String COUNT_BY_TRANG_THAI_SQL = "SELECT COUNT(*) FROM Kho WHERE TrangThai=?";
    
    private final String SELECT_BY_PAGE_SQL = "SELECT * FROM Kho ORDER BY NgayCapNhat DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";

    @Override
    public Kho create(Kho kho) {
        Object[] values = {
            kho.getMaKho(),
            kho.getTenKho(),
            kho.getDiaChi(),
            kho.getNguoiQuanLy(),
            kho.getSoDienThoai(),
            kho.getEmail(),
            kho.getMoTa(),
            kho.getNgayTao(),
            kho.getNgayCapNhat(),
            kho.isTrangThai(),
            kho.getTongSanPham(),
            kho.getTongGiaTri()
        };
        XJdbc.executeUpdate(INSERT_SQL, values);
        return kho;
    }

    @Override
    public void update(Kho kho) {
        kho.setNgayCapNhat(new java.util.Date());
        Object[] values = {
            kho.getTenKho(),
            kho.getDiaChi(),
            kho.getNguoiQuanLy(),
            kho.getSoDienThoai(),
            kho.getEmail(),
            kho.getMoTa(),
            kho.getNgayCapNhat(),
            kho.isTrangThai(),
            kho.getTongSanPham(),
            kho.getTongGiaTri(),
            kho.getMaKho()
        };
        XJdbc.executeUpdate(UPDATE_SQL, values);
    }

    @Override
    public void deleteById(String maKho) {
        XJdbc.executeUpdate(DELETE_SQL, maKho);
    }

    @Override
    public List<Kho> findAll() {
        return XQuery.getBeanList(Kho.class, SELECT_ALL_SQL);
    }

    @Override
    public Kho findById(String maKho) {
        return XQuery.getSingleBean(Kho.class, SELECT_BY_ID_SQL, maKho);
    }

    @Override
    public List<Kho> findByTenKho(String tenKho) {
        return XQuery.getBeanList(Kho.class, SELECT_BY_TEN_SQL, "%" + tenKho + "%");
    }

    @Override
    public List<Kho> findByNguoiQuanLy(String nguoiQuanLy) {
        return XQuery.getBeanList(Kho.class, SELECT_BY_NGUOI_QUAN_LY_SQL, "%" + nguoiQuanLy + "%");
    }

    @Override
    public List<Kho> findByTrangThai(boolean trangThai) {
        return XQuery.getBeanList(Kho.class, SELECT_BY_TRANG_THAI_SQL, trangThai);
    }

    @Override
    public List<Kho> findByDiaChi(String diaChi) {
        return XQuery.getBeanList(Kho.class, SELECT_BY_DIA_CHI_SQL, "%" + diaChi + "%");
    }

    @Override
    public List<Kho> findActiveKho() {
        return XQuery.getBeanList(Kho.class, SELECT_ACTIVE_SQL);
    }

    @Override
    public List<Kho> search(String keyword) {
        String searchPattern = "%" + keyword + "%";
        return XQuery.getBeanList(Kho.class, SEARCH_SQL, 
            searchPattern, searchPattern, searchPattern, searchPattern);
    }

    @Override
    public void updateTongSanPham(String maKho, int tongSanPham) {
        XJdbc.executeUpdate(UPDATE_TONG_SAN_PHAM_SQL, tongSanPham, maKho);
    }

    @Override
    public void updateTongGiaTri(String maKho, double tongGiaTri) {
        XJdbc.executeUpdate(UPDATE_TONG_GIA_TRI_SQL, tongGiaTri, maKho);
    }

    @Override
    public void updateTrangThai(String maKho, boolean trangThai) {
        XJdbc.executeUpdate(UPDATE_TRANG_THAI_SQL, trangThai, maKho);
    }

    @Override
    public boolean existsByMaKho(String maKho) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(EXISTS_BY_MA_SQL, maKho);
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public long count() {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_SQL);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public long countByTrangThai(boolean trangThai) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_BY_TRANG_THAI_SQL, trangThai);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public List<Kho> findByPage(int page, int size) {
        int offset = page * size;
        return XQuery.getBeanList(Kho.class, SELECT_BY_PAGE_SQL, offset, size);
    }
}
