package maytinh.dao;

import maytinh.entity.NhapKho;
import java.util.List;
import java.util.Date;

/**
 * DAO interface cho NhapKho
 * @author Cong Nam
 */
public interface NhapKhoDAO extends CrudDao<NhapKho, String> {
    
    /**
     * Tìm phiếu nhập theo mã kho
     * @param maKho Mã kho
     * @return List<NhapKho>
     */
    List<NhapKho> findByMaKho(String maKho);
    
    /**
     * Tìm phiếu nhập theo mã sản phẩm
     * @param maSanPham Mã sản phẩm
     * @return List<NhapKho>
     */
    List<NhapKho> findByMaSanPham(String maSanPham);
    
    /**
     * Tìm phiếu nhập theo trạng thái
     * @param trangThai Trạng thái
     * @return List<NhapKho>
     */
    List<NhapKho> findByTrangThai(String trangThai);
    
    /**
     * Tìm phiếu nhập theo người nhập
     * @param nguoiNhap Người nhập
     * @return List<NhapKho>
     */
    List<NhapKho> findByNguoiNhap(String nguoiNhap);
    
    /**
     * Tìm phiếu nhập theo nhà cung cấp
     * @param nhaCungCap Nhà cung cấp
     * @return List<NhapKho>
     */
    List<NhapKho> findByNhaCungCap(String nhaCungCap);
    
    /**
     * Tìm phiếu nhập theo khoảng thời gian
     * @param tuNgay Từ ngày
     * @param denNgay Đến ngày
     * @return List<NhapKho>
     */
    List<NhapKho> findByDateRange(Date tuNgay, Date denNgay);
    
    /**
     * Tìm kiếm phiếu nhập theo từ khóa
     * @param keyword Từ khóa
     * @return List<NhapKho>
     */
    List<NhapKho> search(String keyword);
    
    /**
     * Cập nhật trạng thái phiếu nhập
     * @param maPhieuNhap Mã phiếu nhập
     * @param trangThai Trạng thái mới
     */
    void updateTrangThai(String maPhieuNhap, String trangThai);
    
    /**
     * Lấy danh sách phiếu nhập theo phân trang
     * @param page Trang (bắt đầu từ 0)
     * @param size Số lượng bản ghi mỗi trang
     * @return List<NhapKho>
     */
    List<NhapKho> findByPage(int page, int size);
    
    /**
     * Đếm tổng số phiếu nhập
     * @return Số lượng phiếu nhập
     */
    long count();
    
    /**
     * Đếm số phiếu nhập theo trạng thái
     * @param trangThai Trạng thái
     * @return Số lượng phiếu nhập
     */
    long countByTrangThai(String trangThai);
    
    /**
     * Kiểm tra mã phiếu nhập có tồn tại không
     * @param maPhieuNhap Mã phiếu nhập
     * @return true nếu tồn tại
     */
    boolean existsByMaPhieuNhap(String maPhieuNhap);
    
    /**
     * Lấy tổng số lượng nhập theo sản phẩm
     * @param maSanPham Mã sản phẩm
     * @return Tổng số lượng nhập
     */
    int getTongSoLuongNhapBySanPham(String maSanPham);
    
    /**
     * Lấy tổng giá trị nhập theo kho
     * @param maKho Mã kho
     * @return Tổng giá trị nhập
     */
    double getTongGiaTriNhapByKho(String maKho);
}
