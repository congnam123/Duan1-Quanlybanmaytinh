package maytinh.dao;

import maytinh.entity.Kho;
import java.util.List;

/**
 * DAO interface cho Kho
 * @author Cong Nam
 */
public interface KhoDAO extends CrudDao<Kho, String> {
    
    /**
     * Tìm kho theo tên
     * @param tenKho Tên kho cần tìm
     * @return List<Kho>
     */
    List<Kho> findByTenKho(String tenKho);
    
    /**
     * Tìm kho theo người quản lý
     * @param nguoiQuanLy Tên người quản lý
     * @return List<Kho>
     */
    List<Kho> findByNguoiQuanLy(String nguoiQuanLy);
    
    /**
     * Tìm kho theo trạng thái
     * @param trangThai Trạng thái kho (true: hoạt động, false: ngừng hoạt động)
     * @return List<Kho>
     */
    List<Kho> findByTrangThai(boolean trangThai);
    
    /**
     * Tìm kho theo địa chỉ
     * @param diaChi Địa chỉ kho
     * @return List<Kho>
     */
    List<Kho> findByDiaChi(String diaChi);
    
    /**
     * Lấy danh sách kho đang hoạt động
     * @return List<Kho>
     */
    List<Kho> findActiveKho();
    
    /**
     * Tìm kiếm kho theo từ khóa
     * @param keyword Từ khóa tìm kiếm
     * @return List<Kho>
     */
    List<Kho> search(String keyword);
    
    /**
     * Cập nhật tổng số sản phẩm trong kho
     * @param maKho Mã kho
     * @param tongSanPham Tổng số sản phẩm
     */
    void updateTongSanPham(String maKho, int tongSanPham);
    
    /**
     * Cập nhật tổng giá trị hàng hóa trong kho
     * @param maKho Mã kho
     * @param tongGiaTri Tổng giá trị
     */
    void updateTongGiaTri(String maKho, double tongGiaTri);
    
    /**
     * Cập nhật trạng thái kho
     * @param maKho Mã kho
     * @param trangThai Trạng thái mới
     */
    void updateTrangThai(String maKho, boolean trangThai);
    
    /**
     * Kiểm tra mã kho có tồn tại không
     * @param maKho Mã kho cần kiểm tra
     * @return true nếu tồn tại
     */
    boolean existsByMaKho(String maKho);
    
    /**
     * Đếm tổng số kho
     * @return Số lượng kho
     */
    long count();
    
    /**
     * Đếm số kho theo trạng thái
     * @param trangThai Trạng thái
     * @return Số lượng kho
     */
    long countByTrangThai(boolean trangThai);
    
    /**
     * Lấy danh sách kho theo phân trang
     * @param page Trang (bắt đầu từ 0)
     * @param size Số lượng bản ghi mỗi trang
     * @return List<Kho>
     */
    List<Kho> findByPage(int page, int size);
}
