package maytinh.dao;

import maytinh.entity.LoaiSanPham;
import java.util.List;

/**
 * DAO interface cho Loại sản phẩm
 * @author Admin
 */
public interface LoaiSanPhamDAO {
    
    /**
     * Lấy tất cả loại sản phẩm
     * @return List<LoaiSanPham>
     */
    List<LoaiSanPham> getAllLoaiSanPham();
    
    /**
     * Lấy loại sản phẩm theo mã
     * @param maLoai Mã loại
     * @return LoaiSanPham hoặc null
     */
    LoaiSanPham getLoaiSanPhamById(int maLoai);
    
    /**
     * Thêm loại sản phẩm mới
     * @param loaiSP Loại sản phẩm cần thêm
     * @return true nếu thành công
     */
    boolean themLoaiSanPham(LoaiSanPham loaiSP);
    
    /**
     * Cập nhật loại sản phẩm
     * @param loaiSP Loại sản phẩm cần cập nhật
     * @return true nếu thành công
     */
    boolean capNhatLoaiSanPham(LoaiSanPham loaiSP);
    
    /**
     * Xóa loại sản phẩm
     * @param maLoai Mã loại cần xóa
     * @return true nếu thành công
     */
    boolean xoaLoaiSanPham(int maLoai);
    
    /**
     * Tìm kiếm loại sản phẩm theo tên
     * @param tenLoai Tên loại cần tìm
     * @return List<LoaiSanPham>
     */
    List<LoaiSanPham> timKiemLoaiSanPham(String tenLoai);
    
    /**
     * Kiểm tra loại sản phẩm có đang được sử dụng không
     * @param maLoai Mã loại
     * @return true nếu đang được sử dụng
     */
    boolean kiemTraLoaiDangSuDung(int maLoai);
}
