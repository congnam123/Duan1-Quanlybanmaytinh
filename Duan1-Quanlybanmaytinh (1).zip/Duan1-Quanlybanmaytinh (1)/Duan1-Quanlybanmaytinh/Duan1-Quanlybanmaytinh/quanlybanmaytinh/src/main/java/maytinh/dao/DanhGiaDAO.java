package maytinh.dao;

import maytinh.entity.DanhGia;
import java.util.List;

/**
 * DAO Interface cho DanhGia
 * @author Admin
 */
public interface DanhGiaDAO {

    /**
     * Thêm đánh giá mới
     */
    DanhGia insert(DanhGia danhGia);

    /**
     * Cập nhật đánh giá
     */
    DanhGia update(DanhGia danhGia);

    /**
     * Xóa đánh giá theo mã
     */
    boolean delete(int maDG);

    /**
     * Tìm đánh giá theo mã
     */
    DanhGia selectById(int maDG);

    /**
     * Lấy tất cả đánh giá
     */
    List<DanhGia> selectAll();

    /**
     * Lấy đánh giá theo username
     */
    List<DanhGia> selectByUsername(String username);

    /**
     * Lấy đánh giá theo mã sản phẩm
     */
    List<DanhGia> selectByProductId(int maSP);

    /**
     * Kiểm tra user đã đánh giá sản phẩm chưa
     */
    boolean hasReviewed(String username, int maSP);

    /**
     * Cập nhật trả lời cho đánh giá
     */
    boolean updateReply(int maDG, String traLoi);

    /**
     * Lấy tất cả đánh giá (cho admin)
     */
    List<DanhGia> getAll();

    /**
     * Tìm kiếm đánh giá theo từ khóa
     */
    List<DanhGia> searchByKeyword(String keyword);

    /**
     * Trả lời đánh giá (cho admin)
     */
    boolean traLoiDanhGia(int maDG, String traLoi);

    /**
     * Lấy đánh giá theo username với thông tin sản phẩm (JOIN)
     * @param username Tên đăng nhập
     * @return Danh sách đánh giá có kèm tên sản phẩm
     */
    List<DanhGia> selectByUsernameWithProductInfo(String username);
}
