package maytinh.impl;

import java.sql.*;
import java.util.*;
import maytinh.dao.LichSuDAO;
import maytinh.entity.LichSu1;
import maytinh.util.XJdbc;

public class LichSuDAOImpl implements LichSuDAO {

    @Override
    public LichSu1 create(LichSu1 entity) {
        String sql = "INSERT INTO LichSu (MaDonHang, TenSanPham, SoLuong, DonGia, TrangThai, NgayMua, Username) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, entity.getMaDonHang());
            ps.setString(2, entity.getTenSanPham());
            ps.setInt(3, entity.getSoLuong());
            ps.setDouble(4, entity.getDonGia());
            ps.setString(5, entity.getTrangThai());
            ps.setTimestamp(6, new Timestamp(entity.getNgayMua().getTime()));
            ps.setString(7, entity.getUsername());

            int affectedRows = ps.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        entity.setMaDH(generatedKeys.getInt(1));
                    }
                }
            }
            return entity;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public void update(LichSu1 entity) {
        String sql = "UPDATE LichSu SET MaDonHang=?, TenSanPham=?, SoLuong=?, DonGia=?, TrangThai=?, NgayMua=?, Username=? WHERE MaDH=?";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, entity.getMaDonHang());
            ps.setString(2, entity.getTenSanPham());
            ps.setInt(3, entity.getSoLuong());
            ps.setDouble(4, entity.getDonGia());
            ps.setString(5, entity.getTrangThai());
            ps.setTimestamp(6, new Timestamp(entity.getNgayMua().getTime()));
            ps.setString(7, entity.getUsername());
            ps.setInt(8, entity.getMaDH());

            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteById(Integer id) {
        String sql = "DELETE FROM LichSu WHERE MaDH=?";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<LichSu1> findAll() {
        List<LichSu1> list = new ArrayList<>();
        String sql = "SELECT * FROM LichSu ORDER BY NgayMua DESC";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(createLichSuFromResultSet(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public LichSu1 findById(Integer id) {
        String sql = "SELECT * FROM LichSu WHERE MaDH=?";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return createLichSuFromResultSet(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<LichSu1> selectByUsername(String username) {
        List<LichSu1> list = new ArrayList<>();
        String sql = "SELECT * FROM LichSu WHERE Username=? ORDER BY NgayMua DESC";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(createLichSuFromResultSet(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<LichSu1> getLichSuByUsername(String username) {
        return selectByUsername(username); // Delegate to selectByUsername
    }

    private LichSu1 createLichSuFromResultSet(ResultSet rs) throws SQLException {
        LichSu1 ls = new LichSu1();
        ls.setMaDH(rs.getInt("MaDH"));
        ls.setMaDonHang(rs.getString("MaDonHang"));
        ls.setTenSanPham(rs.getString("TenSanPham"));
        ls.setSoLuong(rs.getInt("SoLuong"));
        ls.setDonGia(rs.getDouble("DonGia"));
        ls.setTrangThai(rs.getString("TrangThai"));
        ls.setNgayMua(rs.getTimestamp("NgayMua"));
        ls.setUsername(rs.getString("Username"));
        return ls;
    }

    @Override
    public List<LichSu1> searchByDateRange(String username, String from, String to) {
        List<LichSu1> list = new ArrayList<>();

        // 🔧 SỬA: Sử dụng CAST để so sánh ngày chính xác
        String sql = "SELECT * FROM LichSu WHERE Username = ? " +
                    "AND CAST(NgayMua AS DATE) BETWEEN CAST(? AS DATE) AND CAST(? AS DATE) " +
                    "ORDER BY NgayMua DESC";

        System.out.println("🔍 DEBUG LichSuDAO.searchByDateRange:");
        System.out.println("   - SQL: " + sql);
        System.out.println("   - Username: " + username);
        System.out.println("   - From: " + from);
        System.out.println("   - To: " + to);

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, from);
            ps.setString(3, to);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    LichSu1 ls = createLichSuFromResultSet(rs);
                    list.add(ls);
                    System.out.println("   - Tìm thấy: " + ls.getMaDonHang() + " - " + ls.getTenSanPham() + " - " + ls.getNgayMua());
                }
            }

            System.out.println("   - Tổng kết quả: " + list.size());

        } catch (Exception e) {
            System.err.println("❌ Lỗi trong LichSuDAO.searchByDateRange: " + e.getMessage());
            e.printStackTrace();
        }

        return list;
    }

    @Override
    public void deleteLichSuByUsername(String username) {
        String sql = "DELETE FROM LichSu WHERE Username = ?";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<LichSu1> searchByKeyword(String keyword) {
        List<LichSu1> list = new ArrayList<>();
        String sql = "SELECT * FROM LichSu WHERE MaDonHang LIKE ? OR TenSanPham LIKE ? OR Username LIKE ? ORDER BY NgayMua DESC";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String searchPattern = "%" + keyword + "%";
            ps.setString(1, searchPattern);
            ps.setString(2, searchPattern);
            ps.setString(3, searchPattern);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(createLichSuFromResultSet(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<LichSu1> selectByStatus(String status) {
        List<LichSu1> list = new ArrayList<>();
        String sql = "SELECT * FROM LichSu WHERE TrangThai = ? ORDER BY NgayMua DESC";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(createLichSuFromResultSet(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<LichSu1> selectByMaDonHang(String maDonHang) {
        List<LichSu1> list = new ArrayList<>();
        String sql = "SELECT * FROM LichSu WHERE MaDonHang = ? ORDER BY NgayMua DESC";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maDonHang);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(createLichSuFromResultSet(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public LichSu1 findByMaDonHang(String maDonHang) {
        String sql = "SELECT TOP 1 * FROM LichSu WHERE MaDonHang = ?";
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maDonHang);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return createLichSuFromResultSet(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Lỗi findByMaDonHang: " + e.getMessage());
        }
        return null;
    }

    @Override
    public List<LichSu1> findAllByMaDonHang(String maDonHang) {
        List<LichSu1> list = new ArrayList<>();
        String sql = "SELECT * FROM LichSu WHERE MaDonHang = ? ORDER BY NgayMua DESC";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, maDonHang);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(createLichSuFromResultSet(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Lỗi findAllByMaDonHang: " + e.getMessage());
        }
        return list;
    }
}
