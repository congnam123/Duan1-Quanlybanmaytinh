package maytinh.impl;

import maytinh.dao.LoaiSanPhamDAO;
import maytinh.entity.LoaiSanPham;
import maytinh.util.XJdbc;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation của LoaiSanPhamDAO
 * @author Admin
 */
public class LoaiSanPhamDAOImpl implements LoaiSanPhamDAO {
    
    @Override
    public List<LoaiSanPham> getAllLoaiSanPham() {
        List<LoaiSanPham> list = new ArrayList<>();
        // Sửa: Bỏ điều kiện TrangThai nếu cột không tồn tại
        String sql = "SELECT MaLoai, TenLoai, MoTa FROM LoaiSanPham ORDER BY TenLoai";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                LoaiSanPham loai = new LoaiSanPham();
                loai.setMaLoai(rs.getInt("MaLoai"));
                loai.setTenLoai(rs.getString("TenLoai"));
                // Kiểm tra xem có cột MoTa không
                try {
                    loai.setMoTa(rs.getString("MoTa"));
                } catch (Exception e) {
                    loai.setMoTa(""); // Mặc định nếu không có cột MoTa
                }
                loai.setTrangThai(true); // Mặc định true
                list.add(loai);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    @Override
    public LoaiSanPham getLoaiSanPhamById(int maLoai) {
        String sql = "SELECT * FROM LoaiSanPham WHERE MaLoai = ?";
        
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, maLoai);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                LoaiSanPham loai = new LoaiSanPham();
                loai.setMaLoai(rs.getInt("MaLoai"));
                loai.setTenLoai(rs.getString("TenLoai"));
                loai.setMoTa(rs.getString("MoTa"));
                loai.setTrangThai(rs.getBoolean("TrangThai"));
                return loai;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    @Override
    public boolean themLoaiSanPham(LoaiSanPham loaiSP) {
        String sql = "INSERT INTO LoaiSanPham (TenLoai, MoTa, TrangThai) VALUES (?, ?, ?)";
        
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, loaiSP.getTenLoai());
            ps.setString(2, loaiSP.getMoTa());
            ps.setBoolean(3, loaiSP.isTrangThai());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean capNhatLoaiSanPham(LoaiSanPham loaiSP) {
        String sql = "UPDATE LoaiSanPham SET TenLoai = ?, MoTa = ?, TrangThai = ? WHERE MaLoai = ?";
        
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, loaiSP.getTenLoai());
            ps.setString(2, loaiSP.getMoTa());
            ps.setBoolean(3, loaiSP.isTrangThai());
            ps.setInt(4, loaiSP.getMaLoai());
            
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public boolean xoaLoaiSanPham(int maLoai) {
        // Soft delete - chỉ cập nhật trạng thái
        String sql = "UPDATE LoaiSanPham SET TrangThai = 0 WHERE MaLoai = ?";
        
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, maLoai);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
    
    @Override
    public List<LoaiSanPham> timKiemLoaiSanPham(String tenLoai) {
        List<LoaiSanPham> list = new ArrayList<>();
        String sql = "SELECT * FROM LoaiSanPham WHERE TenLoai LIKE ? AND TrangThai = 1 ORDER BY TenLoai";
        
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, "%" + tenLoai + "%");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                LoaiSanPham loai = new LoaiSanPham();
                loai.setMaLoai(rs.getInt("MaLoai"));
                loai.setTenLoai(rs.getString("TenLoai"));
                loai.setMoTa(rs.getString("MoTa"));
                loai.setTrangThai(rs.getBoolean("TrangThai"));
                list.add(loai);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
    
    @Override
    public boolean kiemTraLoaiDangSuDung(int maLoai) {
        String sql = "SELECT COUNT(*) FROM SanPham WHERE MaLoai = ?";
        
        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, maLoai);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
