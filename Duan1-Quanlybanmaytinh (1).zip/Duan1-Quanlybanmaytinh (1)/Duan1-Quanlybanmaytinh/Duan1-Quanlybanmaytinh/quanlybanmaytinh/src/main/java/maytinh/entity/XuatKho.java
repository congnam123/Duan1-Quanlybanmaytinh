package maytinh.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Entity class cho Xuất Kho
 * @author Cong Nam
 */
public class XuatKho {
    private String maPhieuXuat;
    private String maKho;
    private String maSanPham;
    private String tenSanPham;
    private int soLuongXuat;
    private BigDecimal donGiaXuat;
    private BigDecimal thanhTien;
    private String khachHang;
    private String nguoiXuat;
    private Date ngayXuat;
    private String lyDoXuat; // "Bán hàng", "Chuyển kho", "Hủy hàng", "Khác"
    private String ghiChu;
    private String trangThai; // "Đã xuất", "Chờ xử lý", "Hủy"
    private Date ngayTao;
    private Date ngayCapNhat;

    // Constructor mặc định
    public XuatKho() {
        this.ngayTao = new Date();
        this.ngayCapNhat = new Date();
        this.trangThai = "Chờ xử lý";
        this.lyDoXuat = "Bán hàng";
    }

    // Constructor đầy đủ
    public XuatKho(String maPhieuXuat, String maKho, String maSanPham, int soLuongXuat, BigDecimal donGiaXuat) {
        this();
        this.maPhieuXuat = maPhieuXuat;
        this.maKho = maKho;
        this.maSanPham = maSanPham;
        this.soLuongXuat = soLuongXuat;
        this.donGiaXuat = donGiaXuat;
        this.thanhTien = donGiaXuat.multiply(new BigDecimal(soLuongXuat));
    }

    // Getter và Setter methods
    public String getMaPhieuXuat() {
        return maPhieuXuat;
    }

    public void setMaPhieuXuat(String maPhieuXuat) {
        this.maPhieuXuat = maPhieuXuat;
    }

    public String getMaKho() {
        return maKho;
    }

    public void setMaKho(String maKho) {
        this.maKho = maKho;
    }

    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuongXuat() {
        return soLuongXuat;
    }

    public void setSoLuongXuat(int soLuongXuat) {
        this.soLuongXuat = soLuongXuat;
        if (this.donGiaXuat != null) {
            this.thanhTien = this.donGiaXuat.multiply(new BigDecimal(soLuongXuat));
        }
    }

    public BigDecimal getDonGiaXuat() {
        return donGiaXuat;
    }

    public void setDonGiaXuat(BigDecimal donGiaXuat) {
        this.donGiaXuat = donGiaXuat;
        if (this.soLuongXuat > 0) {
            this.thanhTien = donGiaXuat.multiply(new BigDecimal(this.soLuongXuat));
        }
    }

    public BigDecimal getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(BigDecimal thanhTien) {
        this.thanhTien = thanhTien;
    }

    public String getKhachHang() {
        return khachHang;
    }

    public void setKhachHang(String khachHang) {
        this.khachHang = khachHang;
    }

    public String getNguoiXuat() {
        return nguoiXuat;
    }

    public void setNguoiXuat(String nguoiXuat) {
        this.nguoiXuat = nguoiXuat;
    }

    public Date getNgayXuat() {
        return ngayXuat;
    }

    public void setNgayXuat(Date ngayXuat) {
        this.ngayXuat = ngayXuat;
    }

    public String getLyDoXuat() {
        return lyDoXuat;
    }

    public void setLyDoXuat(String lyDoXuat) {
        this.lyDoXuat = lyDoXuat;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(Date ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    @Override
    public String toString() {
        return "XuatKho{" +
                "maPhieuXuat='" + maPhieuXuat + '\'' +
                ", maKho='" + maKho + '\'' +
                ", maSanPham='" + maSanPham + '\'' +
                ", tenSanPham='" + tenSanPham + '\'' +
                ", soLuongXuat=" + soLuongXuat +
                ", donGiaXuat=" + donGiaXuat +
                ", thanhTien=" + thanhTien +
                ", khachHang='" + khachHang + '\'' +
                ", nguoiXuat='" + nguoiXuat + '\'' +
                ", ngayXuat=" + ngayXuat +
                ", lyDoXuat='" + lyDoXuat + '\'' +
                ", trangThai='" + trangThai + '\'' +
                '}';
    }
}
