package maytinh.impl;

import maytinh.dao.NhapKhoDAO;
import maytinh.entity.NhapKho;
import maytinh.util.XJdbc;
import maytinh.util.XQuery;
import java.util.List;
import java.util.Date;

/**
 * Implementation của NhapKhoDAO
 * @author Cong Nam
 */
public class NhapKhoDAOImpl implements NhapKhoDAO {
    
    // SQL Statements
    private final String INSERT_SQL = "INSERT INTO NhapKho (MaPhieuNhap, MaKho, MaSanPham, TenSanPham, SoLuongNhap, DonGiaNhap, ThanhTien, NhaCungCap, NguoiNhap, NgayNhap, GhiChu, TrangThai, NgayTao, NgayCapNhat) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private final String UPDATE_SQL = "UPDATE NhapKho SET MaKho=?, MaSanPham=?, TenSanPham=?, SoLuongNhap=?, DonGiaNhap=?, ThanhTien=?, NhaCungCap=?, NguoiNhap=?, NgayNhap=?, GhiChu=?, TrangThai=?, NgayCapNhat=? WHERE MaPhieuNhap=?";
    
    private final String DELETE_SQL = "DELETE FROM NhapKho WHERE MaPhieuNhap=?";
    
    private final String SELECT_ALL_SQL = "SELECT * FROM NhapKho ORDER BY NgayCapNhat DESC";
    
    private final String SELECT_BY_ID_SQL = "SELECT * FROM NhapKho WHERE MaPhieuNhap=?";
    
    private final String SELECT_BY_MA_KHO_SQL = "SELECT * FROM NhapKho WHERE MaKho=?";
    
    private final String SELECT_BY_MA_SAN_PHAM_SQL = "SELECT * FROM NhapKho WHERE MaSanPham=?";
    
    private final String SELECT_BY_TRANG_THAI_SQL = "SELECT * FROM NhapKho WHERE TrangThai=?";
    
    private final String SELECT_BY_NGUOI_NHAP_SQL = "SELECT * FROM NhapKho WHERE NguoiNhap LIKE ?";
    
    private final String SELECT_BY_NHA_CUNG_CAP_SQL = "SELECT * FROM NhapKho WHERE NhaCungCap LIKE ?";
    
    private final String SELECT_BY_DATE_RANGE_SQL = "SELECT * FROM NhapKho WHERE NgayNhap BETWEEN ? AND ?";
    
    private final String SEARCH_SQL = "SELECT * FROM NhapKho WHERE MaPhieuNhap LIKE ? OR TenSanPham LIKE ? OR NhaCungCap LIKE ? OR NguoiNhap LIKE ?";
    
    private final String UPDATE_TRANG_THAI_SQL = "UPDATE NhapKho SET TrangThai=?, NgayCapNhat=GETDATE() WHERE MaPhieuNhap=?";
    
    private final String SELECT_BY_PAGE_SQL = "SELECT * FROM NhapKho ORDER BY NgayCapNhat DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    
    private final String COUNT_SQL = "SELECT COUNT(*) FROM NhapKho";
    
    private final String COUNT_BY_TRANG_THAI_SQL = "SELECT COUNT(*) FROM NhapKho WHERE TrangThai=?";
    
    private final String EXISTS_BY_MA_SQL = "SELECT COUNT(*) FROM NhapKho WHERE MaPhieuNhap=?";
    
    private final String SUM_SO_LUONG_BY_SAN_PHAM_SQL = "SELECT ISNULL(SUM(SoLuongNhap), 0) FROM NhapKho WHERE MaSanPham=? AND TrangThai='Đã nhập'";
    
    private final String SUM_GIA_TRI_BY_KHO_SQL = "SELECT ISNULL(SUM(ThanhTien), 0) FROM NhapKho WHERE MaKho=? AND TrangThai='Đã nhập'";

    @Override
    public NhapKho create(NhapKho nhapKho) {
        Object[] values = {
            nhapKho.getMaPhieuNhap(),
            nhapKho.getMaKho(),
            nhapKho.getMaSanPham(),
            nhapKho.getTenSanPham(),
            nhapKho.getSoLuongNhap(),
            nhapKho.getDonGiaNhap(),
            nhapKho.getThanhTien(),
            nhapKho.getNhaCungCap(),
            nhapKho.getNguoiNhap(),
            nhapKho.getNgayNhap(),
            nhapKho.getGhiChu(),
            nhapKho.getTrangThai(),
            nhapKho.getNgayTao(),
            nhapKho.getNgayCapNhat()
        };
        XJdbc.executeUpdate(INSERT_SQL, values);
        return nhapKho;
    }

    @Override
    public void update(NhapKho nhapKho) {
        nhapKho.setNgayCapNhat(new Date());
        Object[] values = {
            nhapKho.getMaKho(),
            nhapKho.getMaSanPham(),
            nhapKho.getTenSanPham(),
            nhapKho.getSoLuongNhap(),
            nhapKho.getDonGiaNhap(),
            nhapKho.getThanhTien(),
            nhapKho.getNhaCungCap(),
            nhapKho.getNguoiNhap(),
            nhapKho.getNgayNhap(),
            nhapKho.getGhiChu(),
            nhapKho.getTrangThai(),
            nhapKho.getNgayCapNhat(),
            nhapKho.getMaPhieuNhap()
        };
        XJdbc.executeUpdate(UPDATE_SQL, values);
    }

    @Override
    public void deleteById(String maPhieuNhap) {
        XJdbc.executeUpdate(DELETE_SQL, maPhieuNhap);
    }

    @Override
    public List<NhapKho> findAll() {
        return XQuery.getBeanList(NhapKho.class, SELECT_ALL_SQL);
    }

    @Override
    public NhapKho findById(String maPhieuNhap) {
        return XQuery.getSingleBean(NhapKho.class, SELECT_BY_ID_SQL, maPhieuNhap);
    }

    @Override
    public List<NhapKho> findByMaKho(String maKho) {
        return XQuery.getBeanList(NhapKho.class, SELECT_BY_MA_KHO_SQL, maKho);
    }

    @Override
    public List<NhapKho> findByMaSanPham(String maSanPham) {
        return XQuery.getBeanList(NhapKho.class, SELECT_BY_MA_SAN_PHAM_SQL, maSanPham);
    }

    @Override
    public List<NhapKho> findByTrangThai(String trangThai) {
        return XQuery.getBeanList(NhapKho.class, SELECT_BY_TRANG_THAI_SQL, trangThai);
    }

    @Override
    public List<NhapKho> findByNguoiNhap(String nguoiNhap) {
        return XQuery.getBeanList(NhapKho.class, SELECT_BY_NGUOI_NHAP_SQL, "%" + nguoiNhap + "%");
    }

    @Override
    public List<NhapKho> findByNhaCungCap(String nhaCungCap) {
        return XQuery.getBeanList(NhapKho.class, SELECT_BY_NHA_CUNG_CAP_SQL, "%" + nhaCungCap + "%");
    }

    @Override
    public List<NhapKho> findByDateRange(Date tuNgay, Date denNgay) {
        return XQuery.getBeanList(NhapKho.class, SELECT_BY_DATE_RANGE_SQL, tuNgay, denNgay);
    }

    @Override
    public List<NhapKho> search(String keyword) {
        String searchPattern = "%" + keyword + "%";
        return XQuery.getBeanList(NhapKho.class, SEARCH_SQL, 
            searchPattern, searchPattern, searchPattern, searchPattern);
    }

    @Override
    public void updateTrangThai(String maPhieuNhap, String trangThai) {
        XJdbc.executeUpdate(UPDATE_TRANG_THAI_SQL, trangThai, maPhieuNhap);
    }

    @Override
    public List<NhapKho> findByPage(int page, int size) {
        int offset = page * size;
        return XQuery.getBeanList(NhapKho.class, SELECT_BY_PAGE_SQL, offset, size);
    }

    @Override
    public long count() {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_SQL);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public long countByTrangThai(String trangThai) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_BY_TRANG_THAI_SQL, trangThai);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public boolean existsByMaPhieuNhap(String maPhieuNhap) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(EXISTS_BY_MA_SQL, maPhieuNhap);
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public int getTongSoLuongNhapBySanPham(String maSanPham) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(SUM_SO_LUONG_BY_SAN_PHAM_SQL, maSanPham);
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public double getTongGiaTriNhapByKho(String maKho) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(SUM_GIA_TRI_BY_KHO_SQL, maKho);
            if (rs.next()) {
                return rs.getDouble(1);
            }
            return 0.0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0.0;
        }
    }
}
