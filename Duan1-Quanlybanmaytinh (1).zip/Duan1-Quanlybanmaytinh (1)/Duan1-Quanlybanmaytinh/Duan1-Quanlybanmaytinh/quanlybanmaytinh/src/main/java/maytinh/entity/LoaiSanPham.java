package maytinh.entity;

/**
 * Entity cho Loại sản phẩm
 * @author Admin
 */
public class LoaiSanPham {
    private int maLoai;
    private String tenLoai;
    private String moTa;
    private boolean trangThai;
    
    // Constructors
    public LoaiSanPham() {
    }
    
    public LoaiSanPham(int maLoai, String tenLoai) {
        this.maLoai = maLoai;
        this.tenLoai = tenLoai;
        this.trangThai = true;
    }
    
    public LoaiSanPham(int maLoai, String tenLoai, String moTa, boolean trangThai) {
        this.maLoai = maLoai;
        this.tenLoai = tenLoai;
        this.moTa = moTa;
        this.trangThai = trangThai;
    }
    
    // Getters and Setters
    public int getMaLoai() {
        return maLoai;
    }
    
    public void setMaLoai(int maLoai) {
        this.maLoai = maLoai;
    }
    
    public String getTenLoai() {
        return tenLoai;
    }
    
    public void setTenLoai(String tenLoai) {
        this.tenLoai = tenLoai;
    }
    
    public String getMoTa() {
        return moTa;
    }
    
    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }
    
    public boolean isTrangThai() {
        return trangThai;
    }
    
    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }
    
    // Override toString để hiển thị trong ComboBox
    @Override
    public String toString() {
        return tenLoai;
    }
    
    // Override equals và hashCode để so sánh
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        LoaiSanPham that = (LoaiSanPham) obj;
        return maLoai == that.maLoai;
    }
    
    @Override
    public int hashCode() {
        return Integer.hashCode(maLoai);
    }
}
