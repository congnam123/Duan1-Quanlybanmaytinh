package maytinh.dao;

import maytinh.entity.Laptop;
import java.util.List;

/**
 * DAO interface cho Laptop
 */
public interface LaptopDAO extends CrudDao<Laptop, String> {
    
    /**
     * Tìm laptop theo tên
     */
    List<Laptop> findByTenLaptop(String tenLaptop);
    
    /**
     * Tìm laptop theo hãng sản xuất
     */
    List<Laptop> findByHangSanXuat(String hangSanXuat);
    
    /**
     * Tìm laptop theo trạng thái
     */
    List<Laptop> findByTrangThai(String trangThai);
    
    /**
     * Tìm laptop theo khoảng giá
     */
    List<Laptop> findByGiaRange(double giaMin, double giaMax);
    
    /**
     * Tìm laptop còn hàng (số lượng > 0)
     */
    List<Laptop> findAvailableLaptops();
    
    /**
     * Tìm laptop hết hàng (số lượng = 0)
     */
    List<Laptop> findOutOfStockLaptops();
    
    /**
     * Cập nhật số lượng laptop
     */
    void updateSoLuong(String maLaptop, int soLuong);
    
    /**
     * Cập nhật trạng thái laptop
     */
    void updateTrangThai(String maLaptop, String trangThai);
    
    /**
     * Tìm kiếm laptop theo từ khóa (tên, hãng, CPU, RAM, etc.)
     */
    List<Laptop> search(String keyword);
    
    /**
     * Lấy danh sách laptop theo trang
     */
    List<Laptop> findByPage(int page, int size);
    
    /**
     * Đếm tổng số laptop
     */
    long count();
    
    /**
     * Đếm laptop theo trạng thái
     */
    long countByTrangThai(String trangThai);
}
