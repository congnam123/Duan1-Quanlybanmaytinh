package maytinh.util;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Utility class for image handling
 */
public class XImage {
    
    /**
     * Read image from file path and return as ImageIcon
     * @param imagePath path to image file
     * @return ImageIcon or null if error
     */
    public static ImageIcon read(String imagePath) {
        try {
            if (imagePath == null || imagePath.trim().isEmpty()) {
                return null;
            }
            
            File imageFile = new File(imagePath);
            if (!imageFile.exists()) {
                System.out.println("Image file not found: " + imagePath);
                return null;
            }
            
            BufferedImage bufferedImage = ImageIO.read(imageFile);
            if (bufferedImage == null) {
                System.out.println("Cannot read image: " + imagePath);
                return null;
            }
            
            return new ImageIcon(bufferedImage);
            
        } catch (Exception e) {
            System.out.println("Error reading image: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Read image and resize to specified dimensions
     * @param imagePath path to image file
     * @param width target width
     * @param height target height
     * @return resized ImageIcon or null if error
     */
    public static ImageIcon read(String imagePath, int width, int height) {
        try {
            ImageIcon originalIcon = read(imagePath);
            if (originalIcon == null) {
                return null;
            }
            
            Image originalImage = originalIcon.getImage();
            Image resizedImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            
            return new ImageIcon(resizedImage);
            
        } catch (Exception e) {
            System.out.println("Error resizing image: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Save ImageIcon to file
     * @param icon ImageIcon to save
     * @param filePath target file path
     * @param format image format (jpg, png, gif, etc.)
     * @return true if successful, false otherwise
     */
    public static boolean save(ImageIcon icon, String filePath, String format) {
        try {
            if (icon == null || filePath == null || format == null) {
                return false;
            }
            
            Image image = icon.getImage();
            BufferedImage bufferedImage = new BufferedImage(
                image.getWidth(null), 
                image.getHeight(null), 
                BufferedImage.TYPE_INT_RGB
            );
            
            Graphics2D g2d = bufferedImage.createGraphics();
            g2d.drawImage(image, 0, 0, null);
            g2d.dispose();
            
            File outputFile = new File(filePath);
            return ImageIO.write(bufferedImage, format, outputFile);
            
        } catch (Exception e) {
            System.out.println("Error saving image: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Create a placeholder image with text
     * @param text text to display
     * @param width image width
     * @param height image height
     * @return ImageIcon with placeholder
     */
    public static ImageIcon createPlaceholder(String text, int width, int height) {
        try {
            BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = image.createGraphics();
            
            // Set background color
            g2d.setColor(Color.LIGHT_GRAY);
            g2d.fillRect(0, 0, width, height);
            
            // Set border
            g2d.setColor(Color.GRAY);
            g2d.drawRect(0, 0, width - 1, height - 1);
            
            // Set text
            g2d.setColor(Color.DARK_GRAY);
            g2d.setFont(new Font("Arial", Font.PLAIN, 12));
            
            FontMetrics fm = g2d.getFontMetrics();
            int textWidth = fm.stringWidth(text);
            int textHeight = fm.getHeight();
            
            int x = (width - textWidth) / 2;
            int y = (height - textHeight) / 2 + fm.getAscent();
            
            g2d.drawString(text, x, y);
            g2d.dispose();
            
            return new ImageIcon(image);
            
        } catch (Exception e) {
            System.out.println("Error creating placeholder: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Get default no-image icon
     * @return default ImageIcon for no image
     */
    public static ImageIcon getNoImageIcon() {
        return createPlaceholder("No Image", 100, 80);
    }
    
    /**
     * Get default no-image icon with custom size
     * @param width icon width
     * @param height icon height
     * @return default ImageIcon for no image
     */
    public static ImageIcon getNoImageIcon(int width, int height) {
        return createPlaceholder("No Image", width, height);
    }
}
