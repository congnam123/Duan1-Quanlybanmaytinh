package maytinh.ui;

/**
 * Interface callback để refresh giao diện sau khi thanh toán
 * @author Cong Nam
 */
public interface RefreshCallback {
    /**
     * Được gọi khi cần refresh danh sách sản phẩm
     */
    void onRefreshRequired();
}
