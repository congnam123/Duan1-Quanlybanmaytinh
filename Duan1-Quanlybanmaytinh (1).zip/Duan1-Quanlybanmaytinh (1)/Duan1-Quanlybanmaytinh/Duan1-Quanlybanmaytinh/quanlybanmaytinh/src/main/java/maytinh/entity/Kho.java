package maytinh.entity;

import java.util.Date;

/**
 * Entity class cho Kho
 * @author Cong Nam
 */
public class Kho {
    private String maKho;
    private String tenKho;
    private String diaChi;
    private String nguoiQuanLy;
    private String soDienThoai;
    private String email;
    private String moTa;
    private Date ngayTao;
    private Date ngayCapNhat;
    private boolean trangThai; // true: hoạt động, false: ngừng hoạt động
    private int tongSanPham; // Tổng số sản phẩm trong kho
    private double tongGiaTri; // Tổng giá trị hàng hóa trong kho

    // Constructor mặc định
    public Kho() {
        this.ngayTao = new Date();
        this.ngayCapNhat = new Date();
        this.trangThai = true;
        this.tongSanPham = 0;
        this.tongGiaTri = 0.0;
    }

    // Constructor đầy đủ
    public Kho(String maKho, String tenKho, String diaChi, String nguoiQuanLy) {
        this();
        this.maKho = maKho;
        this.tenKho = tenKho;
        this.diaChi = diaChi;
        this.nguoiQuanLy = nguoiQuanLy;
    }

    // Getter và Setter methods
    public String getMaKho() {
        return maKho;
    }

    public void setMaKho(String maKho) {
        this.maKho = maKho;
    }

    public String getTenKho() {
        return tenKho;
    }

    public void setTenKho(String tenKho) {
        this.tenKho = tenKho;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public String getNguoiQuanLy() {
        return nguoiQuanLy;
    }

    public void setNguoiQuanLy(String nguoiQuanLy) {
        this.nguoiQuanLy = nguoiQuanLy;
    }

    public String getSoDienThoai() {
        return soDienThoai;
    }

    public void setSoDienThoai(String soDienThoai) {
        this.soDienThoai = soDienThoai;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(Date ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    public boolean isTrangThai() {
        return trangThai;
    }

    public void setTrangThai(boolean trangThai) {
        this.trangThai = trangThai;
    }

    public int getTongSanPham() {
        return tongSanPham;
    }

    public void setTongSanPham(int tongSanPham) {
        this.tongSanPham = tongSanPham;
    }

    public double getTongGiaTri() {
        return tongGiaTri;
    }

    public void setTongGiaTri(double tongGiaTri) {
        this.tongGiaTri = tongGiaTri;
    }

    @Override
    public String toString() {
        return "Kho{" +
                "maKho='" + maKho + '\'' +
                ", tenKho='" + tenKho + '\'' +
                ", diaChi='" + diaChi + '\'' +
                ", nguoiQuanLy='" + nguoiQuanLy + '\'' +
                ", trangThai=" + trangThai +
                ", tongSanPham=" + tongSanPham +
                ", tongGiaTri=" + tongGiaTri +
                '}';
    }
}
