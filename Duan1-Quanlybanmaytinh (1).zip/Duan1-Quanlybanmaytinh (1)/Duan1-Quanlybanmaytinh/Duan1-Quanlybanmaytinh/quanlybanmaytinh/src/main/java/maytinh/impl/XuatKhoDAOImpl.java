package maytinh.impl;

import maytinh.dao.XuatKhoDAO;
import maytinh.entity.XuatKho;
import maytinh.util.XJdbc;
import maytinh.util.XQuery;
import java.util.List;
import java.util.Date;

/**
 * Implementation của XuatKhoDAO
 * @author Cong Nam
 */
public class XuatKhoDAOImpl implements XuatKhoDAO {
    
    // SQL Statements
    private final String INSERT_SQL = "INSERT INTO XuatKho (MaPhieuXuat, MaKho, MaSanPham, TenSanPham, SoLuongXuat, DonGiaXuat, ThanhTien, KhachHang, NguoiXuat, NgayXuat, LyDoXuat, GhiChu, TrangThai, NgayTao, NgayCapNhat) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private final String UPDATE_SQL = "UPDATE XuatKho SET MaKho=?, MaSanPham=?, TenSanPham=?, SoLuongXuat=?, DonGiaXuat=?, ThanhTien=?, KhachHang=?, NguoiXuat=?, NgayXuat=?, LyDoXuat=?, GhiChu=?, TrangThai=?, NgayCapNhat=? WHERE MaPhieuXuat=?";
    
    private final String DELETE_SQL = "DELETE FROM XuatKho WHERE MaPhieuXuat=?";
    
    private final String SELECT_ALL_SQL = "SELECT * FROM XuatKho ORDER BY NgayCapNhat DESC";
    
    private final String SELECT_BY_ID_SQL = "SELECT * FROM XuatKho WHERE MaPhieuXuat=?";
    
    private final String SELECT_BY_MA_KHO_SQL = "SELECT * FROM XuatKho WHERE MaKho=?";
    
    private final String SELECT_BY_MA_SAN_PHAM_SQL = "SELECT * FROM XuatKho WHERE MaSanPham=?";
    
    private final String SELECT_BY_TRANG_THAI_SQL = "SELECT * FROM XuatKho WHERE TrangThai=?";
    
    private final String SELECT_BY_NGUOI_XUAT_SQL = "SELECT * FROM XuatKho WHERE NguoiXuat LIKE ?";
    
    private final String SELECT_BY_KHACH_HANG_SQL = "SELECT * FROM XuatKho WHERE KhachHang LIKE ?";
    
    private final String SELECT_BY_LY_DO_XUAT_SQL = "SELECT * FROM XuatKho WHERE LyDoXuat=?";
    
    private final String SELECT_BY_DATE_RANGE_SQL = "SELECT * FROM XuatKho WHERE NgayXuat BETWEEN ? AND ?";
    
    private final String SEARCH_SQL = "SELECT * FROM XuatKho WHERE MaPhieuXuat LIKE ? OR TenSanPham LIKE ? OR KhachHang LIKE ? OR NguoiXuat LIKE ?";
    
    private final String UPDATE_TRANG_THAI_SQL = "UPDATE XuatKho SET TrangThai=?, NgayCapNhat=GETDATE() WHERE MaPhieuXuat=?";
    
    private final String SELECT_BY_PAGE_SQL = "SELECT * FROM XuatKho ORDER BY NgayCapNhat DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    
    private final String COUNT_SQL = "SELECT COUNT(*) FROM XuatKho";
    
    private final String COUNT_BY_TRANG_THAI_SQL = "SELECT COUNT(*) FROM XuatKho WHERE TrangThai=?";
    
    private final String EXISTS_BY_MA_SQL = "SELECT COUNT(*) FROM XuatKho WHERE MaPhieuXuat=?";
    
    private final String SUM_SO_LUONG_BY_SAN_PHAM_SQL = "SELECT ISNULL(SUM(SoLuongXuat), 0) FROM XuatKho WHERE MaSanPham=? AND TrangThai='Đã xuất'";
    
    private final String SUM_GIA_TRI_BY_KHO_SQL = "SELECT ISNULL(SUM(ThanhTien), 0) FROM XuatKho WHERE MaKho=? AND TrangThai='Đã xuất'";

    @Override
    public XuatKho create(XuatKho xuatKho) {
        Object[] values = {
            xuatKho.getMaPhieuXuat(),
            xuatKho.getMaKho(),
            xuatKho.getMaSanPham(),
            xuatKho.getTenSanPham(),
            xuatKho.getSoLuongXuat(),
            xuatKho.getDonGiaXuat(),
            xuatKho.getThanhTien(),
            xuatKho.getKhachHang(),
            xuatKho.getNguoiXuat(),
            xuatKho.getNgayXuat(),
            xuatKho.getLyDoXuat(),
            xuatKho.getGhiChu(),
            xuatKho.getTrangThai(),
            xuatKho.getNgayTao(),
            xuatKho.getNgayCapNhat()
        };
        XJdbc.executeUpdate(INSERT_SQL, values);
        return xuatKho;
    }

    @Override
    public void update(XuatKho xuatKho) {
        xuatKho.setNgayCapNhat(new Date());
        Object[] values = {
            xuatKho.getMaKho(),
            xuatKho.getMaSanPham(),
            xuatKho.getTenSanPham(),
            xuatKho.getSoLuongXuat(),
            xuatKho.getDonGiaXuat(),
            xuatKho.getThanhTien(),
            xuatKho.getKhachHang(),
            xuatKho.getNguoiXuat(),
            xuatKho.getNgayXuat(),
            xuatKho.getLyDoXuat(),
            xuatKho.getGhiChu(),
            xuatKho.getTrangThai(),
            xuatKho.getNgayCapNhat(),
            xuatKho.getMaPhieuXuat()
        };
        XJdbc.executeUpdate(UPDATE_SQL, values);
    }

    @Override
    public void deleteById(String maPhieuXuat) {
        XJdbc.executeUpdate(DELETE_SQL, maPhieuXuat);
    }

    @Override
    public List<XuatKho> findAll() {
        return XQuery.getBeanList(XuatKho.class, SELECT_ALL_SQL);
    }

    @Override
    public XuatKho findById(String maPhieuXuat) {
        return XQuery.getSingleBean(XuatKho.class, SELECT_BY_ID_SQL, maPhieuXuat);
    }

    @Override
    public List<XuatKho> findByMaKho(String maKho) {
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_MA_KHO_SQL, maKho);
    }

    @Override
    public List<XuatKho> findByMaSanPham(String maSanPham) {
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_MA_SAN_PHAM_SQL, maSanPham);
    }

    @Override
    public List<XuatKho> findByTrangThai(String trangThai) {
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_TRANG_THAI_SQL, trangThai);
    }

    @Override
    public List<XuatKho> findByNguoiXuat(String nguoiXuat) {
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_NGUOI_XUAT_SQL, "%" + nguoiXuat + "%");
    }

    @Override
    public List<XuatKho> findByKhachHang(String khachHang) {
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_KHACH_HANG_SQL, "%" + khachHang + "%");
    }

    @Override
    public List<XuatKho> findByLyDoXuat(String lyDoXuat) {
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_LY_DO_XUAT_SQL, lyDoXuat);
    }

    @Override
    public List<XuatKho> findByDateRange(Date tuNgay, Date denNgay) {
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_DATE_RANGE_SQL, tuNgay, denNgay);
    }

    @Override
    public List<XuatKho> search(String keyword) {
        String searchPattern = "%" + keyword + "%";
        return XQuery.getBeanList(XuatKho.class, SEARCH_SQL, 
            searchPattern, searchPattern, searchPattern, searchPattern);
    }

    @Override
    public void updateTrangThai(String maPhieuXuat, String trangThai) {
        XJdbc.executeUpdate(UPDATE_TRANG_THAI_SQL, trangThai, maPhieuXuat);
    }

    @Override
    public List<XuatKho> findByPage(int page, int size) {
        int offset = page * size;
        return XQuery.getBeanList(XuatKho.class, SELECT_BY_PAGE_SQL, offset, size);
    }

    @Override
    public long count() {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_SQL);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public long countByTrangThai(String trangThai) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_BY_TRANG_THAI_SQL, trangThai);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public boolean existsByMaPhieuXuat(String maPhieuXuat) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(EXISTS_BY_MA_SQL, maPhieuXuat);
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public int getTongSoLuongXuatBySanPham(String maSanPham) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(SUM_SO_LUONG_BY_SAN_PHAM_SQL, maSanPham);
            if (rs.next()) {
                return rs.getInt(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public double getTongGiaTriXuatByKho(String maKho) {
        try {
            java.sql.ResultSet rs = XJdbc.executeQuery(SUM_GIA_TRI_BY_KHO_SQL, maKho);
            if (rs.next()) {
                return rs.getDouble(1);
            }
            return 0.0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0.0;
        }
    }
}
