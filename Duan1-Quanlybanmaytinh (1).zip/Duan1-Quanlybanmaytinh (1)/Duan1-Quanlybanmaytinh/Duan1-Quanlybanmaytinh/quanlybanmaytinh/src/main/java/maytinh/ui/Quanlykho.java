/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package maytinh.ui;

import maytinh.controller.QuanLyKhoController;
import maytinh.controller.NhapXuatKhoController;
import maytinh.entity.Kho;
import maytinh.entity.NhapKho;
import maytinh.entity.XuatKho;
import maytinh.entity.SanPham;
import maytinh.util.XDialog;
import maytinh.util.XJdbc;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultComboBoxModel;
import java.util.List;
import java.text.SimpleDateFormat;
import java.text.NumberFormat;
import java.math.BigDecimal;
import java.util.Locale;

/**
 * Giao diện quản lý kho
 * @author Cong Nam
 */
public class Quanlykho extends javax.swing.JDialog {

    private QuanLyKhoController khoController;
    private NhapXuatKhoController nhapXuatController;
    private DefaultTableModel khoTableModel;
    private DefaultTableModel nhapKhoTableModel;
    private DefaultTableModel xuatKhoTableModel;
    private DefaultTableModel tonKhoTableModel;
    private int selectedRow = -1;
    private NumberFormat currencyFormat;

    /**
     * Creates new form Quanlykho
     */
    public Quanlykho(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        initController();
        initTables();
        initComboBoxes();
        loadAllData();
        clearForm();
        clearNhapKhoForm();
        clearXuatKhoForm();

        // Khởi tạo format tiền tệ
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

        // Thêm listener cho số lượng và đơn giá để tính thành tiền (Tab Nhập Kho)
        txtSoLuongNhap.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                calculateThanhTienNhap();
            }
        });

        txtDonGiaNhap.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                calculateThanhTienNhap();
            }
        });

        // Thêm listener cho số lượng và đơn giá để tính thành tiền (Tab Xuất Kho)
        txtSoLuongXuat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                calculateThanhTienXuat();
            }
        });

        txtDonGiaXuat.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                calculateThanhTienXuat();
            }
        });
    }

    /**
     * Khởi tạo controller
     */
    private void initController() {
        khoController = new QuanLyKhoController();
        nhapXuatController = new NhapXuatKhoController();
    }

    /**
     * Khởi tạo các bảng dữ liệu
     */
    private void initTables() {
        khoTableModel = (DefaultTableModel) tblKho.getModel();
        tblKho.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        nhapKhoTableModel = (DefaultTableModel) tblNhapKho.getModel();
        tblNhapKho.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        xuatKhoTableModel = (DefaultTableModel) tblXuatKho.getModel();
        tblXuatKho.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        tonKhoTableModel = (DefaultTableModel) tblTonKho.getModel();
        tblTonKho.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
    }

    /**
     * Khởi tạo ComboBox
     */
    private void initComboBoxes() {
        // Load danh sách kho cho tab nhập kho, xuất kho và tồn kho
        loadKhoComboBox();
        loadSanPhamComboBox();
        loadKhoXuatComboBox();
        loadSanPhamXuatComboBox();
        loadKhoTonKhoComboBox();
        loadSanPhamTonKhoComboBox();
    }

    /**
     * Load danh sách kho vào ComboBox
     */
    private void loadKhoComboBox() {
        List<Kho> danhSachKho = nhapXuatController.getActiveKho();
        DefaultComboBoxModel<String> khoModel = new DefaultComboBoxModel<>();
        khoModel.addElement("-- Chọn kho --");
        if (danhSachKho != null) {
            for (Kho kho : danhSachKho) {
                khoModel.addElement(kho.getMaKho() + " - " + kho.getTenKho());
            }
        }
        cboKhoNhap.setModel(khoModel);
    }

    /**
     * Load danh sách sản phẩm vào ComboBox (từ bảng SanPham với tồn kho)
     */
    private void loadSanPhamComboBox() {
        try {
            List<maytinh.entity.SanPham> sanPhams = nhapXuatController.getAllSanPhamForKho();

            DefaultComboBoxModel<String> sanPhamModel = new DefaultComboBoxModel<>();
            sanPhamModel.addElement("-- Chọn sản phẩm --");

            for (maytinh.entity.SanPham sp : sanPhams) {
                sanPhamModel.addElement(sp.getMaSP() + " - " + sp.getTenSP() + " (Tồn: " + sp.getSoLuong() + ")");
            }

            cboSanPhamNhap.setModel(sanPhamModel);
        } catch (Exception e) {
            System.err.println("Lỗi load sản phẩm: " + e.getMessage());
        }
    }

    /**
     * Load danh sách kho vào ComboBox xuất kho
     */
    private void loadKhoXuatComboBox() {
        List<Kho> danhSachKho = nhapXuatController.getActiveKho();
        DefaultComboBoxModel<String> khoModel = new DefaultComboBoxModel<>();
        khoModel.addElement("-- Chọn kho --");
        if (danhSachKho != null) {
            for (Kho kho : danhSachKho) {
                khoModel.addElement(kho.getMaKho() + " - " + kho.getTenKho());
            }
        }
        cboKhoXuat.setModel(khoModel);

        // Thêm listener để cập nhật tồn kho
        cboKhoXuat.addActionListener(e -> updateTonKhoDisplay());
    }

    /**
     * Load danh sách sản phẩm vào ComboBox xuất kho (từ bảng SanPham với tồn kho)
     */
    private void loadSanPhamXuatComboBox() {
        try {
            List<maytinh.entity.SanPham> sanPhams = nhapXuatController.getAllSanPhamForKho();

            DefaultComboBoxModel<String> sanPhamModel = new DefaultComboBoxModel<>();
            sanPhamModel.addElement("-- Chọn sản phẩm --");

            for (maytinh.entity.SanPham sp : sanPhams) {
                sanPhamModel.addElement(sp.getMaSP() + " - " + sp.getTenSP() + " (Tồn: " + sp.getSoLuong() + ")");
            }

            cboSanPhamXuat.setModel(sanPhamModel);

            // Thêm listener để cập nhật tồn kho
            cboSanPhamXuat.addActionListener(e -> updateTonKhoDisplay());
        } catch (Exception e) {
            System.err.println("Lỗi load sản phẩm xuất: " + e.getMessage());
        }
    }

    /**
     * Load danh sách kho vào ComboBox tồn kho
     */
    private void loadKhoTonKhoComboBox() {
        List<Kho> danhSachKho = nhapXuatController.getActiveKho();
        DefaultComboBoxModel<String> khoModel = new DefaultComboBoxModel<>();
        khoModel.addElement("-- Tất cả kho --");
        if (danhSachKho != null) {
            for (Kho kho : danhSachKho) {
                khoModel.addElement(kho.getMaKho() + " - " + kho.getTenKho());
            }
        }
        cboKhoTonKho.setModel(khoModel);
    }

    /**
     * Load danh sách sản phẩm vào ComboBox tồn kho (từ bảng SanPham với tồn kho)
     */
    private void loadSanPhamTonKhoComboBox() {
        try {
            List<maytinh.entity.SanPham> sanPhams = nhapXuatController.getAllSanPhamForKho();

            DefaultComboBoxModel<String> sanPhamModel = new DefaultComboBoxModel<>();
            sanPhamModel.addElement("-- Tất cả sản phẩm --");

            for (maytinh.entity.SanPham sp : sanPhams) {
                sanPhamModel.addElement(sp.getMaSP() + " - " + sp.getTenSP() + " (Tồn: " + sp.getSoLuong() + ")");
            }

            cboSanPhamTonKho.setModel(sanPhamModel);
        } catch (Exception e) {
            System.err.println("Lỗi load sản phẩm tồn kho: " + e.getMessage());
        }
    }

    /**
     * Load tất cả dữ liệu
     */
    private void loadAllData() {
        loadKhoData();
        loadNhapKhoData();
        loadXuatKhoData();
        loadTonKhoData();
    }

    /**
     * Load dữ liệu kho vào bảng
     */
    private void loadKhoData() {
        khoTableModel.setRowCount(0);
        List<Kho> list = khoController.getAllKho();
        if (list != null) {
            for (Kho kho : list) {
                Object[] row = {
                    kho.getMaKho(),
                    kho.getTenKho(),
                    kho.getDiaChi(),
                    kho.getNguoiQuanLy(),
                    kho.getSoDienThoai(),
                    kho.getEmail(),
                    kho.isTrangThai() ? "Hoạt động" : "Ngừng hoạt động",
                    kho.getTongSanPham()
                };
                khoTableModel.addRow(row);
            }
        }
    }

    /**
     * Load dữ liệu nhập kho vào bảng
     */
    private void loadNhapKhoData() {
        nhapKhoTableModel.setRowCount(0);
        List<maytinh.entity.NhapKho> list = nhapXuatController.getAllNhapKho();
        if (list != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (maytinh.entity.NhapKho nhapKho : list) {
                Object[] row = {
                    nhapKho.getMaPhieuNhap(),
                    nhapKho.getMaKho(),
                    nhapKho.getTenSanPham(),
                    nhapKho.getSoLuongNhap(),
                    nhapKho.getDonGiaNhap(),
                    nhapKho.getThanhTien(),
                    nhapKho.getNhaCungCap(),
                    nhapKho.getNgayNhap() != null ? sdf.format(nhapKho.getNgayNhap()) : "",
                    nhapKho.getTrangThai()
                };
                nhapKhoTableModel.addRow(row);
            }
        }
    }

    /**
     * Load dữ liệu tồn kho vào bảng
     */
    private void loadTonKhoData() {
        tonKhoTableModel.setRowCount(0);
        List<maytinh.entity.TonKho> list = nhapXuatController.getAllTonKho();
        if (list != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            for (maytinh.entity.TonKho tonKho : list) {
                Object[] row = {
                    tonKho.getMaKho(),
                    tonKho.getMaSanPham(),
                    tonKho.getTenSanPham(),
                    tonKho.getSoLuongTon(),
                    tonKho.getSoLuongNhap(),
                    tonKho.getSoLuongXuat(),
                    tonKho.getGiaTriTon(),
                    tonKho.getDonGiaTrungBinh(),
                    tonKho.getTrangThai(),
                    tonKho.getNgayCapNhat() != null ? sdf.format(tonKho.getNgayCapNhat()) : ""
                };
                tonKhoTableModel.addRow(row);
            }
        }
    }

    /**
     * Xóa form
     */
    private void clearForm() {
        txtMaKho.setText(khoController.generateMaKho());
        txtTenKho.setText("");
        txtDiaChi.setText("");
        txtNguoiQuanLy.setText("");
        txtSoDienThoai.setText("");
        txtEmail.setText("");
        txtMoTa.setText("");
        chkTrangThai.setSelected(true);
        selectedRow = -1;
        txtMaKho.setEnabled(true);
    }

    /**
     * Xóa form nhập kho
     */
    private void clearNhapKhoForm() {
        txtMaPhieuNhap.setText(nhapXuatController.generateMaPhieuNhap());
        cboKhoNhap.setSelectedIndex(0);
        cboSanPhamNhap.setSelectedIndex(0);
        txtSoLuongNhap.setText("");
        txtDonGiaNhap.setText("");
        txtNhaCungCap.setText("");
        txtGhiChuNhap.setText("");
        cboTrangThaiNhap.setSelectedIndex(0);
        lblThanhTienNhap.setText("Thành tiền: 0 VNĐ");
        selectedRow = -1;
        txtMaPhieuNhap.setEnabled(true);
    }

    /**
     * Tính thành tiền cho nhập kho
     */
    private void calculateThanhTienNhap() {
        try {
            String soLuongStr = txtSoLuongNhap.getText().trim();
            String donGiaStr = txtDonGiaNhap.getText().trim();

            if (!soLuongStr.isEmpty() && !donGiaStr.isEmpty()) {
                int soLuong = Integer.parseInt(soLuongStr);
                double donGia = Double.parseDouble(donGiaStr);
                double thanhTien = soLuong * donGia;

                lblThanhTienNhap.setText("Thành tiền: " + currencyFormat.format(thanhTien));
            } else {
                lblThanhTienNhap.setText("Thành tiền: 0 VNĐ");
            }
        } catch (NumberFormatException e) {
            lblThanhTienNhap.setText("Thành tiền: 0 VNĐ");
        }
    }

    /**
     * Lấy dữ liệu từ form nhập kho
     */
    private maytinh.entity.NhapKho getNhapKhoFormData() {
        maytinh.entity.NhapKho nhapKho = new maytinh.entity.NhapKho();

        nhapKho.setMaPhieuNhap(txtMaPhieuNhap.getText().trim());

        // Lấy mã kho từ ComboBox
        String khoSelected = (String) cboKhoNhap.getSelectedItem();
        if (khoSelected != null && !khoSelected.startsWith("--")) {
            nhapKho.setMaKho(khoSelected.split(" - ")[0]);
        }

        // Lấy mã sản phẩm từ ComboBox
        String sanPhamSelected = (String) cboSanPhamNhap.getSelectedItem();
        if (sanPhamSelected != null && !sanPhamSelected.startsWith("--")) {
            nhapKho.setMaSanPham(sanPhamSelected.split(" - ")[0]);
        }

        try {
            nhapKho.setSoLuongNhap(Integer.parseInt(txtSoLuongNhap.getText().trim()));
        } catch (NumberFormatException e) {
            nhapKho.setSoLuongNhap(0);
        }

        try {
            nhapKho.setDonGiaNhap(new BigDecimal(txtDonGiaNhap.getText().trim()));
        } catch (NumberFormatException e) {
            nhapKho.setDonGiaNhap(BigDecimal.ZERO);
        }

        nhapKho.setNhaCungCap(txtNhaCungCap.getText().trim());
        nhapKho.setGhiChu(txtGhiChuNhap.getText().trim());
        nhapKho.setTrangThai((String) cboTrangThaiNhap.getSelectedItem());

        return nhapKho;
    }

    // ==================== XỬ LÝ SỰ KIỆN TAB NHẬP KHO ====================

    /**
     * Xử lý sự kiện thêm phiếu nhập
     */
    private void btnThemNhapActionPerformed(java.awt.event.ActionEvent evt) {
        maytinh.entity.NhapKho nhapKho = getNhapKhoFormData();
        if (nhapXuatController.addNhapKho(nhapKho)) {
            // Reload tất cả dữ liệu liên quan
            loadNhapKhoData();
            loadTonKhoData(); // 🔥 Quan trọng: Reload tồn kho
            loadSanPhamComboBox(); // 🔥 Cập nhật ComboBox
            loadSanPhamXuatComboBox();
            loadSanPhamTonKhoComboBox();
            clearNhapKhoForm();
        }
    }

    /**
     * Xử lý sự kiện sửa phiếu nhập
     */
    private void btnSuaNhapActionPerformed(java.awt.event.ActionEvent evt) {
        if (selectedRow < 0) {
            XDialog.alert("Vui lòng chọn phiếu nhập cần sửa!");
            return;
        }

        maytinh.entity.NhapKho nhapKho = getNhapKhoFormData();
        if (nhapXuatController.updateNhapKho(nhapKho)) {
            loadNhapKhoData();
            clearNhapKhoForm();
        }
    }

    /**
     * Xử lý sự kiện xóa phiếu nhập
     */
    private void btnXoaNhapActionPerformed(java.awt.event.ActionEvent evt) {
        if (selectedRow < 0) {
            XDialog.alert("Vui lòng chọn phiếu nhập cần xóa!");
            return;
        }

        String maPhieuNhap = txtMaPhieuNhap.getText();
        if (nhapXuatController.deleteNhapKho(maPhieuNhap)) {
            loadNhapKhoData();
            clearNhapKhoForm();
        }
    }

    /**
     * Xử lý sự kiện làm mới nhập kho
     */
    private void btnLamMoiNhapActionPerformed(java.awt.event.ActionEvent evt) {
        clearNhapKhoForm();
        loadNhapKhoData();
        txtTimKiemNhap.setText("");
    }

    /**
     * Xử lý sự kiện tìm kiếm nhập kho
     */
    private void btnTimKiemNhapActionPerformed(java.awt.event.ActionEvent evt) {
        String keyword = txtTimKiemNhap.getText().trim();
        nhapKhoTableModel.setRowCount(0);

        List<maytinh.entity.NhapKho> list = nhapXuatController.searchNhapKho(keyword);
        if (list != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (maytinh.entity.NhapKho nhapKho : list) {
                Object[] row = {
                    nhapKho.getMaPhieuNhap(),
                    nhapKho.getMaKho(),
                    nhapKho.getTenSanPham(),
                    nhapKho.getSoLuongNhap(),
                    nhapKho.getDonGiaNhap(),
                    nhapKho.getThanhTien(),
                    nhapKho.getNhaCungCap(),
                    nhapKho.getNgayNhap() != null ? sdf.format(nhapKho.getNgayNhap()) : "",
                    nhapKho.getTrangThai()
                };
                nhapKhoTableModel.addRow(row);
            }
        }
    }

    /**
     * Xử lý sự kiện click vào bảng nhập kho
     */
    private void tblNhapKhoMouseClicked(java.awt.event.MouseEvent evt) {
        selectedRow = tblNhapKho.getSelectedRow();
        if (selectedRow >= 0) {
            String maPhieuNhap = (String) nhapKhoTableModel.getValueAt(selectedRow, 0);
            try {
                String sql = "SELECT * FROM NhapKho WHERE MaPhieuNhap = ?";
                maytinh.entity.NhapKho nhapKho = maytinh.util.XQuery.getSingleBean(maytinh.entity.NhapKho.class, sql, maPhieuNhap);
                if (nhapKho != null) {
                    setNhapKhoFormData(nhapKho);
                }
            } catch (Exception e) {
                System.err.println("Lỗi lấy dữ liệu nhập kho: " + e.getMessage());
            }
        }
    }

    /**
     * Hiển thị dữ liệu nhập kho lên form
     */
    private void setNhapKhoFormData(maytinh.entity.NhapKho nhapKho) {
        txtMaPhieuNhap.setText(nhapKho.getMaPhieuNhap());

        // Set kho
        for (int i = 0; i < cboKhoNhap.getItemCount(); i++) {
            String item = cboKhoNhap.getItemAt(i);
            if (item.startsWith(nhapKho.getMaKho())) {
                cboKhoNhap.setSelectedIndex(i);
                break;
            }
        }

        // Set sản phẩm
        for (int i = 0; i < cboSanPhamNhap.getItemCount(); i++) {
            String item = cboSanPhamNhap.getItemAt(i);
            if (item.startsWith(nhapKho.getMaSanPham())) {
                cboSanPhamNhap.setSelectedIndex(i);
                break;
            }
        }

        txtSoLuongNhap.setText(String.valueOf(nhapKho.getSoLuongNhap()));
        txtDonGiaNhap.setText(nhapKho.getDonGiaNhap().toString());
        txtNhaCungCap.setText(nhapKho.getNhaCungCap());
        txtGhiChuNhap.setText(nhapKho.getGhiChu());
        cboTrangThaiNhap.setSelectedItem(nhapKho.getTrangThai());

        calculateThanhTienNhap();
        txtMaPhieuNhap.setEnabled(false);
    }

    // ==================== XỬ LÝ SỰ KIỆN TAB XUẤT KHO ====================

    /**
     * Xóa form xuất kho
     */
    private void clearXuatKhoForm() {
        txtMaPhieuXuat.setText(nhapXuatController.generateMaPhieuXuat());
        cboKhoXuat.setSelectedIndex(0);
        cboSanPhamXuat.setSelectedIndex(0);
        txtSoLuongXuat.setText("");
        txtDonGiaXuat.setText("");
        txtKhachHang.setText("");
        txtGhiChuXuat.setText("");
        cboLyDoXuat.setSelectedIndex(0);
        cboTrangThaiXuat.setSelectedIndex(0);
        lblThanhTienXuat.setText("Thành tiền: 0 VNĐ");
        lblTonKho.setText("Tồn kho: 0");
        selectedRow = -1;
        txtMaPhieuXuat.setEnabled(true);
    }

    /**
     * Tính thành tiền cho xuất kho
     */
    private void calculateThanhTienXuat() {
        try {
            String soLuongStr = txtSoLuongXuat.getText().trim();
            String donGiaStr = txtDonGiaXuat.getText().trim();

            if (!soLuongStr.isEmpty() && !donGiaStr.isEmpty()) {
                int soLuong = Integer.parseInt(soLuongStr);
                double donGia = Double.parseDouble(donGiaStr);
                double thanhTien = soLuong * donGia;

                lblThanhTienXuat.setText("Thành tiền: " + currencyFormat.format(thanhTien));
            } else {
                lblThanhTienXuat.setText("Thành tiền: 0 VNĐ");
            }
        } catch (NumberFormatException e) {
            lblThanhTienXuat.setText("Thành tiền: 0 VNĐ");
        }
    }

    /**
     * Cập nhật tồn kho khi chọn sản phẩm
     */
    private void updateTonKhoDisplay() {
        String khoSelected = (String) cboKhoXuat.getSelectedItem();
        String sanPhamSelected = (String) cboSanPhamXuat.getSelectedItem();

        if (khoSelected != null && !khoSelected.startsWith("--") &&
            sanPhamSelected != null && !sanPhamSelected.startsWith("--")) {

            String maKho = khoSelected.split(" - ")[0];
            String maSanPham = sanPhamSelected.split(" - ")[0];

            int tonKho = nhapXuatController.getTonKho(maKho, maSanPham);
            lblTonKho.setText("Tồn kho: " + tonKho);
        } else {
            lblTonKho.setText("Tồn kho: 0");
        }
    }

    /**
     * Xử lý sự kiện thêm phiếu xuất
     */
    private void btnThemXuatActionPerformed(java.awt.event.ActionEvent evt) {
        // Kiểm tra tồn kho trước khi xuất
        String khoSelected = (String) cboKhoXuat.getSelectedItem();
        String sanPhamSelected = (String) cboSanPhamXuat.getSelectedItem();

        if (khoSelected == null || khoSelected.startsWith("--")) {
            XDialog.alert("Vui lòng chọn kho!");
            return;
        }

        if (sanPhamSelected == null || sanPhamSelected.startsWith("--")) {
            XDialog.alert("Vui lòng chọn sản phẩm!");
            return;
        }

        try {
            int soLuongXuat = Integer.parseInt(txtSoLuongXuat.getText().trim());
            String maKho = khoSelected.split(" - ")[0];
            String maSanPham = sanPhamSelected.split(" - ")[0];

            int tonKho = nhapXuatController.getTonKho(maKho, maSanPham);

            if (soLuongXuat > tonKho) {
                XDialog.alert("Số lượng xuất (" + soLuongXuat + ") vượt quá tồn kho (" + tonKho + ")!");
                return;
            }

            maytinh.entity.XuatKho xuatKho = getXuatKhoFormData();
            if (nhapXuatController.addXuatKho(xuatKho)) {
                // Reload tất cả dữ liệu liên quan
                loadXuatKhoData();
                loadTonKhoData(); // 🔥 Quan trọng: Reload tồn kho
                loadSanPhamComboBox(); // 🔥 Cập nhật ComboBox
                loadSanPhamXuatComboBox();
                loadSanPhamTonKhoComboBox();
                clearXuatKhoForm();
            }
        } catch (NumberFormatException e) {
            XDialog.alert("Vui lòng nhập số lượng hợp lệ!");
        }
    }

    /**
     * Xử lý sự kiện sửa phiếu xuất
     */
    private void btnSuaXuatActionPerformed(java.awt.event.ActionEvent evt) {
        if (selectedRow < 0) {
            XDialog.alert("Vui lòng chọn phiếu xuất cần sửa!");
            return;
        }

        maytinh.entity.XuatKho xuatKho = getXuatKhoFormData();
        if (nhapXuatController.updateXuatKho(xuatKho)) {
            loadXuatKhoData();
            clearXuatKhoForm();
        }
    }

    /**
     * Xử lý sự kiện xóa phiếu xuất
     */
    private void btnXoaXuatActionPerformed(java.awt.event.ActionEvent evt) {
        if (selectedRow < 0) {
            XDialog.alert("Vui lòng chọn phiếu xuất cần xóa!");
            return;
        }

        String maPhieuXuat = txtMaPhieuXuat.getText();
        if (nhapXuatController.deleteXuatKho(maPhieuXuat)) {
            loadXuatKhoData();
            clearXuatKhoForm();
        }
    }

    /**
     * Xử lý sự kiện làm mới xuất kho
     */
    private void btnLamMoiXuatActionPerformed(java.awt.event.ActionEvent evt) {
        clearXuatKhoForm();
        loadXuatKhoData();
        txtTimKiemXuat.setText("");
    }

    /**
     * Xử lý sự kiện tìm kiếm xuất kho
     */
    private void btnTimKiemXuatActionPerformed(java.awt.event.ActionEvent evt) {
        String keyword = txtTimKiemXuat.getText().trim();
        xuatKhoTableModel.setRowCount(0);

        List<maytinh.entity.XuatKho> list = nhapXuatController.searchXuatKho(keyword);
        if (list != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (maytinh.entity.XuatKho xuatKho : list) {
                Object[] row = {
                    xuatKho.getMaPhieuXuat(),
                    xuatKho.getMaKho(),
                    xuatKho.getTenSanPham(),
                    xuatKho.getSoLuongXuat(),
                    xuatKho.getDonGiaXuat(),
                    xuatKho.getThanhTien(),
                    xuatKho.getKhachHang(),
                    xuatKho.getLyDoXuat(),
                    xuatKho.getNgayXuat() != null ? sdf.format(xuatKho.getNgayXuat()) : "",
                    xuatKho.getTrangThai()
                };
                xuatKhoTableModel.addRow(row);
            }
        }
    }

    /**
     * Xử lý sự kiện click vào bảng xuất kho
     */
    private void tblXuatKhoMouseClicked(java.awt.event.MouseEvent evt) {
        selectedRow = tblXuatKho.getSelectedRow();
        if (selectedRow >= 0) {
            String maPhieuXuat = (String) xuatKhoTableModel.getValueAt(selectedRow, 0);
            try {
                String sql = "SELECT * FROM XuatKho WHERE MaPhieuXuat = ?";
                maytinh.entity.XuatKho xuatKho = maytinh.util.XQuery.getSingleBean(maytinh.entity.XuatKho.class, sql, maPhieuXuat);
                if (xuatKho != null) {
                    setXuatKhoFormData(xuatKho);
                }
            } catch (Exception e) {
                System.err.println("Lỗi lấy dữ liệu xuất kho: " + e.getMessage());
            }
        }
    }

    /**
     * Lấy dữ liệu từ form xuất kho
     */
    private maytinh.entity.XuatKho getXuatKhoFormData() {
        maytinh.entity.XuatKho xuatKho = new maytinh.entity.XuatKho();

        xuatKho.setMaPhieuXuat(txtMaPhieuXuat.getText().trim());

        // Lấy mã kho từ ComboBox
        String khoSelected = (String) cboKhoXuat.getSelectedItem();
        if (khoSelected != null && !khoSelected.startsWith("--")) {
            xuatKho.setMaKho(khoSelected.split(" - ")[0]);
        }

        // Lấy mã sản phẩm từ ComboBox
        String sanPhamSelected = (String) cboSanPhamXuat.getSelectedItem();
        if (sanPhamSelected != null && !sanPhamSelected.startsWith("--")) {
            xuatKho.setMaSanPham(sanPhamSelected.split(" - ")[0]);
        }

        try {
            xuatKho.setSoLuongXuat(Integer.parseInt(txtSoLuongXuat.getText().trim()));
        } catch (NumberFormatException e) {
            xuatKho.setSoLuongXuat(0);
        }

        try {
            xuatKho.setDonGiaXuat(new BigDecimal(txtDonGiaXuat.getText().trim()));
        } catch (NumberFormatException e) {
            xuatKho.setDonGiaXuat(BigDecimal.ZERO);
        }

        xuatKho.setKhachHang(txtKhachHang.getText().trim());
        xuatKho.setLyDoXuat((String) cboLyDoXuat.getSelectedItem());
        xuatKho.setGhiChu(txtGhiChuXuat.getText().trim());
        xuatKho.setTrangThai((String) cboTrangThaiXuat.getSelectedItem());

        return xuatKho;
    }

    /**
     * Hiển thị dữ liệu xuất kho lên form
     */
    private void setXuatKhoFormData(maytinh.entity.XuatKho xuatKho) {
        txtMaPhieuXuat.setText(xuatKho.getMaPhieuXuat());

        // Set kho
        for (int i = 0; i < cboKhoXuat.getItemCount(); i++) {
            String item = cboKhoXuat.getItemAt(i);
            if (item.startsWith(xuatKho.getMaKho())) {
                cboKhoXuat.setSelectedIndex(i);
                break;
            }
        }

        // Set sản phẩm
        for (int i = 0; i < cboSanPhamXuat.getItemCount(); i++) {
            String item = cboSanPhamXuat.getItemAt(i);
            if (item.startsWith(xuatKho.getMaSanPham())) {
                cboSanPhamXuat.setSelectedIndex(i);
                break;
            }
        }

        txtSoLuongXuat.setText(String.valueOf(xuatKho.getSoLuongXuat()));
        txtDonGiaXuat.setText(xuatKho.getDonGiaXuat().toString());
        txtKhachHang.setText(xuatKho.getKhachHang());
        txtGhiChuXuat.setText(xuatKho.getGhiChu());
        cboLyDoXuat.setSelectedItem(xuatKho.getLyDoXuat());
        cboTrangThaiXuat.setSelectedItem(xuatKho.getTrangThai());

        calculateThanhTienXuat();
        updateTonKhoDisplay();
        txtMaPhieuXuat.setEnabled(false);
    }

    /**
     * Load dữ liệu xuất kho vào bảng
     */
    private void loadXuatKhoData() {
        xuatKhoTableModel.setRowCount(0);
        List<maytinh.entity.XuatKho> list = nhapXuatController.getAllXuatKho();
        if (list != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
            for (maytinh.entity.XuatKho xuatKho : list) {
                Object[] row = {
                    xuatKho.getMaPhieuXuat(),
                    xuatKho.getMaKho(),
                    xuatKho.getTenSanPham(),
                    xuatKho.getSoLuongXuat(),
                    xuatKho.getDonGiaXuat(),
                    xuatKho.getThanhTien(),
                    xuatKho.getKhachHang(),
                    xuatKho.getLyDoXuat(),
                    xuatKho.getNgayXuat() != null ? sdf.format(xuatKho.getNgayXuat()) : "",
                    xuatKho.getTrangThai()
                };
                xuatKhoTableModel.addRow(row);
            }
        }
    }

    // ==================== XỬ LÝ SỰ KIỆN TAB TỒN KHO ====================

    /**
     * Xử lý sự kiện tìm kiếm tồn kho
     */
    private void btnTimKiemTonKhoActionPerformed(java.awt.event.ActionEvent evt) {
        String maKho = null;
        String maSanPham = null;
        String trangThai = (String) cboTrangThaiTonKho.getSelectedItem();

        // Lấy mã kho từ ComboBox
        String khoSelected = (String) cboKhoTonKho.getSelectedItem();
        if (khoSelected != null && !khoSelected.startsWith("--")) {
            maKho = khoSelected.split(" - ")[0];
        }

        // Lấy mã sản phẩm từ ComboBox
        String sanPhamSelected = (String) cboSanPhamTonKho.getSelectedItem();
        if (sanPhamSelected != null && !sanPhamSelected.startsWith("--")) {
            maSanPham = sanPhamSelected.split(" - ")[0];
        }

        // Lọc dữ liệu tồn kho
        filterTonKhoData(maKho, maSanPham, trangThai);
    }

    /**
     * Xử lý sự kiện làm mới tồn kho
     */
    private void btnLamMoiTonKhoActionPerformed(java.awt.event.ActionEvent evt) {
        cboKhoTonKho.setSelectedIndex(0);
        cboSanPhamTonKho.setSelectedIndex(0);
        cboTrangThaiTonKho.setSelectedIndex(0);
        loadTonKhoData();
    }

    /**
     * Xử lý sự kiện báo cáo tồn kho
     */
    private void btnBaoCaoTonKhoActionPerformed(java.awt.event.ActionEvent evt) {
        generateTonKhoReport();
    }

    /**
     * Lọc dữ liệu tồn kho theo điều kiện
     */
    private void filterTonKhoData(String maKho, String maSanPham, String trangThai) {
        tonKhoTableModel.setRowCount(0);
        List<maytinh.entity.TonKho> list = nhapXuatController.getAllTonKho();

        if (list != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            for (maytinh.entity.TonKho tonKho : list) {
                boolean match = true;

                // Lọc theo kho
                if (maKho != null && !tonKho.getMaKho().equals(maKho)) {
                    match = false;
                }

                // Lọc theo sản phẩm
                if (maSanPham != null && !tonKho.getMaSanPham().equals(maSanPham)) {
                    match = false;
                }

                // Lọc theo trạng thái
                if (!"Tất cả".equals(trangThai) && !tonKho.getTrangThai().equals(trangThai)) {
                    match = false;
                }

                if (match) {
                    Object[] row = {
                        tonKho.getMaKho(),
                        tonKho.getMaSanPham(),
                        tonKho.getTenSanPham(),
                        tonKho.getSoLuongTon(),
                        tonKho.getSoLuongNhap(),
                        tonKho.getSoLuongXuat(),
                        tonKho.getGiaTriTon(),
                        tonKho.getDonGiaTrungBinh(),
                        tonKho.getTrangThai(),
                        tonKho.getNgayCapNhat() != null ? sdf.format(tonKho.getNgayCapNhat()) : ""
                    };
                    tonKhoTableModel.addRow(row);
                }
            }
        }
    }

    /**
     * Tạo báo cáo tồn kho
     */
    private void generateTonKhoReport() {
        List<maytinh.entity.TonKho> list = nhapXuatController.getAllTonKho();
        if (list == null || list.isEmpty()) {
            XDialog.alert("Không có dữ liệu tồn kho để báo cáo!");
            return;
        }

        StringBuilder report = new StringBuilder();
        report.append("=== BÁO CÁO TỒN KHO ===\n\n");

        int tongSanPham = 0;
        double tongGiaTri = 0;
        int sanPhamConHang = 0;
        int sanPhamHetHang = 0;

        for (maytinh.entity.TonKho tonKho : list) {
            tongSanPham += tonKho.getSoLuongTon();
            tongGiaTri += tonKho.getGiaTriTon().doubleValue();

            if ("Còn hàng".equals(tonKho.getTrangThai())) {
                sanPhamConHang++;
            } else if ("Hết hàng".equals(tonKho.getTrangThai())) {
                sanPhamHetHang++;
            }
        }

        report.append("Tổng số lượng tồn: ").append(tongSanPham).append(" sản phẩm\n");
        report.append("Tổng giá trị tồn: ").append(currencyFormat.format(tongGiaTri)).append("\n");
        report.append("Sản phẩm còn hàng: ").append(sanPhamConHang).append("\n");
        report.append("Sản phẩm hết hàng: ").append(sanPhamHetHang).append("\n");
        report.append("Tổng số loại sản phẩm: ").append(list.size()).append("\n");

        XDialog.alert(report.toString());
    }

    /**
     * Xử lý sự kiện đồng bộ tồn kho
     */
    private void btnDongBoTonKhoActionPerformed(java.awt.event.ActionEvent evt) {
        try {
            // Đồng bộ tồn kho từ TonKho sang SanPham
            nhapXuatController.syncTonKhoToSanPham();

            // Reload dữ liệu
            loadAllData();
            loadSanPhamComboBox();
            loadSanPhamXuatComboBox();
            loadSanPhamTonKhoComboBox();

            XDialog.alert("🔗 Đồng bộ tồn kho thành công!\n\n" +
                         "✅ Tồn kho trong bảng SanPham đã được cập nhật\n" +
                         "✅ ComboBox sản phẩm đã được làm mới\n" +
                         "✅ Dữ liệu đã đồng bộ giữa Quản lý Sản phẩm và Kho");
        } catch (Exception e) {
            XDialog.alert("❌ Lỗi khi đồng bộ tồn kho: " + e.getMessage());
        }
    }

    /**
     * Lấy dữ liệu từ form
     */
    private Kho getFormData() {
        Kho kho = new Kho();
        kho.setMaKho(txtMaKho.getText().trim());
        kho.setTenKho(txtTenKho.getText().trim());
        kho.setDiaChi(txtDiaChi.getText().trim());
        kho.setNguoiQuanLy(txtNguoiQuanLy.getText().trim());
        kho.setSoDienThoai(txtSoDienThoai.getText().trim());
        kho.setEmail(txtEmail.getText().trim());
        kho.setMoTa(txtMoTa.getText().trim());
        kho.setTrangThai(chkTrangThai.isSelected());
        return kho;
    }

    /**
     * Hiển thị dữ liệu lên form
     */
    private void setFormData(Kho kho) {
        txtMaKho.setText(kho.getMaKho());
        txtTenKho.setText(kho.getTenKho());
        txtDiaChi.setText(kho.getDiaChi());
        txtNguoiQuanLy.setText(kho.getNguoiQuanLy());
        txtSoDienThoai.setText(kho.getSoDienThoai());
        txtEmail.setText(kho.getEmail());
        txtMoTa.setText(kho.getMoTa());
        chkTrangThai.setSelected(kho.isTrangThai());
        txtMaKho.setEnabled(false);
    }

    /**
     * Xử lý sự kiện thêm kho
     */
    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {
        Kho kho = getFormData();
        if (khoController.addKho(kho)) {
            loadKhoData();
            clearForm();
        }
    }

    /**
     * Xử lý sự kiện sửa kho
     */
    private void btnSuaActionPerformed(java.awt.event.ActionEvent evt) {
        if (selectedRow < 0) {
            XDialog.alert("Vui lòng chọn kho cần sửa!");
            return;
        }

        Kho kho = getFormData();
        if (khoController.updateKho(kho)) {
            loadKhoData();
            clearForm();
        }
    }

    /**
     * Xử lý sự kiện xóa kho
     */
    private void btnXoaActionPerformed(java.awt.event.ActionEvent evt) {
        if (selectedRow < 0) {
            XDialog.alert("Vui lòng chọn kho cần xóa!");
            return;
        }

        String maKho = txtMaKho.getText();
        if (khoController.deleteKho(maKho)) {
            loadKhoData();
            clearForm();
        }
    }

    /**
     * Xử lý sự kiện làm mới
     */
    private void btnLamMoiActionPerformed(java.awt.event.ActionEvent evt) {
        clearForm();
        loadKhoData();
        txtTimKiem.setText("");
    }

    /**
     * Xử lý sự kiện thống kê
     */
    private void btnThongKeActionPerformed(java.awt.event.ActionEvent evt) {
        String thongKe = khoController.getThongKeKho();
        XDialog.alert(thongKe);
    }

    /**
     * Xử lý sự kiện tìm kiếm
     */
    private void btnTimKiemActionPerformed(java.awt.event.ActionEvent evt) {
        String keyword = txtTimKiem.getText().trim();
        khoTableModel.setRowCount(0);

        List<Kho> list = khoController.searchKho(keyword);
        if (list != null) {
            for (Kho kho : list) {
                Object[] row = {
                    kho.getMaKho(),
                    kho.getTenKho(),
                    kho.getDiaChi(),
                    kho.getNguoiQuanLy(),
                    kho.getSoDienThoai(),
                    kho.getEmail(),
                    kho.isTrangThai() ? "Hoạt động" : "Ngừng hoạt động",
                    kho.getTongSanPham()
                };
                khoTableModel.addRow(row);
            }
        }
    }

    /**
     * Xử lý sự kiện click vào bảng
     */
    private void tblKhoMouseClicked(java.awt.event.MouseEvent evt) {
        selectedRow = tblKho.getSelectedRow();
        if (selectedRow >= 0) {
            String maKho = (String) khoTableModel.getValueAt(selectedRow, 0);
            Kho kho = khoController.getKhoById(maKho);
            if (kho != null) {
                setFormData(kho);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        tabQuanLyKho = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtMaKho = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTenKho = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtDiaChi = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtNguoiQuanLy = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtSoDienThoai = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        chkTrangThai = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtMoTa = new javax.swing.JTextArea();
        jPanel3 = new javax.swing.JPanel();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        btnThongKe = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        txtTimKiem = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblKho = new javax.swing.JTable();
        tabNhapKho = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        txtMaPhieuNhap = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cboKhoNhap = new javax.swing.JComboBox<>();
        jLabel13 = new javax.swing.JLabel();
        cboSanPhamNhap = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        txtSoLuongNhap = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtDonGiaNhap = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtNhaCungCap = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        cboTrangThaiNhap = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtGhiChuNhap = new javax.swing.JTextArea();
        jPanel6 = new javax.swing.JPanel();
        btnThemNhap = new javax.swing.JButton();
        btnSuaNhap = new javax.swing.JButton();
        btnXoaNhap = new javax.swing.JButton();
        btnLamMoiNhap = new javax.swing.JButton();
        btnTimKiemNhap = new javax.swing.JButton();
        jLabel19 = new javax.swing.JLabel();
        txtTimKiemNhap = new javax.swing.JTextField();
        lblThanhTienNhap = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblNhapKho = new javax.swing.JTable();
        tabXuatKho = new javax.swing.JPanel();
        jPanel8 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        txtMaPhieuXuat = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        cboKhoXuat = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        cboSanPhamXuat = new javax.swing.JComboBox<>();
        jLabel23 = new javax.swing.JLabel();
        txtSoLuongXuat = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        txtDonGiaXuat = new javax.swing.JTextField();
        jLabel25 = new javax.swing.JLabel();
        txtKhachHang = new javax.swing.JTextField();
        jLabel26 = new javax.swing.JLabel();
        cboLyDoXuat = new javax.swing.JComboBox<>();
        jLabel27 = new javax.swing.JLabel();
        cboTrangThaiXuat = new javax.swing.JComboBox<>();
        jLabel28 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtGhiChuXuat = new javax.swing.JTextArea();
        jPanel9 = new javax.swing.JPanel();
        btnThemXuat = new javax.swing.JButton();
        btnSuaXuat = new javax.swing.JButton();
        btnXoaXuat = new javax.swing.JButton();
        btnLamMoiXuat = new javax.swing.JButton();
        btnTimKiemXuat = new javax.swing.JButton();
        jLabel29 = new javax.swing.JLabel();
        txtTimKiemXuat = new javax.swing.JTextField();
        lblThanhTienXuat = new javax.swing.JLabel();
        lblTonKho = new javax.swing.JLabel();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblXuatKho = new javax.swing.JTable();
        tabTonKho = new javax.swing.JPanel();
        jPanel11 = new javax.swing.JPanel();
        jLabel30 = new javax.swing.JLabel();
        cboKhoTonKho = new javax.swing.JComboBox<>();
        jLabel31 = new javax.swing.JLabel();
        cboSanPhamTonKho = new javax.swing.JComboBox<>();
        jLabel32 = new javax.swing.JLabel();
        cboTrangThaiTonKho = new javax.swing.JComboBox<>();
        btnTimKiemTonKho = new javax.swing.JButton();
        btnLamMoiTonKho = new javax.swing.JButton();
        btnBaoCaoTonKho = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblTonKho = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản Lý Kho");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 51, 153));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("QUẢN LÝ KHO");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin kho"));

        jLabel2.setText("Mã kho:");

        jLabel3.setText("Tên kho:");

        jLabel4.setText("Địa chỉ:");

        jLabel5.setText("Người quản lý:");

        jLabel6.setText("Số điện thoại:");

        jLabel7.setText("Email:");

        jLabel8.setText("Trạng thái:");

        chkTrangThai.setSelected(true);
        chkTrangThai.setText("Hoạt động");

        jLabel9.setText("Mô tả:");

        txtMoTa.setColumns(20);
        txtMoTa.setRows(3);
        jScrollPane1.setViewportView(txtMoTa);

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin phiếu nhập"));

        jLabel11.setText("Mã phiếu nhập:");

        jLabel12.setText("Kho:");

        jLabel13.setText("Sản phẩm:");

        jLabel14.setText("Số lượng:");

        jLabel15.setText("Đơn giá:");

        jLabel16.setText("Nhà cung cấp:");

        jLabel17.setText("Trạng thái:");

        cboTrangThaiNhap.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chờ xử lý", "Đã nhập", "Hủy" }));

        jLabel18.setText("Ghi chú:");

        txtGhiChuNhap.setColumns(20);
        txtGhiChuNhap.setRows(3);
        jScrollPane3.setViewportView(txtGhiChuNhap);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14)
                            .addComponent(jLabel15)
                            .addComponent(jLabel16)
                            .addComponent(jLabel17))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMaPhieuNhap)
                            .addComponent(cboKhoNhap, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboSanPhamNhap, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtSoLuongNhap)
                            .addComponent(txtDonGiaNhap)
                            .addComponent(txtNhaCungCap)
                            .addComponent(cboTrangThaiNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel18)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txtMaPhieuNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(cboKhoNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(cboSanPhamNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(txtSoLuongNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15)
                    .addComponent(txtDonGiaNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txtNhaCungCap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(cboTrangThaiNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel18)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder("Chức năng"));

        btnThemNhap.setText("Thêm");
        btnThemNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemNhapActionPerformed(evt);
            }
        });

        btnSuaNhap.setText("Sửa");
        btnSuaNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaNhapActionPerformed(evt);
            }
        });

        btnXoaNhap.setText("Xóa");
        btnXoaNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaNhapActionPerformed(evt);
            }
        });

        btnLamMoiNhap.setText("Làm mới");
        btnLamMoiNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiNhapActionPerformed(evt);
            }
        });

        btnTimKiemNhap.setText("Tìm kiếm");
        btnTimKiemNhap.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemNhapActionPerformed(evt);
            }
        });

        jLabel19.setText("Tìm kiếm:");

        lblThanhTienNhap.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblThanhTienNhap.setForeground(new java.awt.Color(255, 0, 0));
        lblThanhTienNhap.setText("Thành tiền: 0 VNĐ");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnThemNhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSuaNhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoaNhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLamMoiNhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTimKiemNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(txtTimKiemNhap, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThanhTienNhap))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(btnThemNhap)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSuaNhap)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnXoaNhap)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnLamMoiNhap)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemNhap))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtTimKiemNhap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblThanhTienNhap)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách phiếu nhập"));

        tblNhapKho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã phiếu", "Kho", "Sản phẩm", "Số lượng", "Đơn giá", "Thành tiền", "Nhà CC", "Ngày nhập", "Trạng thái"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblNhapKho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblNhapKhoMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tblNhapKho);

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        // Khởi tạo components cho tab Xuất Kho
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin phiếu xuất"));

        jLabel20.setText("Mã phiếu xuất:");
        jLabel21.setText("Kho:");
        jLabel22.setText("Sản phẩm:");
        jLabel23.setText("Số lượng:");
        jLabel24.setText("Đơn giá:");
        jLabel25.setText("Khách hàng:");
        jLabel26.setText("Lý do xuất:");
        jLabel27.setText("Trạng thái:");
        jLabel28.setText("Ghi chú:");

        cboLyDoXuat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Bán hàng", "Chuyển kho", "Hủy hàng", "Khác" }));
        cboTrangThaiXuat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Chờ xử lý", "Đã xuất", "Hủy" }));

        txtGhiChuXuat.setColumns(20);
        txtGhiChuXuat.setRows(3);
        jScrollPane5.setViewportView(txtGhiChuXuat);

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22)
                            .addComponent(jLabel23)
                            .addComponent(jLabel24)
                            .addComponent(jLabel25)
                            .addComponent(jLabel26)
                            .addComponent(jLabel27))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMaPhieuXuat)
                            .addComponent(cboKhoXuat, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboSanPhamXuat, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtSoLuongXuat)
                            .addComponent(txtDonGiaXuat)
                            .addComponent(txtKhachHang)
                            .addComponent(cboLyDoXuat, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboTrangThaiXuat, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(jLabel28)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txtMaPhieuXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(cboKhoXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(cboSanPhamXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel23)
                    .addComponent(txtSoLuongXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel24)
                    .addComponent(txtDonGiaXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel25)
                    .addComponent(txtKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(cboLyDoXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel27)
                    .addComponent(cboTrangThaiXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel28)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel5)
                            .addComponent(jLabel6)
                            .addComponent(jLabel7))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMaKho)
                            .addComponent(txtTenKho)
                            .addComponent(txtDiaChi)
                            .addComponent(txtNguoiQuanLy)
                            .addComponent(txtSoDienThoai)
                            .addComponent(txtEmail, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(chkTrangThai))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMaKho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTenKho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtDiaChi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtNguoiQuanLy, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtSoDienThoai, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(chkTrangThai))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Chức năng"));

        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("Sửa");
        btnSua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaActionPerformed(evt);
            }
        });

        btnXoa.setText("Xóa");
        btnXoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaActionPerformed(evt);
            }
        });

        btnLamMoi.setText("Làm mới");
        btnLamMoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiActionPerformed(evt);
            }
        });

        btnThongKe.setText("Thống kê");
        btnThongKe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThongKeActionPerformed(evt);
            }
        });

        jLabel10.setText("Tìm kiếm:");

        btnTimKiem.setText("Tìm");
        btnTimKiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnThem, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSua, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoa, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLamMoi, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnThongKe, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnThem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSua)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnXoa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnLamMoi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnThongKe))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiem)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách kho"));

        tblKho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã kho", "Tên kho", "Địa chỉ", "Người quản lý", "Số điện thoại", "Email", "Trạng thái", "Tổng SP"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblKho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblKhoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblKho);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        // Thêm các tab vào TabbedPane
        javax.swing.GroupLayout tabQuanLyKhoLayout = new javax.swing.GroupLayout(tabQuanLyKho);
        tabQuanLyKho.setLayout(tabQuanLyKhoLayout);
        tabQuanLyKhoLayout.setHorizontalGroup(
            tabQuanLyKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabQuanLyKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabQuanLyKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabQuanLyKhoLayout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        tabQuanLyKhoLayout.setVerticalGroup(
            tabQuanLyKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabQuanLyKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabQuanLyKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Quản Lý Kho", tabQuanLyKho);

        // Khởi tạo jPanel9 (chức năng xuất kho)
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Chức năng"));

        btnThemXuat.setText("Thêm");
        btnThemXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemXuatActionPerformed(evt);
            }
        });

        btnSuaXuat.setText("Sửa");
        btnSuaXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaXuatActionPerformed(evt);
            }
        });

        btnXoaXuat.setText("Xóa");
        btnXoaXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaXuatActionPerformed(evt);
            }
        });

        btnLamMoiXuat.setText("Làm mới");
        btnLamMoiXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiXuatActionPerformed(evt);
            }
        });

        btnTimKiemXuat.setText("Tìm kiếm");
        btnTimKiemXuat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemXuatActionPerformed(evt);
            }
        });

        jLabel29.setText("Tìm kiếm:");

        lblThanhTienXuat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblThanhTienXuat.setForeground(new java.awt.Color(255, 0, 0));
        lblThanhTienXuat.setText("Thành tiền: 0 VNĐ");

        lblTonKho.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblTonKho.setForeground(new java.awt.Color(0, 128, 0));
        lblTonKho.setText("Tồn kho: 0");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnThemXuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnSuaXuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnXoaXuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnLamMoiXuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnTimKiemXuat, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel29)
                    .addComponent(txtTimKiemXuat, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThanhTienXuat)
                    .addComponent(lblTonKho))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(btnThemXuat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSuaXuat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnXoaXuat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnLamMoiXuat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTimKiemXuat))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel29)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtTimKiemXuat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblThanhTienXuat)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lblTonKho)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        // Khởi tạo jPanel10 (bảng xuất kho)
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách phiếu xuất"));

        tblXuatKho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã phiếu", "Kho", "Sản phẩm", "Số lượng", "Đơn giá", "Thành tiền", "Khách hàng", "Lý do", "Ngày xuất", "Trạng thái"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblXuatKho.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblXuatKhoMouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(tblXuatKho);

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 788, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout tabNhapKhoLayout = new javax.swing.GroupLayout(tabNhapKho);
        tabNhapKho.setLayout(tabNhapKhoLayout);
        tabNhapKhoLayout.setHorizontalGroup(
            tabNhapKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabNhapKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabNhapKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabNhapKhoLayout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        tabNhapKhoLayout.setVerticalGroup(
            tabNhapKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabNhapKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabNhapKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Nhập Kho", tabNhapKho);

        javax.swing.GroupLayout tabXuatKhoLayout = new javax.swing.GroupLayout(tabXuatKho);
        tabXuatKho.setLayout(tabXuatKhoLayout);
        tabXuatKhoLayout.setHorizontalGroup(
            tabXuatKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabXuatKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabXuatKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(tabXuatKhoLayout.createSequentialGroup()
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        tabXuatKhoLayout.setVerticalGroup(
            tabXuatKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabXuatKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabXuatKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Xuất Kho", tabXuatKho);

        // Khởi tạo components cho tab Tồn Kho
        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Bộ lọc tồn kho"));

        jLabel30.setText("Kho:");
        jLabel31.setText("Sản phẩm:");
        jLabel32.setText("Trạng thái:");

        cboTrangThaiTonKho.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tất cả", "Còn hàng", "Hết hàng", "Sắp hết" }));

        btnTimKiemTonKho.setText("Tìm kiếm");
        btnTimKiemTonKho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTimKiemTonKhoActionPerformed(evt);
            }
        });

        btnLamMoiTonKho.setText("Làm mới");
        btnLamMoiTonKho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLamMoiTonKhoActionPerformed(evt);
            }
        });

        btnBaoCaoTonKho.setText("Báo cáo");
        btnBaoCaoTonKho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBaoCaoTonKhoActionPerformed(evt);
            }
        });

        // Thêm nút đồng bộ tồn kho
        btnDongBoTonKho = new javax.swing.JButton();
        btnDongBoTonKho.setText("Đồng bộ");
        btnDongBoTonKho.setToolTipText("Đồng bộ tồn kho từ Kho sang Sản phẩm");
        btnDongBoTonKho.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDongBoTonKhoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel30)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboKhoTonKho, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel31)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboSanPhamTonKho, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel32)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboTrangThaiTonKho, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnTimKiemTonKho)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLamMoiTonKho)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnBaoCaoTonKho)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnDongBoTonKho)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(cboKhoTonKho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel31)
                    .addComponent(cboSanPhamTonKho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel32)
                    .addComponent(cboTrangThaiTonKho, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiemTonKho)
                    .addComponent(btnLamMoiTonKho)
                    .addComponent(btnBaoCaoTonKho)
                    .addComponent(btnDongBoTonKho))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Báo cáo tồn kho"));

        tblTonKho.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Kho", "Mã SP", "Tên sản phẩm", "SL Tồn", "SL Nhập", "SL Xuất", "Giá trị tồn", "Đơn giá TB", "Trạng thái", "Cập nhật"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Double.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane7.setViewportView(tblTonKho);

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane7, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
                .addContainerGap())
        );

        javax.swing.GroupLayout tabTonKhoLayout = new javax.swing.GroupLayout(tabTonKho);
        tabTonKho.setLayout(tabTonKhoLayout);
        tabTonKhoLayout.setHorizontalGroup(
            tabTonKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabTonKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(tabTonKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel11, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        tabTonKhoLayout.setVerticalGroup(
            tabTonKhoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(tabTonKhoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Tồn Kho", tabTonKho);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jTabbedPane1))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Quanlykho.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Quanlykho.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Quanlykho.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Quanlykho.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Quanlykho dialog = new Quanlykho(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBaoCaoTonKho;
    private javax.swing.JButton btnDongBoTonKho;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnLamMoiNhap;
    private javax.swing.JButton btnLamMoiTonKho;
    private javax.swing.JButton btnLamMoiXuat;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnSuaNhap;
    private javax.swing.JButton btnSuaXuat;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnThemNhap;
    private javax.swing.JButton btnThemXuat;
    private javax.swing.JButton btnThongKe;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnTimKiemNhap;
    private javax.swing.JButton btnTimKiemTonKho;
    private javax.swing.JButton btnTimKiemXuat;
    private javax.swing.JButton btnXoa;
    private javax.swing.JButton btnXoaNhap;
    private javax.swing.JButton btnXoaXuat;
    private javax.swing.JComboBox<String> cboKhoNhap;
    private javax.swing.JComboBox<String> cboKhoTonKho;
    private javax.swing.JComboBox<String> cboKhoXuat;
    private javax.swing.JComboBox<String> cboLyDoXuat;
    private javax.swing.JComboBox<String> cboSanPhamNhap;
    private javax.swing.JComboBox<String> cboSanPhamTonKho;
    private javax.swing.JComboBox<String> cboSanPhamXuat;
    private javax.swing.JComboBox<String> cboTrangThaiNhap;
    private javax.swing.JComboBox<String> cboTrangThaiTonKho;
    private javax.swing.JComboBox<String> cboTrangThaiXuat;
    private javax.swing.JCheckBox chkTrangThai;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblThanhTienNhap;
    private javax.swing.JLabel lblThanhTienXuat;
    private javax.swing.JLabel lblTonKho;
    private javax.swing.JPanel tabNhapKho;
    private javax.swing.JPanel tabQuanLyKho;
    private javax.swing.JPanel tabTonKho;
    private javax.swing.JPanel tabXuatKho;
    private javax.swing.JTable tblKho;
    private javax.swing.JTable tblNhapKho;
    private javax.swing.JTable tblTonKho;
    private javax.swing.JTable tblXuatKho;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtDonGiaNhap;
    private javax.swing.JTextField txtDonGiaXuat;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextArea txtGhiChuNhap;
    private javax.swing.JTextArea txtGhiChuXuat;
    private javax.swing.JTextField txtKhachHang;
    private javax.swing.JTextField txtMaKho;
    private javax.swing.JTextField txtMaPhieuNhap;
    private javax.swing.JTextField txtMaPhieuXuat;
    private javax.swing.JTextArea txtMoTa;
    private javax.swing.JTextField txtNguoiQuanLy;
    private javax.swing.JTextField txtNhaCungCap;
    private javax.swing.JTextField txtSoDienThoai;
    private javax.swing.JTextField txtSoLuongNhap;
    private javax.swing.JTextField txtSoLuongXuat;
    private javax.swing.JTextField txtTenKho;
    private javax.swing.JTextField txtTimKiem;
    private javax.swing.JTextField txtTimKiemNhap;
    private javax.swing.JTextField txtTimKiemXuat;
    // End of variables declaration//GEN-END:variables
}
