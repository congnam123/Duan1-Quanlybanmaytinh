package maytinh.dao;

import java.util.List;
import maytinh.entity.LichSu1;

public interface LichSuDAO {

    // CRUD operations
    LichSu1 create(LichSu1 entity);
    void update(LichSu1 entity);
    void deleteById(Integer id);
    List<LichSu1> findAll();
    LichSu1 findById(Integer id);

    // Custom methods
    List<LichSu1> getLichSuByUsername(String username);
    List<LichSu1> selectByUsername(String username);
    List<LichSu1> searchByDateRange(String username, String from, String to);
    void deleteLichSuByUsername(String username);

    // Admin methods
    List<LichSu1> searchByKeyword(String keyword);
    List<LichSu1> selectByStatus(String status);
    List<LichSu1> selectByMaDonHang(String maDonHang);
    LichSu1 findByMaDonHang(String maDonHang);

    // 🔥 Thêm phương thức mới cho DonHangController
    List<LichSu1> findAllByMaDonHang(String maDonHang);
}
