package maytinh.util;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;
import javax.imageio.ImageIO;

/**
 * Utility class cho quản lý hình ảnh
 * @author Admin
 */
public class ImageUtil {
    
    // Thư mục lưu hình ảnh
    private static final String IMAGE_DIRECTORY = "src/main/resources/images/products/";
    private static final String DEFAULT_IMAGE = "default.jpg";
    
    // Kích thước ảnh chuẩn
    private static final int PREVIEW_WIDTH = 150;
    private static final int PREVIEW_HEIGHT = 150;
    private static final int THUMBNAIL_WIDTH = 100;
    private static final int THUMBNAIL_HEIGHT = 100;
    
    /**
     * Tạo thư mục images nếu chưa tồn tại
     */
    public static void createImageDirectory() {
        try {
            Path path = Paths.get(IMAGE_DIRECTORY);
            if (!Files.exists(path)) {
                Files.createDirectories(path);
                System.out.println("Đã tạo thư mục: " + IMAGE_DIRECTORY);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * Chọn file hình ảnh từ hệ thống
     * @param parent Component cha
     * @return File được chọn hoặc null
     */
    public static File chooseImageFile(Component parent) {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setDialogTitle("Chọn hình ảnh sản phẩm");
        
        // Chỉ cho phép chọn file ảnh
        FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "Hình ảnh (*.jpg, *.jpeg, *.png, *.gif)", 
            "jpg", "jpeg", "png", "gif"
        );
        fileChooser.setFileFilter(filter);
        fileChooser.setAcceptAllFileFilterUsed(false);
        
        // Mở thư mục Pictures mặc định
        String userHome = System.getProperty("user.home");
        File picturesDir = new File(userHome, "Pictures");
        if (picturesDir.exists()) {
            fileChooser.setCurrentDirectory(picturesDir);
        }
        
        int result = fileChooser.showOpenDialog(parent);
        if (result == JFileChooser.APPROVE_OPTION) {
            return fileChooser.getSelectedFile();
        }
        return null;
    }
    
    /**
     * Lưu file ảnh vào thư mục images với tên unique
     * @param sourceFile File ảnh gốc
     * @return Tên file đã lưu hoặc null nếu lỗi
     */
    public static String saveImageFile(File sourceFile) {
        if (sourceFile == null || !sourceFile.exists()) {
            return null;
        }
        
        try {
            createImageDirectory();
            
            // Tạo tên file unique
            String extension = getFileExtension(sourceFile.getName());
            String fileName = UUID.randomUUID().toString() + "." + extension;
            
            // Copy file vào thư mục images
            Path sourcePath = sourceFile.toPath();
            Path targetPath = Paths.get(IMAGE_DIRECTORY + fileName);
            
            Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
            
            System.out.println("Đã lưu ảnh: " + fileName);
            return fileName;
            
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    /**
     * Tạo ImageIcon từ file ảnh với kích thước cố định
     * @param imageName Tên file ảnh
     * @param width Chiều rộng
     * @param height Chiều cao
     * @return ImageIcon hoặc null
     */
    public static ImageIcon createImageIcon(String imageName, int width, int height) {
        if (imageName == null || imageName.trim().isEmpty()) {
            imageName = DEFAULT_IMAGE;
        }
        
        try {
            String imagePath = IMAGE_DIRECTORY + imageName;
            File imageFile = new File(imagePath);
            
            if (!imageFile.exists()) {
                // Nếu không tìm thấy ảnh, dùng ảnh mặc định
                imagePath = IMAGE_DIRECTORY + DEFAULT_IMAGE;
                imageFile = new File(imagePath);
                
                if (!imageFile.exists()) {
                    // Tạo ảnh placeholder nếu không có ảnh mặc định
                    return createPlaceholderIcon(width, height);
                }
            }
            
            BufferedImage originalImage = ImageIO.read(imageFile);
            Image scaledImage = originalImage.getScaledInstance(width, height, Image.SCALE_SMOOTH);
            return new ImageIcon(scaledImage);
            
        } catch (IOException e) {
            e.printStackTrace();
            return createPlaceholderIcon(width, height);
        }
    }
    
    /**
     * Tạo ImageIcon preview (150x150)
     * @param imageName Tên file ảnh
     * @return ImageIcon preview
     */
    public static ImageIcon createPreviewIcon(String imageName) {
        return createImageIcon(imageName, PREVIEW_WIDTH, PREVIEW_HEIGHT);
    }

    /**
     * Tạo ImageIcon preview với kích thước tùy chỉnh
     * @param imageName Tên file ảnh
     * @param width Chiều rộng
     * @param height Chiều cao
     * @return ImageIcon preview
     */
    public static ImageIcon createPreviewIcon(String imageName, int width, int height) {
        return createImageIcon(imageName, width, height);
    }
    
    /**
     * Tạo ImageIcon thumbnail (100x100)
     * @param imageName Tên file ảnh
     * @return ImageIcon thumbnail
     */
    public static ImageIcon createThumbnailIcon(String imageName) {
        return createImageIcon(imageName, THUMBNAIL_WIDTH, THUMBNAIL_HEIGHT);
    }
    
    /**
     * Tạo placeholder icon khi không có ảnh
     * @param width Chiều rộng
     * @param height Chiều cao
     * @return ImageIcon placeholder
     */
    private static ImageIcon createPlaceholderIcon(int width, int height) {
        BufferedImage placeholder = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = placeholder.createGraphics();
        
        // Vẽ background xám
        g2d.setColor(Color.LIGHT_GRAY);
        g2d.fillRect(0, 0, width, height);
        
        // Vẽ border
        g2d.setColor(Color.GRAY);
        g2d.drawRect(0, 0, width - 1, height - 1);
        
        // Vẽ text "No Image"
        g2d.setColor(Color.DARK_GRAY);
        g2d.setFont(new Font("Arial", Font.BOLD, 12));
        FontMetrics fm = g2d.getFontMetrics();
        String text = "No Image";
        int textWidth = fm.stringWidth(text);
        int textHeight = fm.getHeight();
        g2d.drawString(text, (width - textWidth) / 2, (height + textHeight) / 2 - 3);
        
        g2d.dispose();
        return new ImageIcon(placeholder);
    }
    
    /**
     * Lấy extension của file
     * @param fileName Tên file
     * @return Extension (không có dấu chấm)
     */
    private static String getFileExtension(String fileName) {
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1).toLowerCase();
        }
        return "jpg"; // Default extension
    }
    
    /**
     * Xóa file ảnh
     * @param imageName Tên file ảnh cần xóa
     * @return true nếu xóa thành công
     */
    public static boolean deleteImageFile(String imageName) {
        if (imageName == null || imageName.equals(DEFAULT_IMAGE)) {
            return false; // Không xóa ảnh mặc định
        }
        
        try {
            Path imagePath = Paths.get(IMAGE_DIRECTORY + imageName);
            return Files.deleteIfExists(imagePath);
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Kiểm tra file ảnh có tồn tại không
     * @param imageName Tên file ảnh
     * @return true nếu tồn tại
     */
    public static boolean imageExists(String imageName) {
        if (imageName == null || imageName.trim().isEmpty()) {
            return false;
        }
        
        File imageFile = new File(IMAGE_DIRECTORY + imageName);
        return imageFile.exists();
    }
}
