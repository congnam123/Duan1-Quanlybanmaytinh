package maytinh.dao;

import maytinh.entity.TonKho;
import java.util.List;

/**
 * DAO interface cho quản lý tồn kho
 */
public interface TonKhoDAO extends CrudDao<TonKho, String> {
    
    /**
     * Tìm tồn kho theo mã kho và mã sản phẩm
     */
    TonKho findByKhoAndSanPham(String maKho, String maSanPham);
    
    /**
     * Tìm tồn kho theo mã kho
     */
    List<TonKho> findByKho(String maKho);
    
    /**
     * Tìm tồn kho theo mã sản phẩm
     */
    List<TonKho> findBySanPham(String maSanPham);
    
    /**
     * Tìm tồn kho theo trạng thái
     */
    List<TonKho> findByTrangThai(String trangThai);
    
    /**
     * Cập nhật số lượng tồn kho
     */
    void updateSoLuongTon(String maKho, String maSanPham, int soLuongMoi);
    
    /**
     * Tìm kiếm tồn kho theo từ khóa
     */
    List<TonKho> search(String keyword);
}
