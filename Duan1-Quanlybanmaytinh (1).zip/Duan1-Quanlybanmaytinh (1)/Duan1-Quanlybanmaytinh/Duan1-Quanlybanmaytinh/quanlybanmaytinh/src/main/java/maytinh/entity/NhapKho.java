package maytinh.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Entity class cho Nhập Kho
 * @author Cong Nam
 */
public class NhapKho {
    private String maPhieuNhap;
    private String maKho;
    private String maSanPham;
    private String tenSanPham;
    private int soLuongNhap;
    private BigDecimal donGiaNhap;
    private BigDecimal thanhTien;
    private String nhaCungCap;
    private String nguoiNhap;
    private Date ngayNhap;
    private String ghiChu;
    private String trangThai; // "Đã nhập", "Chờ xử lý", "Hủy"
    private Date ngayTao;
    private Date ngayCapNhat;

    // Constructor mặc định
    public NhapKho() {
        this.ngayTao = new Date();
        this.ngayCapNhat = new Date();
        this.trangThai = "Chờ xử lý";
    }

    // Constructor đầy đủ
    public NhapKho(String maPhieuNhap, String maKho, String maSanPham, int soLuongNhap, BigDecimal donGiaNhap) {
        this();
        this.maPhieuNhap = maPhieuNhap;
        this.maKho = maKho;
        this.maSanPham = maSanPham;
        this.soLuongNhap = soLuongNhap;
        this.donGiaNhap = donGiaNhap;
        this.thanhTien = donGiaNhap.multiply(new BigDecimal(soLuongNhap));
    }

    // Getter và Setter methods
    public String getMaPhieuNhap() {
        return maPhieuNhap;
    }

    public void setMaPhieuNhap(String maPhieuNhap) {
        this.maPhieuNhap = maPhieuNhap;
    }

    public String getMaKho() {
        return maKho;
    }

    public void setMaKho(String maKho) {
        this.maKho = maKho;
    }

    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuongNhap() {
        return soLuongNhap;
    }

    public void setSoLuongNhap(int soLuongNhap) {
        this.soLuongNhap = soLuongNhap;
        if (this.donGiaNhap != null) {
            this.thanhTien = this.donGiaNhap.multiply(new BigDecimal(soLuongNhap));
        }
    }

    public BigDecimal getDonGiaNhap() {
        return donGiaNhap;
    }

    public void setDonGiaNhap(BigDecimal donGiaNhap) {
        this.donGiaNhap = donGiaNhap;
        if (this.soLuongNhap > 0) {
            this.thanhTien = donGiaNhap.multiply(new BigDecimal(this.soLuongNhap));
        }
    }

    public BigDecimal getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(BigDecimal thanhTien) {
        this.thanhTien = thanhTien;
    }

    public String getNhaCungCap() {
        return nhaCungCap;
    }

    public void setNhaCungCap(String nhaCungCap) {
        this.nhaCungCap = nhaCungCap;
    }

    public String getNguoiNhap() {
        return nguoiNhap;
    }

    public void setNguoiNhap(String nguoiNhap) {
        this.nguoiNhap = nguoiNhap;
    }

    public Date getNgayNhap() {
        return ngayNhap;
    }

    public void setNgayNhap(Date ngayNhap) {
        this.ngayNhap = ngayNhap;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(Date ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    @Override
    public String toString() {
        return "NhapKho{" +
                "maPhieuNhap='" + maPhieuNhap + '\'' +
                ", maKho='" + maKho + '\'' +
                ", maSanPham='" + maSanPham + '\'' +
                ", tenSanPham='" + tenSanPham + '\'' +
                ", soLuongNhap=" + soLuongNhap +
                ", donGiaNhap=" + donGiaNhap +
                ", thanhTien=" + thanhTien +
                ", nhaCungCap='" + nhaCungCap + '\'' +
                ", nguoiNhap='" + nguoiNhap + '\'' +
                ", ngayNhap=" + ngayNhap +
                ", trangThai='" + trangThai + '\'' +
                '}';
    }
}
