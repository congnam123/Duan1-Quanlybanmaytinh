package maytinh.controller;

/**
 * Controller interface cho Quản lý sản phẩm
 */
public interface QuanlysanphamController {
    
    /**
     * Load danh sách laptop lên table
     */
    void loadLaptopList();
    
    /**
     * Load thông tin laptop lên form
     */
    void loadLaptopInfo();
    
    /**
     * Thêm laptop mới
     */
    void addLaptop();
    
    /**
     * Cập nhật thông tin laptop
     */
    void updateLaptop();
    
    /**
     * Xóa laptop
     */
    void deleteLaptop();
    
    /**
     * Tìm kiếm laptop
     */
    void searchLaptop();
    
    /**
     * Làm mới form
     */
    void refreshForm();
    
    /**
     * Validate dữ liệu đầu vào
     */
    boolean validateData();
    
    /**
     * Xóa dữ liệu trên form
     */
    void clearForm();
    
    /**
     * Kiểm tra quyền truy cập
     */
    boolean checkPermission();
    
    /**
     * Xuất danh sách ra Excel
     */
    void exportToExcel();
    
    /**
     * Import danh sách từ Excel
     */
    void importFromExcel();
}
