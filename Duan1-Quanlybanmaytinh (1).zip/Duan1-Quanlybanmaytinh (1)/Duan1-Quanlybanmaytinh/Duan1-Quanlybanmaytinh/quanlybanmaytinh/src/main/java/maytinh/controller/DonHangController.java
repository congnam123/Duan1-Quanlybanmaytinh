package maytinh.controller;

import maytinh.dao.LichSuDAO;
import maytinh.entity.LichSu1;
import maytinh.entity.GioHang;
import maytinh.entity.XuatKho;
import maytinh.util.XDialog;
import maytinh.util.XJdbc;
import maytinh.impl.LichSuDAOImpl;
import java.util.List;
import java.util.Date;
import java.math.BigDecimal;

/**
 * Controller xử lý logic đặt hàng và cập nhật tồn kho
 * @author Cong Nam
 */
public class DonHangController {
    
    private LichSuDAO lichSuDAO;
    private NhapXuatKhoController nhapXuatController;
    
    public DonHangController() {
        this.lichSuDAO = new LichSuDAOImpl();
        this.nhapXuatController = new NhapXuatKhoController();
    }
    
    /**
     * Xử lý đặt hàng - Trừ tồn kho khi đặt hàng
     */
    public boolean datHang(List<GioHang> cartItems, String username, String paymentMethod) {
        try {
            System.out.println("🛒 BẮT ĐẦU ĐẶT HÀNG - DonHangController.datHang()");
            System.out.println("   - Username: " + username);
            System.out.println("   - Payment: " + paymentMethod);
            System.out.println("   - Số sản phẩm: " + cartItems.size());

            // Kiểm tra tồn kho trước khi đặt hàng
            for (GioHang item : cartItems) {
                System.out.println("   - Kiểm tra: " + item.getTenSP() + " (SP" + item.getMaSP() + ") - SL: " + item.getSoLuong());
                if (!kiemTraTonKho(item.getMaSP(), item.getSoLuong())) {
                    String errorMsg = "Sản phẩm '" + item.getTenSP() + "' không đủ hàng trong kho!\n" +
                                    "Tồn kho hiện tại: " + getTonKhoHienTai(item.getMaSP()) +
                                    ", Yêu cầu: " + item.getSoLuong();
                    System.out.println("❌ " + errorMsg);
                    XDialog.alert(errorMsg);
                    return false;
                }
            }
            
            // Tạo mã đơn hàng
            String maDonHang = "DH" + System.currentTimeMillis();
            
            // Xác định trạng thái dựa trên phương thức thanh toán
            String trangThai;
            if ("Chuyển khoản".equals(paymentMethod)) {
                trangThai = "Chờ thanh toán";
            } else if ("COD".equals(paymentMethod)) {
                trangThai = "Đã đặt hàng";
            } else {
                trangThai = "Chờ xác nhận";
            }
            
            // Tạo đơn hàng và trừ tồn kho
            for (GioHang item : cartItems) {
                // 1. Tạo bản ghi lịch sử
                LichSu1 lichSu = new LichSu1();
                lichSu.setMaDonHang(maDonHang);
                lichSu.setTenSanPham(item.getTenSP());
                lichSu.setSoLuong(item.getSoLuong());
                lichSu.setDonGia(item.getGia());
                lichSu.setTrangThai(trangThai);
                lichSu.setNgayMua(new Date());
                lichSu.setUsername(username);
                
                lichSuDAO.create(lichSu);
                
                // 2. 🔥 QUAN TRỌNG: Tạo phiếu xuất kho tự động
                taoPhieuXuatKhoTuDong(item, maDonHang, username);
                
                System.out.println("✅ Đã đặt hàng và trừ tồn kho: " + item.getTenSP() + " (-" + item.getSoLuong() + ")");
            }
            
            System.out.println("🎉 Đặt hàng thành công: " + maDonHang + " (" + cartItems.size() + " sản phẩm)");
            return true;
            
        } catch (Exception e) {
            System.err.println("❌ Lỗi khi đặt hàng: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Xử lý hủy đơn hàng - Hoàn lại tồn kho
     */
    public boolean huyDonHang(String maDonHang) {
        try {
            System.out.println("🔄 Bắt đầu hủy đơn hàng: " + maDonHang);

            // Lấy danh sách sản phẩm trong đơn hàng
            List<LichSu1> danhSachSanPham = lichSuDAO.findAllByMaDonHang(maDonHang);
            System.out.println("📋 Tìm thấy " + danhSachSanPham.size() + " sản phẩm trong đơn hàng");

            if (danhSachSanPham.isEmpty()) {
                System.err.println("❌ Không tìm thấy đơn hàng: " + maDonHang);
                XDialog.alert("Không tìm thấy đơn hàng: " + maDonHang);
                return false;
            }

            // In ra thông tin các sản phẩm
            for (LichSu1 item : danhSachSanPham) {
                System.out.println("📦 Sản phẩm: " + item.getTenSanPham() + " - SL: " + item.getSoLuong() + " - Trạng thái: " + item.getTrangThai());
            }

            // Kiểm tra trạng thái đơn hàng
            String trangThaiHienTai = danhSachSanPham.get(0).getTrangThai();
            System.out.println("🔍 Trạng thái hiện tại: " + trangThaiHienTai);

            if ("Đã giao thành công".equals(trangThaiHienTai) || "Đã hủy".equals(trangThaiHienTai)) {
                System.err.println("❌ Không thể hủy đơn hàng đã " + trangThaiHienTai.toLowerCase());
                XDialog.alert("Không thể hủy đơn hàng đã " + trangThaiHienTai.toLowerCase() + "!");
                return false;
            }

            // Hoàn lại tồn kho cho từng sản phẩm
            for (LichSu1 item : danhSachSanPham) {
                System.out.println("🔄 Xử lý sản phẩm: " + item.getTenSanPham() + " (+" + item.getSoLuong() + ")");

                // 1. 🔥 QUAN TRỌNG: Hoàn lại tồn kho
                hoanLaiTonKho(item.getTenSanPham(), item.getSoLuong(), "Hủy đơn: " + maDonHang);

                // 2. Cập nhật trạng thái đơn hàng
                item.setTrangThai("Đã hủy");
                lichSuDAO.update(item);

                System.out.println("✅ Đã hủy đơn và hoàn tồn kho: " + item.getTenSanPham() + " (+" + item.getSoLuong() + ")");
            }

            System.out.println("🎉 Hủy đơn hàng thành công: " + maDonHang + " (" + danhSachSanPham.size() + " sản phẩm)");
            return true;

        } catch (Exception e) {
            System.err.println("❌ Lỗi khi hủy đơn hàng: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * 🔥 SỬA LẠI: Cập nhật trạng thái CHỈ SẢN PHẨM ĐƯỢC CHỌN (không ảnh hưởng sản phẩm khác)
     */
    public boolean capNhatTrangThai(int maDH, String trangThaiMoi) {
        try {
            // Lấy thông tin sản phẩm được chọn
            LichSu1 order = lichSuDAO.findById(maDH);
            if (order == null) {
                XDialog.alert("Không tìm thấy đơn hàng!");
                return false;
            }

            String trangThaiCu = order.getTrangThai();
            String maDonHang = order.getMaDonHang();
            String tenSanPham = order.getTenSanPham();

            System.out.println("🔄 Cập nhật trạng thái sản phẩm riêng lẻ:");
            System.out.println("   - MaDH: " + maDH);
            System.out.println("   - MaDonHang: " + maDonHang);
            System.out.println("   - Sản phẩm: " + tenSanPham);
            System.out.println("   - Trạng thái: " + trangThaiCu + " → " + trangThaiMoi);

            // 🔥 CHỈ CẬP NHẬT SẢN PHẨM ĐƯỢC CHỌN
            order.setTrangThai(trangThaiMoi);
            lichSuDAO.update(order);

            System.out.println("✅ Đã cập nhật trạng thái sản phẩm: " + tenSanPham + " (MaDH: " + maDH + ")");

            // Hiển thị thông tin các sản phẩm khác trong cùng đơn hàng (để debug)
            List<LichSu1> cacSanPhamKhac = lichSuDAO.findAllByMaDonHang(maDonHang);
            System.out.println("📋 Trạng thái các sản phẩm trong đơn " + maDonHang + ":");
            for (LichSu1 sp : cacSanPhamKhac) {
                String status = sp.getMaDH() == maDH ? "← VỪA CẬP NHẬT" : "";
                System.out.println("   - " + sp.getTenSanPham() + ": " + sp.getTrangThai() + " " + status);
            }

            return true;

        } catch (Exception e) {
            System.err.println("❌ Lỗi cập nhật trạng thái: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }
    
    // ==================== HELPER METHODS ====================
    
    /**
     * Kiểm tra tồn kho có đủ không
     */
    private boolean kiemTraTonKho(int maSP, int soLuongYeuCau) {
        try {
            String sql = "SELECT SoLuongTon FROM SanPham WHERE MaSP = ?";
            java.sql.ResultSet rs = XJdbc.executeQuery(sql, maSP);
            if (rs.next()) {
                int tonKho = rs.getInt("SoLuongTon");
                return tonKho >= soLuongYeuCau;
            }
            return false;
        } catch (Exception e) {
            System.err.println("❌ Lỗi kiểm tra tồn kho: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Lấy tồn kho hiện tại
     */
    private int getTonKhoHienTai(int maSP) {
        try {
            String sql = "SELECT SoLuongTon FROM SanPham WHERE MaSP = ?";
            java.sql.ResultSet rs = XJdbc.executeQuery(sql, maSP);
            if (rs.next()) {
                return rs.getInt("SoLuongTon");
            }
            return 0;
        } catch (Exception e) {
            return 0;
        }
    }
    
    /**
     * Trừ tồn kho khi đặt hàng
     */
    private void truTonKho(int maSP, int soLuong, String ghiChu) {
        try {
            System.out.println("🔧 TRỪ TỒN KHO:");
            System.out.println("   - Sản phẩm: SP" + maSP);
            System.out.println("   - Số lượng trừ: " + soLuong);
            System.out.println("   - Ghi chú: " + ghiChu);

            // Kiểm tra tồn kho hiện tại trước khi trừ
            String checkSql = "SELECT TenSP, SoLuongTon FROM SanPham WHERE MaSP = ?";
            java.sql.ResultSet rs = XJdbc.executeQuery(checkSql, maSP);
            if (rs.next()) {
                String tenSP = rs.getString("TenSP");
                int tonHienTai = rs.getInt("SoLuongTon");
                System.out.println("   - Tồn kho hiện tại: " + tenSP + " = " + tonHienTai);

                if (tonHienTai < soLuong) {
                    System.err.println("❌ KHÔNG ĐỦ HÀNG: Cần " + soLuong + ", chỉ có " + tonHienTai);
                    return;
                }
            }

            // Cập nhật SanPham
            String sql = "UPDATE SanPham SET SoLuongTon = SoLuongTon - ? WHERE MaSP = ? AND SoLuongTon >= ?";
            System.out.println("   - SQL: " + sql);
            System.out.println("   - Params: [" + soLuong + ", " + maSP + ", " + soLuong + "]");

            int rowsAffected = XJdbc.executeUpdate(sql, soLuong, maSP, soLuong);
            System.out.println("   - Rows affected: " + rowsAffected);

            if (rowsAffected > 0) {
                // Kiểm tra kết quả sau khi trừ
                java.sql.ResultSet rs2 = XJdbc.executeQuery("SELECT SoLuongTon FROM SanPham WHERE MaSP = ?", maSP);
                if (rs2.next()) {
                    int tonMoi = rs2.getInt("SoLuongTon");
                    System.out.println("   - Tồn kho sau khi trừ: " + tonMoi);
                }

                // Đồng bộ với TonKho và Kho
                nhapXuatController.updateTonKhoSanPham(String.valueOf(maSP));
                System.out.println("✅ Trừ tồn kho thành công: SP" + maSP + " (-" + soLuong + ") - " + ghiChu);
            } else {
                System.err.println("❌ Không thể trừ tồn kho: SP" + maSP + " - Không đủ hàng hoặc lỗi SQL");
            }
        } catch (Exception e) {
            System.err.println("❌ Lỗi trừ tồn kho: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Hoàn lại tồn kho khi hủy đơn
     */
    /**
     * 🔥 SỬA MỚI: Hoàn trả tồn kho bằng cách tạo phiếu nhập kho
     */
    private void hoanLaiTonKho(String tenSanPham, int soLuong, String ghiChu) {
        try {
            System.out.println("🔄 Bắt đầu hoàn trả tồn kho qua phiếu nhập: '" + tenSanPham + "' (+" + soLuong + ")");

            // Tìm MaSP từ tên sản phẩm
            String maSP = timMaSanPham(tenSanPham);
            if (maSP == null) {
                System.err.println("❌ Không tìm thấy sản phẩm: " + tenSanPham);
                return;
            }

            System.out.println("✅ Tìm thấy sản phẩm: SP" + maSP + " - " + tenSanPham);

            // Tạo phiếu nhập kho để hoàn trả
            taoPhieuNhapHoanTra(maSP, tenSanPham, soLuong, ghiChu);

        } catch (Exception e) {
            System.err.println("❌ Lỗi hoàn trả tồn kho: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Tìm MaSP từ tên sản phẩm với nhiều cách khác nhau
     */
    private String timMaSanPham(String tenSanPham) {
        try {
            // Cách 1: Tìm chính xác
            String sqlFind = "SELECT MaSP FROM SanPham WHERE TenSP = ?";
            java.sql.ResultSet rs = XJdbc.executeQuery(sqlFind, tenSanPham);
            if (rs.next()) {
                String maSP = String.valueOf(rs.getInt("MaSP"));
                System.out.println("✅ Tìm thấy chính xác: SP" + maSP);
                return maSP;
            }

            // Cách 2: Tìm với TRIM
            String sqlTrim = "SELECT MaSP FROM SanPham WHERE LTRIM(RTRIM(TenSP)) = LTRIM(RTRIM(?))";
            java.sql.ResultSet rsTrim = XJdbc.executeQuery(sqlTrim, tenSanPham);
            if (rsTrim.next()) {
                String maSP = String.valueOf(rsTrim.getInt("MaSP"));
                System.out.println("✅ Tìm thấy với TRIM: SP" + maSP);
                return maSP;
            }

            // Cách 3: Tìm với LIKE (đặc biệt cho Dell OptiPlex)
            if (tenSanPham.contains("Dell OptiPlex")) {
                String sqlLike = "SELECT MaSP FROM SanPham WHERE TenSP LIKE ?";
                java.sql.ResultSet rsLike = XJdbc.executeQuery(sqlLike, "%Dell OptiPlex%");
                if (rsLike.next()) {
                    String maSP = String.valueOf(rsLike.getInt("MaSP"));
                    System.out.println("✅ Tìm thấy Dell OptiPlex với LIKE: SP" + maSP);
                    return maSP;
                }
            }

            return null;
        } catch (Exception e) {
            System.err.println("❌ Lỗi tìm MaSP: " + e.getMessage());
            return null;
        }
    }

    /**
     * Tạo phiếu nhập kho để hoàn trả hàng
     */
    private void taoPhieuNhapHoanTra(String maSP, String tenSanPham, int soLuong, String ghiChu) {
        try {
            // Tạo đối tượng NhapKho
            maytinh.entity.NhapKho nhapKho = new maytinh.entity.NhapKho();

            // Tạo mã phiếu nhập tự động
            String maPhieuNhap = nhapXuatController.generateMaPhieuNhap();
            nhapKho.setMaPhieuNhap(maPhieuNhap);

            // Thông tin cơ bản
            nhapKho.setMaKho("KHO001"); // Kho mặc định
            nhapKho.setMaSanPham(maSP);
            nhapKho.setTenSanPham(tenSanPham);
            nhapKho.setSoLuongNhap(soLuong);

            // Giá nhập = 0 (vì là hoàn trả)
            nhapKho.setDonGiaNhap(java.math.BigDecimal.ZERO);
            nhapKho.setThanhTien(java.math.BigDecimal.ZERO);

            // Thông tin hoàn trả
            nhapKho.setNhaCungCap("Hoàn trả từ khách hàng");
            nhapKho.setNguoiNhap(maytinh.util.XAuth.user != null ? maytinh.util.XAuth.user.getFullname() : "Hệ thống");
            nhapKho.setGhiChu(ghiChu);
            nhapKho.setTrangThai("Đã nhập"); // Tự động nhập luôn

            // Thêm phiếu nhập qua controller
            boolean success = nhapXuatController.addNhapKho(nhapKho);

            if (success) {
                System.out.println("✅ Tạo phiếu nhập hoàn trả thành công: " + maPhieuNhap);
                System.out.println("📦 Đã hoàn trả " + soLuong + " " + tenSanPham + " về kho");
            } else {
                System.err.println("❌ Tạo phiếu nhập hoàn trả thất bại");
            }

        } catch (Exception e) {
            System.err.println("❌ Lỗi tạo phiếu nhập hoàn trả: " + e.getMessage());
            e.printStackTrace();
        }
    }



    /**
     * 🔥 TẠO PHIẾU XUẤT KHO TỰ ĐỘNG KHI ĐẶT HÀNG
     */
    private void taoPhieuXuatKhoTuDong(GioHang item, String maDonHang, String username) {
        try {
            System.out.println("📦 TẠO PHIẾU XUẤT KHO TỰ ĐỘNG:");
            System.out.println("   - Sản phẩm: " + item.getTenSP() + " (SP" + item.getMaSP() + ")");
            System.out.println("   - Số lượng: " + item.getSoLuong());
            System.out.println("   - Đơn hàng: " + maDonHang);

            // Tạo đối tượng XuatKho
            XuatKho xuatKho = new XuatKho();
            xuatKho.setMaPhieuXuat("PX" + System.currentTimeMillis() + "_" + item.getMaSP());
            xuatKho.setMaKho("KHO001"); // Mặc định xuất từ kho chính
            xuatKho.setMaSanPham(String.valueOf(item.getMaSP()));
            xuatKho.setTenSanPham(item.getTenSP());
            xuatKho.setSoLuongXuat(item.getSoLuong());
            xuatKho.setDonGiaXuat(BigDecimal.valueOf(item.getGia()));
            xuatKho.setThanhTien(BigDecimal.valueOf(item.getGia() * item.getSoLuong()));
            xuatKho.setLyDoXuat("Bán hàng - Đơn: " + maDonHang);
            xuatKho.setKhachHang(username); // 🔥 LƯU TÊN KHÁCH HÀNG
            xuatKho.setNguoiXuat("Hệ thống");
            xuatKho.setNgayXuat(new Date());
            xuatKho.setTrangThai("Đã xuất"); // 🔥 QUAN TRỌNG: Đã xuất để trừ tồn kho

            // Sử dụng NhapXuatKhoController để tạo phiếu xuất
            boolean thanhCong = nhapXuatController.addXuatKho(xuatKho);

            if (thanhCong) {
                System.out.println("✅ Tạo phiếu xuất kho thành công: " + xuatKho.getMaPhieuXuat());
                System.out.println("   - Tồn kho đã được trừ tự động qua NhapXuatKhoController");
            } else {
                System.err.println("❌ Không thể tạo phiếu xuất kho cho SP" + item.getMaSP());
            }

        } catch (Exception e) {
            System.err.println("❌ Lỗi tạo phiếu xuất kho: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
