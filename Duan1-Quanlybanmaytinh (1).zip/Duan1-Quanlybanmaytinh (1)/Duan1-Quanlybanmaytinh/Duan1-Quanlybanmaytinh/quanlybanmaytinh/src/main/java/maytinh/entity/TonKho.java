package maytinh.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Entity class cho Tồn Kho
 * @author Cong Nam
 */
public class TonKho {
    private String maKho;
    private String tenKho;
    private String maSanPham;
    private String tenSanPham;
    private int soLuongTon;
    private int soLuongNhap;
    private int soLuongXuat;
    private BigDecimal giaTriTon;
    private BigDecimal donGiaTrungBinh;
    private Date ngayCapNhat;
    private String trangThai; // "Còn hàng", "Hết hàng", "Sắp hết"

    // Constructor mặc định
    public TonKho() {
        this.ngayCapNhat = new Date();
        this.soLuongTon = 0;
        this.soLuongNhap = 0;
        this.soLuongXuat = 0;
        this.giaTriTon = BigDecimal.ZERO;
        this.donGiaTrungBinh = BigDecimal.ZERO;
        this.trangThai = "Hết hàng";
    }

    // Constructor đầy đủ
    public TonKho(String maKho, String maSanPham, int soLuongTon) {
        this();
        this.maKho = maKho;
        this.maSanPham = maSanPham;
        this.soLuongTon = soLuongTon;
        updateTrangThai();
    }

    // Getter và Setter methods
    public String getMaKho() {
        return maKho;
    }

    public void setMaKho(String maKho) {
        this.maKho = maKho;
    }

    public String getTenKho() {
        return tenKho;
    }

    public void setTenKho(String tenKho) {
        this.tenKho = tenKho;
    }

    public String getMaSanPham() {
        return maSanPham;
    }

    public void setMaSanPham(String maSanPham) {
        this.maSanPham = maSanPham;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuongTon() {
        return soLuongTon;
    }

    public void setSoLuongTon(int soLuongTon) {
        this.soLuongTon = soLuongTon;
        updateTrangThai();
        updateGiaTriTon();
    }

    public int getSoLuongNhap() {
        return soLuongNhap;
    }

    public void setSoLuongNhap(int soLuongNhap) {
        this.soLuongNhap = soLuongNhap;
    }

    public int getSoLuongXuat() {
        return soLuongXuat;
    }

    public void setSoLuongXuat(int soLuongXuat) {
        this.soLuongXuat = soLuongXuat;
    }

    public BigDecimal getGiaTriTon() {
        return giaTriTon;
    }

    public void setGiaTriTon(BigDecimal giaTriTon) {
        this.giaTriTon = giaTriTon;
    }

    public BigDecimal getDonGiaTrungBinh() {
        return donGiaTrungBinh;
    }

    public void setDonGiaTrungBinh(BigDecimal donGiaTrungBinh) {
        this.donGiaTrungBinh = donGiaTrungBinh;
        updateGiaTriTon();
    }

    public Date getNgayCapNhat() {
        return ngayCapNhat;
    }

    public void setNgayCapNhat(Date ngayCapNhat) {
        this.ngayCapNhat = ngayCapNhat;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    /**
     * Cập nhật trạng thái dựa trên số lượng tồn
     */
    private void updateTrangThai() {
        if (soLuongTon <= 0) {
            this.trangThai = "Hết hàng";
        } else if (soLuongTon <= 10) {
            this.trangThai = "Sắp hết";
        } else {
            this.trangThai = "Còn hàng";
        }
    }

    /**
     * Cập nhật giá trị tồn
     */
    private void updateGiaTriTon() {
        if (donGiaTrungBinh != null && soLuongTon > 0) {
            this.giaTriTon = donGiaTrungBinh.multiply(new BigDecimal(soLuongTon));
        } else {
            this.giaTriTon = BigDecimal.ZERO;
        }
    }

    /**
     * Nhập kho - tăng số lượng tồn
     */
    public void nhapKho(int soLuong, BigDecimal donGia) {
        if (soLuong > 0 && donGia.compareTo(BigDecimal.ZERO) > 0) {
            // Tính đơn giá trung bình mới
            BigDecimal tongGiaTriCu = this.donGiaTrungBinh.multiply(new BigDecimal(this.soLuongTon));
            BigDecimal tongGiaTriMoi = donGia.multiply(new BigDecimal(soLuong));
            BigDecimal tongGiaTriTong = tongGiaTriCu.add(tongGiaTriMoi);
            
            this.soLuongNhap += soLuong;
            this.soLuongTon += soLuong;
            
            if (this.soLuongTon > 0) {
                this.donGiaTrungBinh = tongGiaTriTong.divide(new BigDecimal(this.soLuongTon), 2, BigDecimal.ROUND_HALF_UP);
            }
            
            updateTrangThai();
            updateGiaTriTon();
            this.ngayCapNhat = new Date();
        }
    }

    /**
     * Xuất kho - giảm số lượng tồn
     */
    public boolean xuatKho(int soLuong) {
        if (soLuong > 0 && soLuong <= this.soLuongTon) {
            this.soLuongXuat += soLuong;
            this.soLuongTon -= soLuong;
            
            updateTrangThai();
            updateGiaTriTon();
            this.ngayCapNhat = new Date();
            return true;
        }
        return false;
    }

    @Override
    public String toString() {
        return "TonKho{" +
                "maKho='" + maKho + '\'' +
                ", tenKho='" + tenKho + '\'' +
                ", maSanPham='" + maSanPham + '\'' +
                ", tenSanPham='" + tenSanPham + '\'' +
                ", soLuongTon=" + soLuongTon +
                ", soLuongNhap=" + soLuongNhap +
                ", soLuongXuat=" + soLuongXuat +
                ", giaTriTon=" + giaTriTon +
                ", donGiaTrungBinh=" + donGiaTrungBinh +
                ", trangThai='" + trangThai + '\'' +
                '}';
    }
}
