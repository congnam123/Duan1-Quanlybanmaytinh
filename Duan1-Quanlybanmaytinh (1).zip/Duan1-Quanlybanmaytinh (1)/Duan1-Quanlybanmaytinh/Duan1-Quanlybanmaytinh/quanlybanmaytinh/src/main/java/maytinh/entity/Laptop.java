package maytinh.entity;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Entity cho Laptop
 */
public class Laptop {
    private String maLaptop;
    private String tenLaptop;
    private String hangSanXuat;
    private String cpu;
    private String ram;
    private String oCung;
    private String cardDoHoa;
    private String manHinh;
    private BigDecimal gia;
    private int soLuong;
    private String trangThai; // "Còn hàng", "Hết hàng", "Ngừng kinh doanh"
    private String moTa;
    private String hinhAnh;
    private Date ngayTao;
    private Date ngayCapNhat;
    private boolean kichHoat;

    // Constructor mặc định
    public Laptop() {
        this.ngayTao = new Date();
        this.ngayCapNhat = new Date();
        this.kichHoat = true;
    }

    // Constructor đầy đủ
    public Laptop(String maLaptop, String tenLaptop, String hangSanXuat, String cpu, 
                  String ram, String oCung, String cardDoHoa, String manHinh, 
                  BigDecimal gia, int soLuong, String trangThai) {
        this();
        this.maLaptop = maLaptop;
        this.tenLaptop = tenLaptop;
        this.hangSanXuat = hangSanXuat;
        this.cpu = cpu;
        this.ram = ram;
        this.oCung = oCung;
        this.cardDoHoa = cardDoHoa;
        this.manHinh = manHinh;
        this.gia = gia;
        this.soLuong = soLuong;
        this.trangThai = trangThai;
    }

    // Builder pattern
    public static Builder builder() {
        return new Builder();
    }

    public static class Builder {
        private Laptop laptop = new Laptop();

        public Builder maLaptop(String maLaptop) {
            laptop.maLaptop = maLaptop;
            return this;
        }

        public Builder tenLaptop(String tenLaptop) {
            laptop.tenLaptop = tenLaptop;
            return this;
        }

        public Builder hangSanXuat(String hangSanXuat) {
            laptop.hangSanXuat = hangSanXuat;
            return this;
        }

        public Builder cpu(String cpu) {
            laptop.cpu = cpu;
            return this;
        }

        public Builder ram(String ram) {
            laptop.ram = ram;
            return this;
        }

        public Builder oCung(String oCung) {
            laptop.oCung = oCung;
            return this;
        }

        public Builder cardDoHoa(String cardDoHoa) {
            laptop.cardDoHoa = cardDoHoa;
            return this;
        }

        public Builder manHinh(String manHinh) {
            laptop.manHinh = manHinh;
            return this;
        }

        public Builder gia(BigDecimal gia) {
            laptop.gia = gia;
            return this;
        }

        public Builder soLuong(int soLuong) {
            laptop.soLuong = soLuong;
            return this;
        }

        public Builder trangThai(String trangThai) {
            laptop.trangThai = trangThai;
            return this;
        }

        public Builder moTa(String moTa) {
            laptop.moTa = moTa;
            return this;
        }

        public Builder hinhAnh(String hinhAnh) {
            laptop.hinhAnh = hinhAnh;
            return this;
        }

        public Builder kichHoat(boolean kichHoat) {
            laptop.kichHoat = kichHoat;
            return this;
        }

        public Laptop build() {
            return laptop;
        }
    }

    // Getters and Setters
    public String getMaLaptop() { return maLaptop; }
    public void setMaLaptop(String maLaptop) { this.maLaptop = maLaptop; }

    public String getTenLaptop() { return tenLaptop; }
    public void setTenLaptop(String tenLaptop) { this.tenLaptop = tenLaptop; }

    public String getHangSanXuat() { return hangSanXuat; }
    public void setHangSanXuat(String hangSanXuat) { this.hangSanXuat = hangSanXuat; }

    public String getCpu() { return cpu; }
    public void setCpu(String cpu) { this.cpu = cpu; }

    public String getRam() { return ram; }
    public void setRam(String ram) { this.ram = ram; }

    public String getoCung() { return oCung; }
    public void setoCung(String oCung) { this.oCung = oCung; }

    public String getCardDoHoa() { return cardDoHoa; }
    public void setCardDoHoa(String cardDoHoa) { this.cardDoHoa = cardDoHoa; }

    public String getManHinh() { return manHinh; }
    public void setManHinh(String manHinh) { this.manHinh = manHinh; }

    public BigDecimal getGia() { return gia; }
    public void setGia(BigDecimal gia) { this.gia = gia; }

    public int getSoLuong() { return soLuong; }
    public void setSoLuong(int soLuong) { this.soLuong = soLuong; }

    public String getTrangThai() { return trangThai; }
    public void setTrangThai(String trangThai) { this.trangThai = trangThai; }

    public String getMoTa() { return moTa; }
    public void setMoTa(String moTa) { this.moTa = moTa; }

    public String getHinhAnh() { return hinhAnh; }
    public void setHinhAnh(String hinhAnh) { this.hinhAnh = hinhAnh; }

    public Date getNgayTao() { return ngayTao; }
    public void setNgayTao(Date ngayTao) { this.ngayTao = ngayTao; }

    public Date getNgayCapNhat() { return ngayCapNhat; }
    public void setNgayCapNhat(Date ngayCapNhat) { this.ngayCapNhat = ngayCapNhat; }

    public boolean isKichHoat() { return kichHoat; }
    public void setKichHoat(boolean kichHoat) { this.kichHoat = kichHoat; }

    @Override
    public String toString() {
        return "Laptop{" +
                "maLaptop='" + maLaptop + '\'' +
                ", tenLaptop='" + tenLaptop + '\'' +
                ", hangSanXuat='" + hangSanXuat + '\'' +
                ", gia=" + gia +
                ", soLuong=" + soLuong +
                ", trangThai='" + trangThai + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Laptop laptop = (Laptop) obj;
        return maLaptop != null ? maLaptop.equals(laptop.maLaptop) : laptop.maLaptop == null;
    }

    @Override
    public int hashCode() {
        return maLaptop != null ? maLaptop.hashCode() : 0;
    }
}
