package maytinh.util;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Logger cho việc cập nhật doanh thu
 */
public class DoanhThuLogger {
    private static final String LOG_FILE = "doanh_thu_updates.log";
    private static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    
    /**
     * Log khi có đơn hàng giao thành công và cập nhật doanh thu
     */
    public static void logDoanhThuUpdate(String maDonHang, String tenSanPham, 
                                       int soLuong, double donGia, double tongTien,
                                       String trangThaiCu, String trangThaiMoi) {
        try {
            String timestamp = dateFormat.format(new Date());
            String logEntry = String.format(
                "[%s] DOANH THU UPDATE - Mã: %s | SP: %s | SL: %d | Giá: %.0f | Tổng: %.0f | %s → %s%n",
                timestamp, maDonHang, tenSanPham, soLuong, donGia, tongTien, trangThaiCu, trangThaiMoi
            );
            
            try (FileWriter writer = new FileWriter(LOG_FILE, true)) {
                writer.write(logEntry);
            }
            
            // Cũng in ra console
            System.out.println("📝 LOG: " + logEntry.trim());
            
        } catch (IOException e) {
            System.out.println("⚠️ Không thể ghi log: " + e.getMessage());
        }
    }
    
    /**
     * Log thống kê tổng quan
     */
    public static void logDoanhThuSummary(double tongDoanhThu, int tongDonHang) {
        try {
            String timestamp = dateFormat.format(new Date());
            String logEntry = String.format(
                "[%s] DOANH THU SUMMARY - Tổng DT: %.0f VNĐ | Tổng ĐH: %d%n",
                timestamp, tongDoanhThu, tongDonHang
            );
            
            try (FileWriter writer = new FileWriter(LOG_FILE, true)) {
                writer.write(logEntry);
            }
            
            System.out.println("📊 SUMMARY LOG: " + logEntry.trim());
            
        } catch (IOException e) {
            System.out.println("⚠️ Không thể ghi summary log: " + e.getMessage());
        }
    }
}
