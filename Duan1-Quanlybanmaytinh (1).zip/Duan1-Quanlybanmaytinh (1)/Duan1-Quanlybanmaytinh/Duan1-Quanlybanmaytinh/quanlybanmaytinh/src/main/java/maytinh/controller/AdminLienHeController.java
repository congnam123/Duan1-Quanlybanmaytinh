/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package maytinh.controller;

/**
 *
 * @author Cong Nam
 */
public interface AdminLienHeController {
    void open();
    void timKiem();
    void fillToTable();
    void traLoi();
    void dongLienHe();
}
