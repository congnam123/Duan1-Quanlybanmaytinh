/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */

package maytinh.ui;

import maytinh.entity.SanPham;
import maytinh.entity.LoaiSanPham;
import maytinh.dao.LoaiSanPhamDAO;
import maytinh.impl.LoaiSanPhamDAOImpl;
import maytinh.util.XDialog;
import maytinh.util.XJdbc;
import maytinh.util.XAuth;
import maytinh.util.ImageUtil;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.io.File;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

/**
 * JDialog quản lý sản phẩm - thiết kế giống QuanLyDonHangJDialog
 * @author Cong Nam
 */
public class Quanlysanpham extends javax.swing.JDialog {

    private DefaultTableModel tableModel;
    private NumberFormat currencyFormat;
    private int currentIndex = -1;
    private LoaiSanPhamDAO loaiSanPhamDAO;
    private String currentImageName = null; // Tên file ảnh hiện tại

    /** Creates new form Quanlysanpham */
    public Quanlysanpham(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        init();
    }

    private void init() {
        // Khởi tạo currency format
        currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

        // Khởi tạo DAO
        loaiSanPhamDAO = new LoaiSanPhamDAOImpl();

        // Thiết lập table model
        tableModel = (DefaultTableModel) tableLaptop.getModel();

        // Tạo thư mục images
        ImageUtil.createImageDirectory();

        // Thiết lập sự kiện cho table
        tableLaptop.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                currentIndex = tableLaptop.getSelectedRow();
                if (currentIndex >= 0) {
                    loadSanPhamInfo();
                }
            }
        });

        // Thiết lập components mới (đã được tạo bởi form designer)
        setupNewComponents();

        // Thiết lập sự kiện cho buttons
        btnTimKiem.addActionListener(e -> searchSanPham());
        btnLamMoi.addActionListener(e -> refreshForm());
        btnThem.addActionListener(e -> addSanPham());
        btnSua.addActionListener(e -> updateSanPham());
        btnXoa.addActionListener(e -> deleteSanPham());

        // Load dữ liệu ban đầu
        loadLoaiSanPham(); // Load loại sản phẩm trước
        loadSanPhamList();
        clearForm();

        // Kiểm tra quyền
        checkPermission();

        // Kiểm tra và thông báo trạng thái components
        checkComponentsStatus();
    }

    /**
     * Kiểm tra trạng thái các components mới
     */
    private void checkComponentsStatus() {
        System.out.println("🔍 KIỂM TRA COMPONENTS NÂNG CẤP:");
        System.out.println("- cboLoaiSP: " + (cboLoaiSP != null ? "✅ Có" : "❌ Chưa có"));
        System.out.println("- lblHinhAnh: " + (lblHinhAnh != null ? "✅ Có" : "❌ Chưa có"));
        System.out.println("- btnChonHinh: " + (btnChonHinh != null ? "✅ Có" : "❌ Chưa có"));
        

        if (cboLoaiSP == null || lblHinhAnh == null || btnChonHinh == null) {
            System.out.println("⚠️ MỘT SỐ COMPONENTS CHƯA CÓ TRONG FORM DESIGNER");
            System.out.println("💡 Ứng dụng vẫn hoạt động bình thường với các tính năng cơ bản");
        } else {
            System.out.println("🎉 TẤT CẢ COMPONENTS NÂNG CẤP ĐÃ SẴN SÀNG!");
        }
    }

    /**
     * Thiết lập các components mới (đã được tạo bởi form designer)
     */
    private void setupNewComponents() {
        try {
            // Thiết lập sự kiện cho button chọn hình (nếu tồn tại)
            if (btnChonHinh != null) {
                btnChonHinh.addActionListener(e -> chonHinhAnh());
            }

      

            // Hiển thị ảnh mặc định (nếu label tồn tại)
            if (lblHinhAnh != null) {
                ImageIcon defaultIcon = ImageUtil.createPreviewIcon("default.jpg");
                lblHinhAnh.setIcon(defaultIcon);
                lblHinhAnh.setText(""); // Xóa text mặc định
            }

            System.out.println("✅ Đã thiết lập components mới từ form designer");
        } catch (Exception e) {
            System.out.println("⚠️ Một số components chưa có trong form: " + e.getMessage());
            // Không báo lỗi, chỉ thông báo
        }
    }

    private void checkPermission() {
        boolean isManager = XAuth.user != null && XAuth.user.isManager();
        btnThem.setEnabled(isManager);
        btnSua.setEnabled(isManager);
        btnXoa.setEnabled(isManager);
    }

    /**
     * Load danh sách loại sản phẩm vào ComboBox
     */
    private void loadLoaiSanPham() {
        try {
            // Kiểm tra ComboBox có tồn tại không
            if (cboLoaiSP == null) {
                System.out.println("⚠️ ComboBox cboLoaiSP chưa được tạo trong form");
                return;
            }

            List<LoaiSanPham> danhSachLoai = loaiSanPhamDAO.getAllLoaiSanPham();
            DefaultComboBoxModel<LoaiSanPham> model = new DefaultComboBoxModel<>();

            // Thêm option "Chọn loại sản phẩm"
            model.addElement(new LoaiSanPham(0, "-- Chọn loại sản phẩm --"));

            // Thêm các loại sản phẩm
            for (LoaiSanPham loai : danhSachLoai) {
                model.addElement(loai);
            }

            cboLoaiSP.setModel(model);
            System.out.println("✅ Đã load " + danhSachLoai.size() + " loại sản phẩm vào ComboBox");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("❌ Lỗi khi tải danh sách loại sản phẩm: " + e.getMessage());
            // Không hiển thị dialog lỗi để tránh gián đoạn
        }
    }

    private void loadSanPhamList() {
        try {
            List<SanPham> sanPhams = getAllSanPhamFromDB();
            tableModel.setRowCount(0);

            for (SanPham sp : sanPhams) {
                Object[] row = {
                    "SP" + sp.getMaSP(),
                    sp.getTenSP(),
                    sp.getLoaiSP() != null ? sp.getLoaiSP() : "N/A",
                    currencyFormat.format(sp.getGia()),
                    sp.getSoLuong(),
                    sp.getSoLuong() > 0 ? "Còn hàng" : "Hết hàng"
                };
                tableModel.addRow(row);
            }

            lblStatus.setText("Đã tải " + sanPhams.size() + " sản phẩm");

        } catch (Exception e) {
            e.printStackTrace();
            XDialog.alert("Lỗi khi tải danh sách sản phẩm: " + e.getMessage());
        }
    }

    private List<SanPham> getAllSanPhamFromDB() {
        List<SanPham> sanPhams = new ArrayList<>();
        String sql = "SELECT sp.MaSP, sp.TenSP, sp.MoTa, sp.Gia, sp.SoLuongTon, sp.HinhAnh, lsp.TenLoai " +
                    "FROM SanPham sp LEFT JOIN LoaiSanPham lsp ON sp.MaLoai = lsp.MaLoai " +
                    "ORDER BY sp.MaSP";

        try (java.sql.Connection conn = XJdbc.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql);
             java.sql.ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                SanPham sp = new SanPham();
                sp.setMaSP(rs.getInt("MaSP"));
                sp.setTenSP(rs.getString("TenSP"));
                sp.setGia(rs.getDouble("Gia"));
                sp.setMoTa(rs.getString("MoTa"));
                sp.setLoaiSP(rs.getString("TenLoai"));
                sp.setSoLuong(rs.getInt("SoLuongTon"));
                sanPhams.add(sp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return sanPhams;
    }

    private void loadSanPhamInfo() {
        if (currentIndex < 0) return;

        try {
            String maSPStr = (String) tableModel.getValueAt(currentIndex, 0);
            int maSP = Integer.parseInt(maSPStr.replace("SP", ""));

            SanPham sanPham = getSanPhamById(maSP);
            if (sanPham != null) {
                txtMaLaptop.setText("SP" + sanPham.getMaSP());
                txtTenLaptop.setText(sanPham.getTenSP());
                txtGia.setText(String.valueOf(sanPham.getGia()));
                txtSoLuong.setText(String.valueOf(sanPham.getSoLuong()));
                txtMoTa.setText(sanPham.getMoTa());

                // Lưu tên ảnh hiện tại
                currentImageName = sanPham.getHinhAnh();

                // Hiển thị ảnh preview (nếu label tồn tại)
                try {
                    if (lblHinhAnh != null) {
                        ImageIcon imageIcon = ImageUtil.createPreviewIcon(currentImageName);
                        lblHinhAnh.setIcon(imageIcon);
                        lblHinhAnh.setText(""); // Xóa text
                    }
                } catch (Exception e) {
                    System.out.println("⚠️ Không thể hiển thị ảnh: " + e.getMessage());
                }

                // Chọn loại sản phẩm trong ComboBox (nếu tồn tại)
                try {
                    if (cboLoaiSP != null && sanPham.getMaLoai() > 0) {
                        for (int i = 0; i < cboLoaiSP.getItemCount(); i++) {
                            LoaiSanPham loai = cboLoaiSP.getItemAt(i);
                            if (loai.getMaLoai() == sanPham.getMaLoai()) {
                                cboLoaiSP.setSelectedIndex(i);
                                break;
                            }
                        }
                    }
                } catch (Exception e) {
                    System.out.println("⚠️ Không thể chọn loại sản phẩm: " + e.getMessage());
                }

                // Thiết lập trạng thái radio button
                if (sanPham.getSoLuong() > 0) {
                    rdoConHang.setSelected(true);
                } else {
                    rdoHetHang.setSelected(true);
                }

                // 🔥 KHÔNG CHO PHÉP SỬA SỐ LƯỢNG KHI CHỈNH SỬA SẢN PHẨM
                setSoLuongEditable(false,
                    "Không thể chỉnh sửa số lượng tồn kho trực tiếp. " +
                    "Sử dụng chức năng Nhập/Xuất kho để thay đổi tồn kho. " +
                    "Tồn kho hiện tại: " + sanPham.getSoLuong());
            }
        } catch (Exception e) {
            e.printStackTrace();
            XDialog.alert("Lỗi khi tải thông tin sản phẩm: " + e.getMessage());
        }
    }

    private SanPham getSanPhamById(int maSP) {
        String sql = "SELECT sp.MaSP, sp.TenSP, sp.MoTa, sp.Gia, sp.SoLuongTon, sp.HinhAnh, sp.MaLoai, lsp.TenLoai " +
                    "FROM SanPham sp LEFT JOIN LoaiSanPham lsp ON sp.MaLoai = lsp.MaLoai " +
                    "WHERE sp.MaSP = ?";

        try (java.sql.Connection conn = XJdbc.getConnection();
             java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maSP);
            try (java.sql.ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    SanPham sp = new SanPham();
                    sp.setMaSP(rs.getInt("MaSP"));
                    sp.setTenSP(rs.getString("TenSP"));
                    sp.setGia(rs.getDouble("Gia"));
                    sp.setMoTa(rs.getString("MoTa"));
                    sp.setLoaiSP(rs.getString("TenLoai"));
                    sp.setSoLuong(rs.getInt("SoLuongTon"));
                    sp.setHinhAnh(rs.getString("HinhAnh"));
                    sp.setMaLoai(rs.getInt("MaLoai"));
                    return sp;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        lblTitle = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtSearch = new javax.swing.JTextField();
        btnTimKiem = new javax.swing.JButton();
        btnLamMoi = new javax.swing.JButton();
        lblStatus = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableLaptop = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtMaLaptop = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtTenLaptop = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtGia = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        cboLoaiSP = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        rdoConHang = new javax.swing.JRadioButton();
        rdoHetHang = new javax.swing.JRadioButton();
        lblHinhAnh = new javax.swing.JLabel();
        btnChonHinh = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtMoTa = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        btnThem = new javax.swing.JButton();
        btnSua = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Quản Lý Sản Phẩm");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(240, 248, 255));

        lblTitle.setFont(new java.awt.Font("Segoe UI", 1, 20)); // NOI18N
        lblTitle.setForeground(new java.awt.Color(25, 25, 112));
        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("QUẢN LÝ SẢN PHẨM");

        jPanel2.setBackground(new java.awt.Color(240, 248, 255));

        jLabel1.setText("Tìm kiếm:");

        btnTimKiem.setText("Tìm kiếm");

        btnLamMoi.setText("Làm mới");

        lblStatus.setText("Sẵn sàng");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnTimKiem)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnLamMoi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(lblStatus, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnTimKiem)
                    .addComponent(btnLamMoi)
                    .addComponent(lblStatus))
                .addContainerGap())
        );

        tableLaptop.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Mã SP", "Tên sản phẩm", "Loại", "Giá", "Số lượng", "Trạng thái"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tableLaptop);

        jPanel3.setBackground(new java.awt.Color(240, 248, 255));
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Thông tin sản phẩm"));

        jLabel2.setText("Mã sản phẩm:");

        jLabel3.setText("Tên sản phẩm:");

        jLabel4.setText("Giá (VNĐ):");

        jLabel10.setText("Số lượng:");

        jLabel11.setText("Loại sản phẩm:");

        jLabel5.setText("Trạng thái:");

        buttonGroup1.add(rdoConHang);
        rdoConHang.setText("Còn hàng");

        buttonGroup1.add(rdoHetHang);
        rdoHetHang.setText("Hết hàng");

        lblHinhAnh.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblHinhAnh.setText("Hình ảnh");
        lblHinhAnh.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        lblHinhAnh.setPreferredSize(new java.awt.Dimension(150, 150));

        btnChonHinh.setText("Chọn hình");

        jLabel12.setText("Mô tả:");

        txtMoTa.setColumns(20);
        txtMoTa.setRows(3);
        jScrollPane3.setViewportView(txtMoTa);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMaLaptop)
                            .addComponent(txtTenLaptop)
                            .addComponent(txtGia)
                            .addComponent(txtSoLuong, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                            .addComponent(cboLoaiSP, 0, 200, Short.MAX_VALUE))
                        .addGap(50, 50, 50)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnChonHinh)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(rdoConHang)
                                    .addComponent(rdoHetHang))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(lblHinhAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(28, 28, 28))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(txtMaLaptop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(txtTenLaptop, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel4)
                                    .addComponent(txtGia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10)
                                    .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel11)
                                    .addComponent(cboLoaiSP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rdoConHang)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(rdoHetHang))
                            .addComponent(lblHinhAnh, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(156, 156, 156)
                        .addComponent(btnChonHinh)))
                .addGap(35, 35, 35)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        jPanel4.setBackground(new java.awt.Color(240, 248, 255));

        btnThem.setText("Thêm");
        btnThem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemActionPerformed(evt);
            }
        });

        btnSua.setText("Sửa");

        btnXoa.setText("Xóa");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnThem)
                .addGap(18, 18, 18)
                .addComponent(btnSua)
                .addGap(18, 18, 18)
                .addComponent(btnXoa)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThem)
                    .addComponent(btnSua)
                    .addComponent(btnXoa))
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(lblTitle, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jScrollPane1)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(lblTitle, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 256, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnThemActionPerformed

    private void searchSanPham() {
        String keyword = txtSearch.getText().trim();
        if (keyword.isEmpty()) {
            loadSanPhamList();
            return;
        }

        try {
            String sql = "SELECT sp.MaSP, sp.TenSP, sp.MoTa, sp.Gia, sp.SoLuongTon, sp.HinhAnh, lsp.TenLoai " +
                        "FROM SanPham sp LEFT JOIN LoaiSanPham lsp ON sp.MaLoai = lsp.MaLoai " +
                        "WHERE sp.TenSP LIKE ? OR sp.MoTa LIKE ? OR lsp.TenLoai LIKE ?";

            String searchPattern = "%" + keyword + "%";
            List<SanPham> results = new ArrayList<>();

            try (java.sql.Connection conn = XJdbc.getConnection();
                 java.sql.PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, searchPattern);
                ps.setString(2, searchPattern);
                ps.setString(3, searchPattern);

                try (java.sql.ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        SanPham sp = new SanPham();
                        sp.setMaSP(rs.getInt("MaSP"));
                        sp.setTenSP(rs.getString("TenSP"));
                        sp.setGia(rs.getDouble("Gia"));
                        sp.setMoTa(rs.getString("MoTa"));
                        sp.setLoaiSP(rs.getString("TenLoai"));
                        sp.setSoLuong(rs.getInt("SoLuongTon"));
                        results.add(sp);
                    }
                }
            }

            // Update table
            tableModel.setRowCount(0);
            for (SanPham sp : results) {
                Object[] row = {
                    "SP" + sp.getMaSP(),
                    sp.getTenSP(),
                    sp.getLoaiSP(),
                    currencyFormat.format(sp.getGia()),
                    sp.getSoLuong(),
                    sp.getSoLuong() > 0 ? "Còn hàng" : "Hết hàng"
                };
                tableModel.addRow(row);
            }

            lblStatus.setText("Tìm thấy " + results.size() + " sản phẩm với từ khóa '" + keyword + "'");

        } catch (Exception e) {
            e.printStackTrace();
            XDialog.alert("Lỗi khi tìm kiếm: " + e.getMessage());
        }
    }

    private void refreshForm() {
        loadSanPhamList();
        clearForm();
        txtSearch.setText("");
        currentIndex = -1;
    }

    private void addSanPham() {
        if (!validateData()) {
            return;
        }

        try {
            String sql = "INSERT INTO SanPham (TenSP, MoTa, Gia, SoLuongTon, MaLoai, HinhAnh) VALUES (?, ?, ?, ?, ?, ?)";

            // Lấy MaLoai từ ComboBox (nếu tồn tại)
            int maLoai = 1; // Mặc định
            try {
                if (cboLoaiSP != null && cboLoaiSP.getSelectedItem() != null) {
                    LoaiSanPham selectedLoai = (LoaiSanPham) cboLoaiSP.getSelectedItem();
                    if (selectedLoai.getMaLoai() > 0) {
                        maLoai = selectedLoai.getMaLoai();
                    }
                }
            } catch (Exception e) {
                System.out.println("⚠️ Không thể lấy loại sản phẩm, sử dụng mặc định: " + e.getMessage());
            }

            // Sử dụng ảnh hiện tại hoặc ảnh mặc định
            String hinhAnh = (currentImageName != null && !currentImageName.trim().isEmpty())
                           ? currentImageName : "default.jpg";

            Object[] values = {
                txtTenLaptop.getText().trim(),
                txtMoTa.getText().trim(),
                Double.parseDouble(txtGia.getText().trim()),
                Integer.parseInt(txtSoLuong.getText().trim()),
                maLoai,
                hinhAnh
            };

            XJdbc.executeUpdate(sql, values);
            loadSanPhamList();
            clearForm();
            XDialog.alert("Thêm sản phẩm thành công!");

        } catch (Exception e) {
            e.printStackTrace();
            XDialog.alert("Lỗi khi thêm sản phẩm: " + e.getMessage());
        }
    }

    private void updateSanPham() {
        if (currentIndex < 0) {
            XDialog.alert("Vui lòng chọn sản phẩm cần sửa!");
            return;
        }

        if (!validateData()) {
            return;
        }

        try {
            String maSPStr = txtMaLaptop.getText().trim();
            int maSP = Integer.parseInt(maSPStr.replace("SP", ""));

            // 🔥 KHÔNG CẬP NHẬT SỐ LƯỢNG TỒN KHO KHI SỬA SẢN PHẨM
            String sql = "UPDATE SanPham SET TenSP=?, MoTa=?, Gia=?, MaLoai=?, HinhAnh=? WHERE MaSP=?";

            // Lấy MaLoai từ ComboBox (nếu tồn tại)
            int maLoai = 1; // Mặc định
            try {
                if (cboLoaiSP != null && cboLoaiSP.getSelectedItem() != null) {
                    LoaiSanPham selectedLoai = (LoaiSanPham) cboLoaiSP.getSelectedItem();
                    if (selectedLoai.getMaLoai() > 0) {
                        maLoai = selectedLoai.getMaLoai();
                    }
                }
            } catch (Exception e) {
                System.out.println("⚠️ Không thể lấy loại sản phẩm, sử dụng mặc định: " + e.getMessage());
            }

            // Sử dụng ảnh hiện tại hoặc ảnh mặc định
            String hinhAnh = (currentImageName != null && !currentImageName.trim().isEmpty())
                           ? currentImageName : "default.jpg";

            // 🔥 KHÔNG TRUYỀN SỐ LƯỢNG VÀO QUERY UPDATE
            Object[] values = {
                txtTenLaptop.getText().trim(),
                txtMoTa.getText().trim(),
                Double.parseDouble(txtGia.getText().trim()),
                maLoai,
                hinhAnh,
                maSP
            };

            System.out.println("🔄 Cập nhật sản phẩm SP" + maSP + " - KHÔNG thay đổi tồn kho");

            XJdbc.executeUpdate(sql, values);
            loadSanPhamList();
            XDialog.alert("Cập nhật sản phẩm thành công!");

        } catch (Exception e) {
            e.printStackTrace();
            XDialog.alert("Lỗi khi cập nhật sản phẩm: " + e.getMessage());
        }
    }

    private void deleteSanPham() {
        if (currentIndex < 0) {
            XDialog.alert("Vui lòng chọn sản phẩm cần xóa!");
            return;
        }

        String maSPStr = (String) tableModel.getValueAt(currentIndex, 0);
        String tenSP = (String) tableModel.getValueAt(currentIndex, 1);

        if (XDialog.confirm("Bạn có chắc muốn xóa sản phẩm '" + tenSP + "'?")) {
            try {
                int maSP = Integer.parseInt(maSPStr.replace("SP", ""));
                String sql = "DELETE FROM SanPham WHERE MaSP=?";

                XJdbc.executeUpdate(sql, maSP);
                loadSanPhamList();
                clearForm();
                XDialog.alert("Xóa sản phẩm thành công!");

            } catch (Exception e) {
                e.printStackTrace();
                XDialog.alert("Lỗi khi xóa sản phẩm: " + e.getMessage());
            }
        }
    }

    private boolean validateData() {
        // Kiểm tra tên sản phẩm
        if (txtTenLaptop.getText().trim().isEmpty()) {
            XDialog.alert("Vui lòng nhập tên sản phẩm!");
            txtTenLaptop.requestFocus();
            return false;
        }

        // Kiểm tra loại sản phẩm (nếu ComboBox tồn tại)
        try {
            if (cboLoaiSP != null && cboLoaiSP.getSelectedItem() != null) {
                LoaiSanPham selectedLoai = (LoaiSanPham) cboLoaiSP.getSelectedItem();
                if (selectedLoai.getMaLoai() <= 0) {
                    XDialog.alert("Vui lòng chọn loại sản phẩm!");
                    cboLoaiSP.requestFocus();
                    return false;
                }
            }
        } catch (Exception e) {
            System.out.println("⚠️ Không thể validate ComboBox: " + e.getMessage());
            // Tiếp tục validation các trường khác
        }

        // Kiểm tra giá
        try {
            double gia = Double.parseDouble(txtGia.getText().trim());
            if (gia <= 0) {
                XDialog.alert("Giá phải lớn hơn 0!");
                txtGia.requestFocus();
                return false;
            }
        } catch (NumberFormatException e) {
            XDialog.alert("Giá không hợp lệ!");
            txtGia.requestFocus();
            return false;
        }

        // 🔥 CHỈ KIỂM TRA SỐ LƯỢNG KHI THÊM MỚI (txtSoLuong editable)
        if (txtSoLuong.isEditable()) {
            try {
                int soLuong = Integer.parseInt(txtSoLuong.getText().trim());
                if (soLuong < 0) {
                    XDialog.alert("Số lượng không được âm!");
                    txtSoLuong.requestFocus();
                    return false;
                }
            } catch (NumberFormatException e) {
                XDialog.alert("Số lượng không hợp lệ!");
                txtSoLuong.requestFocus();
                return false;
            }
        }

        return true;
    }

    private void clearForm() {
        txtMaLaptop.setText("");
        txtTenLaptop.setText("");
        txtGia.setText("");
        txtSoLuong.setText("0");
        txtMoTa.setText("");
        rdoConHang.setSelected(true);

        // Reset ComboBox về "Chọn loại sản phẩm" (nếu tồn tại)
        try {
            if (cboLoaiSP != null && cboLoaiSP.getItemCount() > 0) {
                cboLoaiSP.setSelectedIndex(0);
            }
        } catch (Exception e) {
            System.out.println("⚠️ Không thể reset ComboBox: " + e.getMessage());
        }

        // Reset hình ảnh về mặc định (nếu tồn tại)
        currentImageName = null;
        try {
            if (lblHinhAnh != null) {
                ImageIcon defaultIcon = ImageUtil.createPreviewIcon("default.jpg");
                lblHinhAnh.setIcon(defaultIcon);
                lblHinhAnh.setText(""); // Xóa text
            }
        } catch (Exception e) {
            System.out.println("⚠️ Không thể reset hình ảnh: " + e.getMessage());
        }

        txtTenLaptop.requestFocus();

        // 🔥 CHO PHÉP NHẬP SỐ LƯỢNG KHI THÊM MỚI
        setSoLuongEditable(true, "Nhập số lượng ban đầu cho sản phẩm mới");
    }

    /**
     * 🔥 KIỂM SOÁT TRẠNG THÁI CHỈNH SỬA SỐ LƯỢNG
     */
    private void setSoLuongEditable(boolean editable, String tooltip) {
        txtSoLuong.setEditable(editable);
        txtSoLuong.setEnabled(editable);
        txtSoLuong.setToolTipText(tooltip);

        if (editable) {
            txtSoLuong.setBackground(java.awt.Color.WHITE);
        } else {
            txtSoLuong.setBackground(new java.awt.Color(240, 240, 240)); // Màu xám nhạt
        }
    }

    /**
     * Xử lý sự kiện chọn hình ảnh
     */
    private void chonHinhAnh() {
        File selectedFile = ImageUtil.chooseImageFile(this);
        if (selectedFile != null) {
            // Lưu file ảnh
            String savedFileName = ImageUtil.saveImageFile(selectedFile);
            if (savedFileName != null) {
                currentImageName = savedFileName;

                // Hiển thị preview
                if (lblHinhAnh != null) {
                    ImageIcon imageIcon = ImageUtil.createPreviewIcon(savedFileName);
                    lblHinhAnh.setIcon(imageIcon);
                }

                XDialog.alert("Đã chọn hình ảnh thành công!");
            } else {
                XDialog.alert("Lỗi khi lưu hình ảnh!");
            }
        }
    }

    /**
     * Xử lý sự kiện mở dialog quản lý loại sản phẩm
     */
    private void quanLyLoaiSanPham() {
        // Tạo dialog quản lý loại sản phẩm (sẽ implement sau)
        XDialog.alert("Chức năng quản lý loại sản phẩm sẽ được thêm sau!");

        // Refresh lại ComboBox sau khi quản lý
        loadLoaiSanPham();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Quanlysanpham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Quanlysanpham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Quanlysanpham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Quanlysanpham.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Quanlysanpham dialog = new Quanlysanpham(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnChonHinh;
    private javax.swing.JButton btnLamMoi;
    private javax.swing.JButton btnSua;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTimKiem;
    private javax.swing.JButton btnXoa;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<maytinh.entity.LoaiSanPham> cboLoaiSP;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblHinhAnh;
    private javax.swing.JLabel lblStatus;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JRadioButton rdoConHang;
    private javax.swing.JRadioButton rdoHetHang;
    private javax.swing.JTable tableLaptop;
    private javax.swing.JTextField txtGia;
    private javax.swing.JTextField txtMaLaptop;
    private javax.swing.JTextArea txtMoTa;
    private javax.swing.JTextField txtSearch;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenLaptop;
    // End of variables declaration//GEN-END:variables

}
