package maytinh.impl;

import maytinh.dao.DanhGiaDAO;
import maytinh.entity.DanhGia;
import maytinh.util.XJdbc;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation của DanhGiaDAO
 * @author Admin
 */
public class DanhGiaDAOImpl implements DanhGiaDAO {

    @Override
    public DanhGia insert(DanhGia danhGia) {
        String sql = "INSERT INTO DanhGia (Username, MaSP, NoiDung, Diem, NgayDanhGia, TraLoi) VALUES (?, ?, ?, ?, GETDATE(), ?)";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, danhGia.getUsername());
            ps.setInt(2, danhGia.getMaSP());
            ps.setString(3, danhGia.getNoiDung());
            ps.setInt(4, danhGia.getDiem());
            ps.setString(5, null); // TraLoi initially null

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        danhGia.setMaDG(rs.getInt(1));
                        return danhGia;
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public DanhGia update(DanhGia danhGia) {
        String sql = "UPDATE DanhGia SET NoiDung = ?, Diem = ? WHERE MaDG = ?";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, danhGia.getNoiDung());
            ps.setInt(2, danhGia.getDiem());
            ps.setInt(3, danhGia.getMaDG());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                return selectById(danhGia.getMaDG());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean delete(int maDG) {
        String sql = "DELETE FROM DanhGia WHERE MaDG = ?";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maDG);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public DanhGia selectById(int maDG) {
        String sql = "SELECT * FROM DanhGia WHERE MaDG = ?";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maDG);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToDanhGia(rs);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<DanhGia> selectAll() {
        String sql = "SELECT * FROM DanhGia ORDER BY NgayDanhGia DESC";
        List<DanhGia> list = new ArrayList<>();

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapResultSetToDanhGia(rs));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<DanhGia> selectByUsername(String username) {
        String sql = "SELECT * FROM DanhGia WHERE Username = ? ORDER BY NgayDanhGia DESC";
        List<DanhGia> list = new ArrayList<>();

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToDanhGia(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public List<DanhGia> selectByProductId(int maSP) {
        String sql = "SELECT * FROM DanhGia WHERE MaSP = ? ORDER BY NgayDanhGia DESC";
        List<DanhGia> list = new ArrayList<>();

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, maSP);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToDanhGia(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean hasReviewed(String username, int maSP) {
        System.out.println("🔍 DEBUG DanhGiaDAO.hasReviewed:");
        System.out.println("   - Username: " + username);
        System.out.println("   - MaSP: " + maSP);

        String sql = "SELECT COUNT(*) FROM DanhGia WHERE Username = ? AND MaSP = ?";
        System.out.println("   - SQL: " + sql);

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setInt(2, maSP);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int count = rs.getInt(1);
                    boolean hasReviewed = count > 0;
                    System.out.println("   - Count: " + count);
                    System.out.println("   - HasReviewed: " + hasReviewed);

                    // Hiển thị các đánh giá hiện có (để debug)
                    if (count > 0) {
                        System.out.println("   - 📋 Các đánh giá hiện có:");
                        String sqlDetail = "SELECT MaDG, NoiDung, Diem, NgayDanhGia FROM DanhGia WHERE Username = ? AND MaSP = ?";
                        try (PreparedStatement psDetail = conn.prepareStatement(sqlDetail)) {
                            psDetail.setString(1, username);
                            psDetail.setInt(2, maSP);
                            try (ResultSet rsDetail = psDetail.executeQuery()) {
                                while (rsDetail.next()) {
                                    System.out.println("     * MaDG: " + rsDetail.getInt("MaDG") +
                                                     ", Diem: " + rsDetail.getInt("Diem") +
                                                     ", NgayDanhGia: " + rsDetail.getTimestamp("NgayDanhGia"));
                                }
                            }
                        }
                    }

                    return hasReviewed;
                }
            }
        } catch (Exception e) {
            System.err.println("❌ Lỗi trong DanhGiaDAO.hasReviewed: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateReply(int maDG, String traLoi) {
        String sql = "UPDATE DanhGia SET TraLoi = ? WHERE MaDG = ?";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, traLoi);
            ps.setInt(2, maDG);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<DanhGia> getAll() {
        return selectAll();
    }

    @Override
    public List<DanhGia> searchByKeyword(String keyword) {
        String sql = "SELECT * FROM DanhGia WHERE NoiDung LIKE ? OR Username LIKE ? ORDER BY NgayDanhGia DESC";
        List<DanhGia> list = new ArrayList<>();

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String searchPattern = "%" + keyword + "%";
            ps.setString(1, searchPattern);
            ps.setString(2, searchPattern);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapResultSetToDanhGia(rs));
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public boolean traLoiDanhGia(int maDG, String traLoi) {
        return updateReply(maDG, traLoi);
    }

    /**
     * Helper method để map ResultSet thành DanhGia object
     */
    private DanhGia mapResultSetToDanhGia(ResultSet rs) throws SQLException {
        DanhGia danhGia = new DanhGia();
        danhGia.setMaDG(rs.getInt("MaDG"));
        danhGia.setUsername(rs.getString("Username"));
        danhGia.setMaSP(rs.getInt("MaSP"));
        danhGia.setNoiDung(rs.getString("NoiDung"));
        danhGia.setDiem(rs.getInt("Diem"));
        danhGia.setNgayDanhGia(rs.getTimestamp("NgayDanhGia"));
        danhGia.setTraLoi(rs.getString("TraLoi"));
        return danhGia;
    }

    @Override
    public List<DanhGia> selectByUsernameWithProductInfo(String username) {
        List<DanhGia> list = new ArrayList<>();
        String sql = "SELECT dg.MaDG, dg.Username, dg.MaSP, dg.NoiDung, dg.Diem, dg.NgayDanhGia, dg.TraLoi, sp.TenSP " +
                     "FROM DanhGia dg " +
                     "LEFT JOIN SanPham sp ON dg.MaSP = sp.MaSP " +
                     "WHERE dg.Username = ? " +
                     "ORDER BY dg.NgayDanhGia DESC";

        try (Connection conn = XJdbc.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                DanhGia danhGia = new DanhGia();
                danhGia.setMaDG(rs.getInt("MaDG"));
                danhGia.setUsername(rs.getString("Username"));
                danhGia.setMaSP(rs.getInt("MaSP"));
                danhGia.setNoiDung(rs.getString("NoiDung"));
                danhGia.setDiem(rs.getInt("Diem"));
                danhGia.setNgayDanhGia(rs.getTimestamp("NgayDanhGia"));
                danhGia.setTraLoi(rs.getString("TraLoi"));

                // ✅ Set tên sản phẩm từ JOIN
                danhGia.setTenSP(rs.getString("TenSP"));

                list.add(danhGia);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}