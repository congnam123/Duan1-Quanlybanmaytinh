package maytinh.controller;

import maytinh.dao.KhoDAO;
import maytinh.entity.Kho;
import maytinh.impl.KhoDAOImpl;
import maytinh.util.XDialog;
import java.util.List;
import java.util.Date;

/**
 * Controller cho Quản lý Kho
 * @author Cong Nam
 */
public class QuanLyKhoController {
    
    private KhoDAO khoDAO;
    
    public QuanLyKhoController() {
        this.khoDAO = new KhoDAOImpl();
    }
    
    /**
     * Lấy tất cả kho
     * @return List<Kho>
     */
    public List<Kho> getAllKho() {
        try {
            return khoDAO.findAll();
        } catch (Exception e) {
            XDialog.alert("Lỗi khi lấy danh sách kho: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Lấy kho theo mã
     * @param maKho Mã kho
     * @return Kho
     */
    public Kho getKhoById(String maKho) {
        try {
            return khoDAO.findById(maKho);
        } catch (Exception e) {
            XDialog.alert("Lỗi khi lấy thông tin kho: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Thêm kho mới
     * @param kho Kho cần thêm
     * @return true nếu thành công
     */
    public boolean addKho(Kho kho) {
        try {
            // Kiểm tra mã kho đã tồn tại chưa
            if (khoDAO.existsByMaKho(kho.getMaKho())) {
                XDialog.alert("Mã kho đã tồn tại!");
                return false;
            }
            
            // Validate dữ liệu
            if (!validateKho(kho)) {
                return false;
            }
            
            khoDAO.create(kho);
            XDialog.alert("Thêm kho thành công!");
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi thêm kho: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Cập nhật kho
     * @param kho Kho cần cập nhật
     * @return true nếu thành công
     */
    public boolean updateKho(Kho kho) {
        try {
            // Validate dữ liệu
            if (!validateKho(kho)) {
                return false;
            }
            
            khoDAO.update(kho);
            XDialog.alert("Cập nhật kho thành công!");
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi cập nhật kho: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Xóa kho
     * @param maKho Mã kho cần xóa
     * @return true nếu thành công
     */
    public boolean deleteKho(String maKho) {
        try {
            if (XDialog.confirm("Bạn có chắc chắn muốn xóa kho này?")) {
                khoDAO.deleteById(maKho);
                XDialog.alert("Xóa kho thành công!");
                return true;
            }
            return false;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi xóa kho: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Tìm kiếm kho
     * @param keyword Từ khóa tìm kiếm
     * @return List<Kho>
     */
    public List<Kho> searchKho(String keyword) {
        try {
            if (keyword == null || keyword.trim().isEmpty()) {
                return getAllKho();
            }
            return khoDAO.search(keyword.trim());
        } catch (Exception e) {
            XDialog.alert("Lỗi khi tìm kiếm kho: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Lấy danh sách kho đang hoạt động
     * @return List<Kho>
     */
    public List<Kho> getActiveKho() {
        try {
            return khoDAO.findActiveKho();
        } catch (Exception e) {
            XDialog.alert("Lỗi khi lấy danh sách kho hoạt động: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Cập nhật trạng thái kho
     * @param maKho Mã kho
     * @param trangThai Trạng thái mới
     * @return true nếu thành công
     */
    public boolean updateTrangThaiKho(String maKho, boolean trangThai) {
        try {
            khoDAO.updateTrangThai(maKho, trangThai);
            String message = trangThai ? "Kích hoạt kho thành công!" : "Vô hiệu hóa kho thành công!";
            XDialog.alert(message);
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi cập nhật trạng thái kho: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Lấy thống kê kho
     * @return String thông tin thống kê
     */
    public String getThongKeKho() {
        try {
            long tongKho = khoDAO.count();
            long khoHoatDong = khoDAO.countByTrangThai(true);
            long khoNgungHoatDong = khoDAO.countByTrangThai(false);
            
            return String.format("Tổng số kho: %d\nKho đang hoạt động: %d\nKho ngừng hoạt động: %d", 
                    tongKho, khoHoatDong, khoNgungHoatDong);
        } catch (Exception e) {
            return "Lỗi khi lấy thống kê: " + e.getMessage();
        }
    }
    
    /**
     * Validate dữ liệu kho
     * @param kho Kho cần validate
     * @return true nếu hợp lệ
     */
    private boolean validateKho(Kho kho) {
        if (kho.getMaKho() == null || kho.getMaKho().trim().isEmpty()) {
            XDialog.alert("Mã kho không được để trống!");
            return false;
        }
        
        if (kho.getTenKho() == null || kho.getTenKho().trim().isEmpty()) {
            XDialog.alert("Tên kho không được để trống!");
            return false;
        }
        
        if (kho.getDiaChi() == null || kho.getDiaChi().trim().isEmpty()) {
            XDialog.alert("Địa chỉ kho không được để trống!");
            return false;
        }
        
        if (kho.getNguoiQuanLy() == null || kho.getNguoiQuanLy().trim().isEmpty()) {
            XDialog.alert("Người quản lý không được để trống!");
            return false;
        }
        
        // Validate số điện thoại nếu có
        if (kho.getSoDienThoai() != null && !kho.getSoDienThoai().trim().isEmpty()) {
            if (!kho.getSoDienThoai().matches("^[0-9]{10,11}$")) {
                XDialog.alert("Số điện thoại không hợp lệ!");
                return false;
            }
        }
        
        // Validate email nếu có
        if (kho.getEmail() != null && !kho.getEmail().trim().isEmpty()) {
            if (!kho.getEmail().matches("^[A-Za-z0-9+_.-]+@(.+)$")) {
                XDialog.alert("Email không hợp lệ!");
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Tạo mã kho tự động
     * @return Mã kho mới
     */
    public String generateMaKho() {
        try {
            long count = khoDAO.count();
            return String.format("KHO%03d", count + 1);
        } catch (Exception e) {
            return "KHO001";
        }
    }
}
