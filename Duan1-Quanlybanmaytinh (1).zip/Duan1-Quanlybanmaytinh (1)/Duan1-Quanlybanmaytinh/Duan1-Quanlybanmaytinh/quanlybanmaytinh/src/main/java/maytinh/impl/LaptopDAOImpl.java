package maytinh.impl;

import maytinh.dao.LaptopDAO;
import maytinh.entity.Laptop;
import maytinh.util.XJdbc;
import maytinh.util.XQuery;
import java.util.List;

/**
 * Implementation của LaptopDAO
 */
public class LaptopDAOImpl implements LaptopDAO {
    
    // SQL Statements
    private final String INSERT_SQL = "INSERT INTO Laptops (MaLaptop, TenLaptop, HangSanXuat, CPU, RAM, OCung, CardDoHoa, ManHinh, Gia, SoLuong, TrangThai, MoTa, HinhAnh, NgayTao, NgayCapNhat, KichHoat) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private final String UPDATE_SQL = "UPDATE Laptops SET TenLaptop=?, HangSanXuat=?, CPU=?, RAM=?, OCung=?, CardDoHoa=?, ManHinh=?, Gia=?, SoLuong=?, TrangThai=?, MoTa=?, HinhAnh=?, NgayCapNhat=?, KichHoat=? WHERE MaLaptop=?";
    
    private final String DELETE_SQL = "DELETE FROM Laptops WHERE MaLaptop=?";
    
    private final String SELECT_ALL_SQL = "SELECT * FROM Laptops WHERE KichHoat=1 ORDER BY NgayCapNhat DESC";
    
    private final String SELECT_BY_ID_SQL = "SELECT * FROM Laptops WHERE MaLaptop=?";
    
    private final String SELECT_BY_TEN_SQL = "SELECT * FROM Laptops WHERE TenLaptop LIKE ? AND KichHoat=1";
    
    private final String SELECT_BY_HANG_SQL = "SELECT * FROM Laptops WHERE HangSanXuat=? AND KichHoat=1";
    
    private final String SELECT_BY_TRANGTHAI_SQL = "SELECT * FROM Laptops WHERE TrangThai=? AND KichHoat=1";
    
    private final String SELECT_BY_GIA_RANGE_SQL = "SELECT * FROM Laptops WHERE Gia BETWEEN ? AND ? AND KichHoat=1";
    
    private final String SELECT_AVAILABLE_SQL = "SELECT * FROM Laptops WHERE SoLuong > 0 AND KichHoat=1";
    
    private final String SELECT_OUT_OF_STOCK_SQL = "SELECT * FROM Laptops WHERE SoLuong = 0 AND KichHoat=1";
    
    private final String UPDATE_SOLUONG_SQL = "UPDATE Laptops SET SoLuong=?, NgayCapNhat=GETDATE() WHERE MaLaptop=?";
    
    private final String UPDATE_TRANGTHAI_SQL = "UPDATE Laptops SET TrangThai=?, NgayCapNhat=GETDATE() WHERE MaLaptop=?";
    
    private final String SEARCH_SQL = "SELECT * FROM Laptops WHERE (TenLaptop LIKE ? OR HangSanXuat LIKE ? OR CPU LIKE ? OR RAM LIKE ? OR MoTa LIKE ?) AND KichHoat=1";
    
    private final String SELECT_BY_PAGE_SQL = "SELECT * FROM Laptops WHERE KichHoat=1 ORDER BY NgayCapNhat DESC OFFSET ? ROWS FETCH NEXT ? ROWS ONLY";
    
    private final String COUNT_SQL = "SELECT COUNT(*) FROM Laptops WHERE KichHoat=1";
    
    private final String COUNT_BY_TRANGTHAI_SQL = "SELECT COUNT(*) FROM Laptops WHERE TrangThai=? AND KichHoat=1";

    @Override
    public Laptop create(Laptop laptop) {
        Object[] values = {
            laptop.getMaLaptop(),
            laptop.getTenLaptop(),
            laptop.getHangSanXuat(),
            laptop.getCpu(),
            laptop.getRam(),
            laptop.getoCung(),
            laptop.getCardDoHoa(),
            laptop.getManHinh(),
            laptop.getGia(),
            laptop.getSoLuong(),
            laptop.getTrangThai(),
            laptop.getMoTa(),
            laptop.getHinhAnh(),
            laptop.getNgayTao(),
            laptop.getNgayCapNhat(),
            laptop.isKichHoat()
        };
        XJdbc.executeUpdate(INSERT_SQL, values);
        return laptop;
    }

    @Override
    public void update(Laptop laptop) {
        laptop.setNgayCapNhat(new java.util.Date());
        Object[] values = {
            laptop.getTenLaptop(),
            laptop.getHangSanXuat(),
            laptop.getCpu(),
            laptop.getRam(),
            laptop.getoCung(),
            laptop.getCardDoHoa(),
            laptop.getManHinh(),
            laptop.getGia(),
            laptop.getSoLuong(),
            laptop.getTrangThai(),
            laptop.getMoTa(),
            laptop.getHinhAnh(),
            laptop.getNgayCapNhat(),
            laptop.isKichHoat(),
            laptop.getMaLaptop()
        };
        XJdbc.executeUpdate(UPDATE_SQL, values);
    }

    @Override
    public void deleteById(String maLaptop) {
        XJdbc.executeUpdate(DELETE_SQL, maLaptop);
    }

    @Override
    public List<Laptop> findAll() {
        return XQuery.getBeanList(Laptop.class, SELECT_ALL_SQL);
    }

    @Override
    public Laptop findById(String maLaptop) {
        return XQuery.getSingleBean(Laptop.class, SELECT_BY_ID_SQL, maLaptop);
    }

    @Override
    public List<Laptop> findByTenLaptop(String tenLaptop) {
        return XQuery.getBeanList(Laptop.class, SELECT_BY_TEN_SQL, "%" + tenLaptop + "%");
    }

    @Override
    public List<Laptop> findByHangSanXuat(String hangSanXuat) {
        return XQuery.getBeanList(Laptop.class, SELECT_BY_HANG_SQL, hangSanXuat);
    }

    @Override
    public List<Laptop> findByTrangThai(String trangThai) {
        return XQuery.getBeanList(Laptop.class, SELECT_BY_TRANGTHAI_SQL, trangThai);
    }

    @Override
    public List<Laptop> findByGiaRange(double giaMin, double giaMax) {
        return XQuery.getBeanList(Laptop.class, SELECT_BY_GIA_RANGE_SQL, giaMin, giaMax);
    }

    @Override
    public List<Laptop> findAvailableLaptops() {
        return XQuery.getBeanList(Laptop.class, SELECT_AVAILABLE_SQL);
    }

    @Override
    public List<Laptop> findOutOfStockLaptops() {
        return XQuery.getBeanList(Laptop.class, SELECT_OUT_OF_STOCK_SQL);
    }

    @Override
    public void updateSoLuong(String maLaptop, int soLuong) {
        XJdbc.executeUpdate(UPDATE_SOLUONG_SQL, soLuong, maLaptop);
    }

    @Override
    public void updateTrangThai(String maLaptop, String trangThai) {
        XJdbc.executeUpdate(UPDATE_TRANGTHAI_SQL, trangThai, maLaptop);
    }

    @Override
    public List<Laptop> search(String keyword) {
        String searchPattern = "%" + keyword + "%";
        return XQuery.getBeanList(Laptop.class, SEARCH_SQL, 
            searchPattern, searchPattern, searchPattern, searchPattern, searchPattern);
    }

    @Override
    public List<Laptop> findByPage(int page, int size) {
        int offset = page * size;
        return XQuery.getBeanList(Laptop.class, SELECT_BY_PAGE_SQL, offset, size);
    }

    @Override
    public long count() {
        try {
            // Sử dụng XJdbc để thực hiện query count
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_SQL);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    @Override
    public long countByTrangThai(String trangThai) {
        try {
            // Sử dụng XJdbc để thực hiện query count
            java.sql.ResultSet rs = XJdbc.executeQuery(COUNT_BY_TRANGTHAI_SQL, trangThai);
            if (rs.next()) {
                return rs.getLong(1);
            }
            return 0;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }
}
