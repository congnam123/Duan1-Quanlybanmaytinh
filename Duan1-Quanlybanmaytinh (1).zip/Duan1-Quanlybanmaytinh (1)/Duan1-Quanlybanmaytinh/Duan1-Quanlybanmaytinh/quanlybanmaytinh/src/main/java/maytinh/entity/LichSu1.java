package maytinh.entity;

import java.util.Date;

public class LichSu1 {
    private int maDH;
    private String maDonHang;
    private String tenSP;
    private String tenSanPham;
    private int soLuong;
    private double donGia;
    private String trangThai;
    private Date ngayLap;
    private Date ngayMua;
    private String username;

    // Constructors
    public LichSu1() {
    }

    public LichSu1(String maDonHang, String tenSanPham, int soLuong, double donGia, String trangThai, Date ngayMua, String username) {
        this.maDonHang = maDonHang;
        this.tenSanPham = tenSanPham;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.trangThai = trangThai;
        this.ngayMua = ngayMua;
        this.username = username;
    }

    // Getters and Setters
    public int getMaDH() {
        return maDH;
    }

    public void setMaDH(int maDH) {
        this.maDH = maDH;
    }

    public String getMaDonHang() {
        return maDonHang;
    }

    public void setMaDonHang(String maDonHang) {
        this.maDonHang = maDonHang;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
        this.tenSP = tenSanPham; // Đồng bộ với field cũ
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public Date getNgayLap() {
        return ngayLap;
    }

    public void setNgayLap(Date ngayLap) {
        this.ngayLap = ngayLap;
    }

    public Date getNgayMua() {
        return ngayMua;
    }

    public void setNgayMua(Date ngayMua) {
        this.ngayMua = ngayMua;
        this.ngayLap = ngayMua; // Đồng bộ với field cũ
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String toString() {
        return "LichSu1{" +
                "maDH=" + maDH +
                ", maDonHang='" + maDonHang + '\'' +
                ", tenSanPham='" + tenSanPham + '\'' +
                ", soLuong=" + soLuong +
                ", donGia=" + donGia +
                ", trangThai='" + trangThai + '\'' +
                ", ngayMua=" + ngayMua +
                ", username='" + username + '\'' +
                '}';
    }
}
