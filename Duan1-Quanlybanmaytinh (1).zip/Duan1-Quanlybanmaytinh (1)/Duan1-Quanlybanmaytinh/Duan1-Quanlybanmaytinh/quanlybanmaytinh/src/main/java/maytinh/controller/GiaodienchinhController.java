package maytinh.controller;

import javax.swing.JDialog;
import javax.swing.JFrame;
import maytinh.ui.AdminLienHeJDialog;
import maytinh.ui.Doimatkhau;
import maytinh.ui.GioHangJDialog;
import maytinh.ui.LichSuMuaHangJDialog;
import maytinh.ui.Lichsudanhgia;
import maytinh.ui.LienHeJDialog;
import maytinh.ui.Manchay;
import maytinh.ui.QuanLyDonHangJDialog;
import maytinh.ui.Quanlykho;
import maytinh.ui.Quanlysanpham;
import maytinh.ui.Thongtincanhan;
import maytinh.ui.Thongtinsanpham;
import maytinh.ui.dangNhap;
import maytinh.ui.doanhthu;
import maytinh.ui.quanlydanhgia;
import maytinh.ui.quanlykhachhang;

import maytinh.ui.ThanhToanJDialog;
import maytinh.util.XDialog;

/**
 *
 * @author 84327
 */
public interface GiaodienchinhController {


    default void exit() {
        if (XDialog.confirm("Bạn muốn kết thúc?")) {
            System.exit(0);
        }
    }

    default void showJDialog(JDialog dialog) {
        dialog.setLocationRelativeTo(null);
        dialog.setVisible(true);
    }

    default void showWelcomeJDialog(JFrame frame) {
        this.showJDialog(new Manchay(frame, true));
    }

    default void showDangNhapJDialog(JFrame frame) {
        this.showJDialog(new dangNhap(frame, true));
    }

    default void showQuanLyKhachHangJDialog(java.awt.Frame parent) {
        this.showJDialog(new quanlykhachhang(parent, true));
    }

    default void showQuanlysanphamJDialog(java.awt.Frame parent) {
        this.showJDialog(new Quanlysanpham(parent, true));
    }

    default void showQuanlykhoJDialog(java.awt.Frame parent) {
        this.showJDialog(new Quanlykho(parent, true));
    }



    default void showquanlybanhangJDialog(java.awt.Frame parent) {
        this.showJDialog(new QuanLyDonHangJDialog(parent, true));
    }

    default void showdoanhthuJDialog(java.awt.Frame parent) {
        this.showJDialog(new doanhthu(parent, true));
    }

    default void showquanlydanhgiaJDialog(java.awt.Frame parent) {
        this.showJDialog(new quanlydanhgia(parent, true));
    }

    default void showDoimatkhauJDialog(java.awt.Frame parent) {
        this.showJDialog(new Doimatkhau(parent, true));
    }

    default void showThongtincanhanJDialog(java.awt.Frame parent) {
        this.showJDialog(new Thongtincanhan(parent, true));
    }

    default void showThongtinsanphamJDialog(java.awt.Frame parent) {
        this.showJDialog(new Thongtinsanpham(parent, true));
    }

    default void showgiohangJDialog(java.awt.Frame parent) {
        this.showJDialog(new GioHangJDialog(parent, true));
    }

    default void showthanhtoanJDialog(java.awt.Frame parent) {
        this.showJDialog(new ThanhToanJDialog(parent, true));
    }

    default void showLichsuJDialog(java.awt.Frame parent) {
        this.showJDialog(new LichSuMuaHangJDialog(parent, true));
    }



    default void showLienHeJDialog(java.awt.Frame parent) {
        this.showJDialog(new LienHeJDialog(parent, true));
    }

    default void showAdminLienHeJDialog(java.awt.Frame parent) {
        this.showJDialog(new AdminLienHeJDialog(parent, true));
    }

    default void showLichSuDanhGiaJDialog(java.awt.Frame parent) {
        this.showJDialog(new Lichsudanhgia(parent, true));
    }

}
