/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package maytinh.ui;

import maytinh.dao.UserDAO;
import maytinh.entity.User;
import maytinh.impl.UserDAOImpl;
import maytinh.util.XAuth;
import maytinh.util.XDialog;
import javax.swing.JOptionPane;

/**
 * Màn hình đổi mật khẩu
 * @author phuc
 */
public class Doimatkhau extends javax.swing.JDialog {

    private UserDAO userDAO;

    /**
     * Creates new form doimk
     */
    public Doimatkhau(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        this.userDAO = new UserDAOImpl();
        initComponents();
        customizeComponents();
    }

    /**
     * Tùy chỉnh giao diện sau khi khởi tạo
     */
    private void customizeComponents() {
        this.setTitle("Đổi Mật Khẩu");
        this.setLocationRelativeTo(null);

        // Kiểm tra đăng nhập
        if (XAuth.user == null) {
            XDialog.alert("Bạn cần đăng nhập để sử dụng tính năng này!");
            this.dispose();
            return;
        }

        // Hiển thị thông tin người dùng hiện tại
        if (jTextField1 != null) {
            jTextField1.setText(XAuth.user.getUsername());
            jTextField1.setEditable(false); // Không cho phép sửa username
            jTextField1.setBackground(new java.awt.Color(240, 240, 240)); // Màu xám nhạt
        }

        // Thêm placeholder text
        if (jTextField4 != null) {
            jTextField4.setToolTipText("Nhập mật khẩu hiện tại của bạn");
            jTextField4.requestFocus();
        }

        if (jTextField2 != null) {
            jTextField2.setToolTipText("Mật khẩu mới (6-30 ký tự)");
        }

        if (jTextField3 != null) {
            jTextField3.setToolTipText("Nhập lại mật khẩu mới để xác nhận");
        }

        // Cải thiện giao diện nút
        if (jButton1 != null) {
            jButton1.setBackground(new java.awt.Color(0, 123, 255));
            jButton1.setForeground(java.awt.Color.WHITE);
            jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12));
        }

        if (jButton2 != null) {
            jButton2.setBackground(new java.awt.Color(108, 117, 125));
            jButton2.setForeground(java.awt.Color.WHITE);
            jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12));
        }
    }

    /**
     * Xử lý đổi mật khẩu
     */
    private void doiMatKhau() {
        try {
            // Lấy dữ liệu từ form
            String username = jTextField1.getText().trim();
            String matKhauCu = jTextField4.getText().trim();
            String matKhauMoi = jTextField2.getText().trim();
            String xacNhanMatKhau = jTextField3.getText().trim();

            // Validate dữ liệu đầu vào
            if (!validateInput(username, matKhauCu, matKhauMoi, xacNhanMatKhau)) {
                return;
            }

            // Kiểm tra mật khẩu cũ
            if (!kiemTraMatKhauCu(username, matKhauCu)) {
                XDialog.alert("Mật khẩu cũ không đúng!");
                jTextField4.requestFocus();
                jTextField4.selectAll();
                return;
            }

            // Cập nhật mật khẩu mới
            User user = XAuth.user;
            user.setPassword(matKhauMoi);
            userDAO.update(user);

            // Cập nhật lại thông tin trong XAuth
            XAuth.user = user;

            XDialog.alert("Đổi mật khẩu thành công!");
            System.out.println("✅ Đổi mật khẩu thành công cho user: " + username);

            // Clear form
            clearForm();

            // Đóng dialog
            this.dispose();

        } catch (Exception e) {
            System.out.println("❌ Lỗi đổi mật khẩu: " + e.getMessage());
            e.printStackTrace();
            XDialog.alert("Có lỗi xảy ra khi đổi mật khẩu: " + e.getMessage());
        }
    }

    /**
     * Validate dữ liệu đầu vào
     */
    private boolean validateInput(String username, String matKhauCu, String matKhauMoi, String xacNhanMatKhau) {
        // Kiểm tra các trường không được để trống
        if (username.isEmpty()) {
            XDialog.alert("Username không được để trống!");
            return false;
        }

        if (matKhauCu.isEmpty()) {
            XDialog.alert("Vui lòng nhập mật khẩu cũ!");
            jTextField4.requestFocus();
            return false;
        }

        if (matKhauMoi.isEmpty()) {
            XDialog.alert("Vui lòng nhập mật khẩu mới!");
            jTextField2.requestFocus();
            return false;
        }

        if (xacNhanMatKhau.isEmpty()) {
            XDialog.alert("Vui lòng xác nhận mật khẩu mới!");
            jTextField3.requestFocus();
            return false;
        }

        // Kiểm tra độ dài mật khẩu mới
        if (matKhauMoi.length() < 6) {
            XDialog.alert("Mật khẩu mới phải có ít nhất 6 ký tự!");
            jTextField2.requestFocus();
            jTextField2.selectAll();
            return false;
        }

        if (matKhauMoi.length() > 30) {
            XDialog.alert("Mật khẩu mới không được quá 30 ký tự!");
            jTextField2.requestFocus();
            jTextField2.selectAll();
            return false;
        }

        // Kiểm tra mật khẩu mới và xác nhận có khớp không
        if (!matKhauMoi.equals(xacNhanMatKhau)) {
            XDialog.alert("Mật khẩu mới và xác nhận mật khẩu không khớp!");
            jTextField3.requestFocus();
            jTextField3.selectAll();
            return false;
        }

        // Kiểm tra mật khẩu mới không được giống mật khẩu cũ
        if (matKhauMoi.equals(matKhauCu)) {
            XDialog.alert("Mật khẩu mới phải khác mật khẩu cũ!");
            jTextField2.requestFocus();
            jTextField2.selectAll();
            return false;
        }

        return true;
    }

    /**
     * Kiểm tra mật khẩu cũ có đúng không
     */
    private boolean kiemTraMatKhauCu(String username, String matKhauCu) {
        try {
            User user = userDAO.findByUsernameAndPassword(username, matKhauCu);
            return user != null;
        } catch (Exception e) {
            System.out.println("❌ Lỗi kiểm tra mật khẩu cũ: " + e.getMessage());
            return false;
        }
    }

    /**
     * Xóa dữ liệu trong form
     */
    private void clearForm() {
        if (jTextField4 != null) jTextField4.setText(""); // Mật khẩu cũ
        if (jTextField2 != null) jTextField2.setText(""); // Mật khẩu mới
        if (jTextField3 != null) jTextField3.setText(""); // Xác nhận mật khẩu

        // Đặt focus về trường mật khẩu cũ
        if (jTextField4 != null) {
            jTextField4.requestFocus();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextField4 = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("ĐỔI MậT KHẨU");

        jLabel2.setText("Username:");

        jLabel3.setText("Mật khẩu mới:");

        jLabel4.setText("Xác nhận mật khẩu:");

        jButton1.setBackground(new java.awt.Color(0, 123, 255));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Đặt lại mật khẩu");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setBackground(new java.awt.Color(108, 117, 125));
        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(255, 255, 255));
        jButton2.setText("Hủy");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jTextField1.setBackground(new java.awt.Color(240, 240, 240));
        jTextField1.setEditable(false);
        jTextField1.setToolTipText("Tên đăng nhập hiện tại");

        jTextField2.setToolTipText("Mật khẩu mới (6-30 ký tự)");

        jTextField3.setToolTipText("Nhập lại mật khẩu mới để xác nhận");
        jTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField3ActionPerformed(evt);
            }
        });

        jLabel5.setText("Mật khẩu cũ:");

        jTextField4.setToolTipText("Nhập mật khẩu hiện tại của bạn");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(194, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(41, 41, 41)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18))
            .addGroup(layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jTextField4, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jTextField2, javax.swing.GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
                        .addComponent(jTextField3)
                        .addComponent(jTextField1)))
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(162, 162, 162)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2))
                .addContainerGap(52, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        doiMatKhau();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        // Đóng dialog
        this.dispose();
    }

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // Khi nhấn Enter ở trường xác nhận mật khẩu, thực hiện đổi mật khẩu
        doiMatKhau();
    }//GEN-LAST:event_jTextField3ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Doimatkhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Doimatkhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Doimatkhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Doimatkhau.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Doimatkhau dialog = new Doimatkhau(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    // End of variables declaration//GEN-END:variables
}
