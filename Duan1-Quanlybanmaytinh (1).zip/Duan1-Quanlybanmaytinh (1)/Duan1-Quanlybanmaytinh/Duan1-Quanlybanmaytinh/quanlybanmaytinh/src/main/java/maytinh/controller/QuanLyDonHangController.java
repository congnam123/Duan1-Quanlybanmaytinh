/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package maytinh.controller;

/**
 *
 * @author PC
 */
public interface QuanLyDonHangController {
    void open();
    void timKiem();
    void fillToTable();
    void capNhatTrangThai();
    void xoaDonHang();
    void locTheoTrangThai();
}
