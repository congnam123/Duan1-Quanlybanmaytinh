package maytinh.controller;

import maytinh.dao.NhapKhoDAO;
import maytinh.dao.XuatKhoDAO;
import maytinh.dao.KhoDAO;
import maytinh.dao.TonKhoDAO;
import maytinh.entity.NhapKho;
import maytinh.entity.XuatKho;
import maytinh.entity.Kho;
import maytinh.entity.SanPham;
import maytinh.entity.TonKho;
import maytinh.impl.NhapKhoDAOImpl;
import maytinh.impl.XuatKhoDAOImpl;
import maytinh.impl.KhoDAOImpl;
import maytinh.impl.TonKhoDAOImpl;
import maytinh.util.XDialog;
import maytinh.util.XAuth;
import maytinh.util.XJdbc;
import java.util.List;
import java.util.Date;
import java.math.BigDecimal;

/**
 * Controller cho Nhập/Xuất Kho
 * @author Cong Nam
 */
public class NhapXuatKhoController {
    
    private NhapKhoDAO nhapKhoDAO;
    private XuatKhoDAO xuatKhoDAO;
    private KhoDAO khoDAO;
    private TonKhoDAO tonKhoDAO;
    
    public NhapXuatKhoController() {
        this.nhapKhoDAO = new NhapKhoDAOImpl();
        this.xuatKhoDAO = new XuatKhoDAOImpl();
        this.khoDAO = new KhoDAOImpl();
        this.tonKhoDAO = new TonKhoDAOImpl();
    }
    
    // ==================== NHẬP KHO ====================
    
    /**
     * Lấy tất cả phiếu nhập kho
     */
    public List<NhapKho> getAllNhapKho() {
        try {
            return nhapKhoDAO.findAll();
        } catch (Exception e) {
            XDialog.alert("Lỗi khi lấy danh sách phiếu nhập: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Thêm phiếu nhập kho mới
     */
    public boolean addNhapKho(NhapKho nhapKho) {
        try {
            // Kiểm tra mã phiếu nhập đã tồn tại chưa
            if (nhapKhoDAO.existsByMaPhieuNhap(nhapKho.getMaPhieuNhap())) {
                XDialog.alert("Mã phiếu nhập đã tồn tại!");
                return false;
            }
            
            // Validate dữ liệu
            if (!validateNhapKho(nhapKho)) {
                return false;
            }
            
            // Lấy thông tin sản phẩm
            SanPham sanPham = getSanPhamById(nhapKho.getMaSanPham());
            if (sanPham != null) {
                nhapKho.setTenSanPham(sanPham.getTenSP());
            }
            
            // Tính thành tiền
            nhapKho.setThanhTien(nhapKho.getDonGiaNhap().multiply(new BigDecimal(nhapKho.getSoLuongNhap())));
            nhapKho.setNguoiNhap(XAuth.user != null ? XAuth.user.getFullname() : "Admin");
            nhapKho.setNgayNhap(new Date());
            
            nhapKhoDAO.create(nhapKho);
            
            // Cập nhật tồn kho nếu trạng thái là "Đã nhập"
            if ("Đã nhập".equals(nhapKho.getTrangThai())) {
                updateTonKhoSauNhap(nhapKho);
                // 🔗 Đồng bộ với bảng SanPham
                updateTonKhoSanPham(nhapKho.getMaSanPham());
                // 🔗 Cập nhật thông tin kho (TongSanPham, TongGiaTri)
                updateThongTinKho(nhapKho.getMaKho());
            }
            
            XDialog.alert("Thêm phiếu nhập thành công!");
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi thêm phiếu nhập: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Cập nhật phiếu nhập kho
     */
    public boolean updateNhapKho(NhapKho nhapKho) {
        try {
            if (!validateNhapKho(nhapKho)) {
                return false;
            }
            
            // Lấy phiếu nhập cũ để so sánh
            NhapKho nhapKhoCu = nhapKhoDAO.findById(nhapKho.getMaPhieuNhap());
            
            // Tính lại thành tiền
            nhapKho.setThanhTien(nhapKho.getDonGiaNhap().multiply(new BigDecimal(nhapKho.getSoLuongNhap())));
            
            nhapKhoDAO.update(nhapKho);
            
            // Cập nhật tồn kho nếu có thay đổi trạng thái
            if (nhapKhoCu != null && !nhapKhoCu.getTrangThai().equals(nhapKho.getTrangThai())) {
                if ("Đã nhập".equals(nhapKho.getTrangThai())) {
                    updateTonKhoSauNhap(nhapKho);
                } else if ("Đã nhập".equals(nhapKhoCu.getTrangThai())) {
                    // Trừ lại số lượng đã nhập trước đó
                    updateTonKhoSauXuat(nhapKhoCu.getMaSanPham(), nhapKhoCu.getSoLuongNhap());
                }
            }
            
            XDialog.alert("Cập nhật phiếu nhập thành công!");
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi cập nhật phiếu nhập: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Xóa phiếu nhập kho
     */
    public boolean deleteNhapKho(String maPhieuNhap) {
        try {
            if (XDialog.confirm("Bạn có chắc chắn muốn xóa phiếu nhập này?")) {
                NhapKho nhapKho = nhapKhoDAO.findById(maPhieuNhap);
                if (nhapKho != null && "Đã nhập".equals(nhapKho.getTrangThai())) {
                    // Trừ lại số lượng tồn kho
                    updateTonKhoSauXuat(nhapKho.getMaSanPham(), nhapKho.getSoLuongNhap());
                }
                
                nhapKhoDAO.deleteById(maPhieuNhap);
                XDialog.alert("Xóa phiếu nhập thành công!");
                return true;
            }
            return false;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi xóa phiếu nhập: " + e.getMessage());
            return false;
        }
    }
    
    // ==================== XUẤT KHO ====================
    
    /**
     * Lấy tất cả phiếu xuất kho
     */
    public List<XuatKho> getAllXuatKho() {
        try {
            return xuatKhoDAO.findAll();
        } catch (Exception e) {
            XDialog.alert("Lỗi khi lấy danh sách phiếu xuất: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Thêm phiếu xuất kho mới
     */
    public boolean addXuatKho(XuatKho xuatKho) {
        try {
            // Kiểm tra mã phiếu xuất đã tồn tại chưa
            if (xuatKhoDAO.existsByMaPhieuXuat(xuatKho.getMaPhieuXuat())) {
                XDialog.alert("Mã phiếu xuất đã tồn tại!");
                return false;
            }
            
            // Validate dữ liệu
            if (!validateXuatKho(xuatKho)) {
                return false;
            }
            
            // Kiểm tra tồn kho
            if (!checkTonKho(xuatKho.getMaSanPham(), xuatKho.getSoLuongXuat())) {
                XDialog.alert("Không đủ hàng trong kho để xuất!");
                return false;
            }
            
            // Lấy thông tin sản phẩm
            SanPham sanPham = getSanPhamById(xuatKho.getMaSanPham());
            if (sanPham != null) {
                xuatKho.setTenSanPham(sanPham.getTenSP());
            }
            
            // Tính thành tiền
            xuatKho.setThanhTien(xuatKho.getDonGiaXuat().multiply(new BigDecimal(xuatKho.getSoLuongXuat())));
            xuatKho.setNguoiXuat(XAuth.user != null ? XAuth.user.getFullname() : "Admin");
            xuatKho.setNgayXuat(new Date());
            
            xuatKhoDAO.create(xuatKho);
            
            // Cập nhật tồn kho nếu trạng thái là "Đã xuất"
            if ("Đã xuất".equals(xuatKho.getTrangThai())) {
                updateTonKhoSauXuat(xuatKho.getMaSanPham(), xuatKho.getSoLuongXuat());
                // 🔗 Đồng bộ với bảng SanPham
                updateTonKhoSanPham(xuatKho.getMaSanPham());
                // 🔗 Cập nhật thông tin kho (TongSanPham, TongGiaTri)
                updateThongTinKho(xuatKho.getMaKho());
            }
            
            XDialog.alert("Thêm phiếu xuất thành công!");
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi thêm phiếu xuất: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Tìm kiếm phiếu nhập
     */
    public List<NhapKho> searchNhapKho(String keyword) {
        try {
            if (keyword == null || keyword.trim().isEmpty()) {
                return getAllNhapKho();
            }
            return nhapKhoDAO.search(keyword.trim());
        } catch (Exception e) {
            XDialog.alert("Lỗi khi tìm kiếm phiếu nhập: " + e.getMessage());
            return null;
        }
    }
    
    /**
     * Cập nhật phiếu xuất kho
     */
    public boolean updateXuatKho(XuatKho xuatKho) {
        try {
            if (!validateXuatKho(xuatKho)) {
                return false;
            }

            // Tính thành tiền
            xuatKho.setThanhTien(xuatKho.getDonGiaXuat().multiply(new BigDecimal(xuatKho.getSoLuongXuat())));
            xuatKho.setNgayCapNhat(new Date());

            xuatKhoDAO.update(xuatKho);
            XDialog.alert("Cập nhật phiếu xuất thành công!");
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi cập nhật phiếu xuất: " + e.getMessage());
            return false;
        }
    }

    /**
     * Xóa phiếu xuất kho
     */
    public boolean deleteXuatKho(String maPhieuXuat) {
        try {
            if (maPhieuXuat == null || maPhieuXuat.trim().isEmpty()) {
                XDialog.alert("Mã phiếu xuất không hợp lệ!");
                return false;
            }

            xuatKhoDAO.deleteById(maPhieuXuat);
            XDialog.alert("Xóa phiếu xuất thành công!");
            return true;
        } catch (Exception e) {
            XDialog.alert("Lỗi khi xóa phiếu xuất: " + e.getMessage());
            return false;
        }
    }

    /**
     * Tìm kiếm phiếu xuất
     */
    public List<XuatKho> searchXuatKho(String keyword) {
        try {
            if (keyword == null || keyword.trim().isEmpty()) {
                return getAllXuatKho();
            }
            return xuatKhoDAO.search(keyword.trim());
        } catch (Exception e) {
            XDialog.alert("Lỗi khi tìm kiếm phiếu xuất: " + e.getMessage());
            return null;
        }
    }

    /**
     * Lấy số lượng tồn kho của sản phẩm trong kho
     */
    public int getTonKho(String maKho, String maSanPham) {
        try {
            String sql = "SELECT ISNULL(SoLuongTon, 0) AS TonKho FROM TonKho WHERE MaKho = ? AND MaSanPham = ?";
            java.sql.ResultSet rs = XJdbc.executeQuery(sql, maKho, maSanPham);
            if (rs.next()) {
                return rs.getInt("TonKho");
            }
            return 0;
        } catch (Exception e) {
            System.err.println("Lỗi lấy tồn kho: " + e.getMessage());
            return 0;
        }
    }

    /**
     * Lấy tất cả dữ liệu tồn kho
     */
    public List<TonKho> getAllTonKho() {
        try {
            return tonKhoDAO.findAll();
        } catch (Exception e) {
            XDialog.alert("Lỗi khi lấy dữ liệu tồn kho: " + e.getMessage());
            return null;
        }
    }

    // ==================== LIÊN KẾT VỚI QUẢN LÝ SẢN PHẨM ====================

    /**
     * Đồng bộ tồn kho từ bảng TonKho sang bảng SanPham và cập nhật thông tin kho
     */
    public void syncTonKhoToSanPham() {
        try {
            // 1. Đồng bộ tồn kho từ TonKho sang SanPham
            String sqlSanPham = """
                UPDATE SanPham
                SET SoLuongTon = (
                    SELECT ISNULL(SUM(SoLuongTon), 0)
                    FROM TonKho
                    WHERE CAST(TonKho.MaSanPham AS INT) = SanPham.MaSP
                )
                WHERE EXISTS (
                    SELECT 1 FROM TonKho
                    WHERE CAST(TonKho.MaSanPham AS INT) = SanPham.MaSP
                )
                """;
            XJdbc.executeUpdate(sqlSanPham);
            System.out.println("✅ Đồng bộ tồn kho từ TonKho sang SanPham thành công!");

            // 2. Cập nhật thông tin tổng hợp cho tất cả kho
            String sqlKho = """
                UPDATE Kho
                SET TongSanPham = (
                    SELECT ISNULL(SUM(SoLuongTon), 0)
                    FROM TonKho
                    WHERE TonKho.MaKho = Kho.MaKho
                ),
                TongGiaTri = (
                    SELECT ISNULL(SUM(GiaTriTon), 0)
                    FROM TonKho
                    WHERE TonKho.MaKho = Kho.MaKho
                )
                """;
            XJdbc.executeUpdate(sqlKho);
            System.out.println("✅ Đồng bộ thông tin kho (TongSanPham, TongGiaTri) thành công!");
        } catch (Exception e) {
            System.err.println("❌ Lỗi đồng bộ tồn kho: " + e.getMessage());
        }
    }

    /**
     * Lấy tổng tồn kho của sản phẩm từ tất cả kho
     */
    public int getTongTonKhoSanPham(String maSanPham) {
        try {
            String sql = "SELECT ISNULL(SUM(SoLuongTon), 0) AS TongTon FROM TonKho WHERE MaSanPham = ?";
            java.sql.ResultSet rs = XJdbc.executeQuery(sql, maSanPham);
            if (rs.next()) {
                return rs.getInt("TongTon");
            }
            return 0;
        } catch (Exception e) {
            System.err.println("Lỗi lấy tổng tồn kho: " + e.getMessage());
            return 0;
        }
    }

    /**
     * Cập nhật tồn kho sản phẩm sau khi nhập/xuất
     */
    public void updateTonKhoSanPham(String maSanPham) {
        try {
            int tongTon = getTongTonKhoSanPham(maSanPham);
            String sql = "UPDATE SanPham SET SoLuongTon = ? WHERE MaSP = CAST(? AS INT)";
            XJdbc.executeUpdate(sql, tongTon, maSanPham);
            System.out.println("✅ Cập nhật tồn kho sản phẩm " + maSanPham + ": " + tongTon);
        } catch (Exception e) {
            System.err.println("❌ Lỗi cập nhật tồn kho sản phẩm: " + e.getMessage());
        }
    }

    /**
     * Cập nhật thông tin tổng hợp của kho (TongSanPham, TongGiaTri)
     */
    public void updateThongTinKho(String maKho) {
        try {
            // Tính tổng số lượng sản phẩm trong kho
            String sqlTongSP = "SELECT ISNULL(SUM(SoLuongTon), 0) FROM TonKho WHERE MaKho = ?";
            java.sql.ResultSet rs1 = XJdbc.executeQuery(sqlTongSP, maKho);
            int tongSanPham = 0;
            if (rs1.next()) {
                tongSanPham = rs1.getInt(1);
            }

            // Tính tổng giá trị hàng hóa trong kho
            String sqlTongGT = "SELECT ISNULL(SUM(GiaTriTon), 0) FROM TonKho WHERE MaKho = ?";
            java.sql.ResultSet rs2 = XJdbc.executeQuery(sqlTongGT, maKho);
            double tongGiaTri = 0.0;
            if (rs2.next()) {
                tongGiaTri = rs2.getDouble(1);
            }

            // Cập nhật bảng Kho
            khoDAO.updateTongSanPham(maKho, tongSanPham);
            khoDAO.updateTongGiaTri(maKho, tongGiaTri);

            System.out.println("✅ Cập nhật thông tin kho " + maKho + ": " + tongSanPham + " SP, " + String.format("%.0f", tongGiaTri) + " VNĐ");
        } catch (Exception e) {
            System.err.println("❌ Lỗi cập nhật thông tin kho: " + e.getMessage());
        }
    }

    /**
     * Lấy danh sách sản phẩm từ bảng SanPham để hiển thị trong ComboBox
     */
    public List<SanPham> getAllSanPhamForKho() {
        try {
            String sql = "SELECT MaSP, TenSP, Gia, SoLuongTon FROM SanPham ORDER BY TenSP";
            java.sql.ResultSet rs = XJdbc.executeQuery(sql);
            List<SanPham> list = new java.util.ArrayList<>();

            while (rs.next()) {
                SanPham sp = new SanPham();
                sp.setMaSP(rs.getInt("MaSP"));
                sp.setTenSP(rs.getString("TenSP"));
                sp.setGia(rs.getDouble("Gia"));
                sp.setSoLuong(rs.getInt("SoLuongTon"));
                list.add(sp);
            }
            return list;
        } catch (Exception e) {
            System.err.println("Lỗi lấy danh sách sản phẩm: " + e.getMessage());
            return new java.util.ArrayList<>();
        }
    }

    /**
     * Cập nhật hoặc tạo mới bản ghi TonKho
     */
    private void updateOrCreateTonKho(String maKho, String maSanPham, String tenSanPham,
                                     int soLuongNhap, int soLuongXuat, BigDecimal donGia) {
        try {
            // Kiểm tra xem đã có bản ghi TonKho chưa
            TonKho tonKho = tonKhoDAO.findByKhoAndSanPham(maKho, maSanPham);

            if (tonKho != null) {
                // Cập nhật bản ghi có sẵn
                tonKho.setSoLuongTon(tonKho.getSoLuongTon() + soLuongNhap - soLuongXuat);
                tonKho.setSoLuongNhap(tonKho.getSoLuongNhap() + soLuongNhap);
                tonKho.setSoLuongXuat(tonKho.getSoLuongXuat() + soLuongXuat);
                tonKho.setGiaTriTon(new BigDecimal(tonKho.getSoLuongTon()).multiply(tonKho.getDonGiaTrungBinh()));
                tonKho.setNgayCapNhat(new Date());
                tonKho.setTrangThai(tonKho.getSoLuongTon() > 0 ? "Còn hàng" : "Hết hàng");

                tonKhoDAO.update(tonKho);
                System.out.println("✅ Cập nhật TonKho: " + maKho + "-" + maSanPham);
            } else {
                // Tạo mới bản ghi TonKho
                tonKho = new TonKho();
                tonKho.setMaKho(maKho);
                tonKho.setMaSanPham(maSanPham);
                tonKho.setTenSanPham(tenSanPham);
                tonKho.setSoLuongTon(soLuongNhap - soLuongXuat);
                tonKho.setSoLuongNhap(soLuongNhap);
                tonKho.setSoLuongXuat(soLuongXuat);
                tonKho.setDonGiaTrungBinh(donGia);
                tonKho.setGiaTriTon(new BigDecimal(tonKho.getSoLuongTon()).multiply(donGia));
                tonKho.setNgayCapNhat(new Date());
                tonKho.setTrangThai(tonKho.getSoLuongTon() > 0 ? "Còn hàng" : "Hết hàng");

                tonKhoDAO.create(tonKho);
                System.out.println("✅ Tạo mới TonKho: " + maKho + "-" + maSanPham);
            }
        } catch (Exception e) {
            System.err.println("❌ Lỗi cập nhật/tạo TonKho: " + e.getMessage());
        }
    }

    // ==================== HELPER METHODS ====================
    
    /**
     * Validate dữ liệu nhập kho
     */
    private boolean validateNhapKho(NhapKho nhapKho) {
        if (nhapKho.getMaPhieuNhap() == null || nhapKho.getMaPhieuNhap().trim().isEmpty()) {
            XDialog.alert("Mã phiếu nhập không được để trống!");
            return false;
        }
        
        if (nhapKho.getMaKho() == null || nhapKho.getMaKho().trim().isEmpty()) {
            XDialog.alert("Mã kho không được để trống!");
            return false;
        }
        
        if (nhapKho.getMaSanPham() == null || nhapKho.getMaSanPham().trim().isEmpty()) {
            XDialog.alert("Mã sản phẩm không được để trống!");
            return false;
        }
        
        if (nhapKho.getSoLuongNhap() <= 0) {
            XDialog.alert("Số lượng nhập phải lớn hơn 0!");
            return false;
        }
        
        if (nhapKho.getDonGiaNhap() == null || nhapKho.getDonGiaNhap().compareTo(BigDecimal.ZERO) <= 0) {
            XDialog.alert("Đơn giá nhập phải lớn hơn 0!");
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate dữ liệu xuất kho
     */
    private boolean validateXuatKho(XuatKho xuatKho) {
        if (xuatKho.getMaPhieuXuat() == null || xuatKho.getMaPhieuXuat().trim().isEmpty()) {
            XDialog.alert("Mã phiếu xuất không được để trống!");
            return false;
        }
        
        if (xuatKho.getMaKho() == null || xuatKho.getMaKho().trim().isEmpty()) {
            XDialog.alert("Mã kho không được để trống!");
            return false;
        }
        
        if (xuatKho.getMaSanPham() == null || xuatKho.getMaSanPham().trim().isEmpty()) {
            XDialog.alert("Mã sản phẩm không được để trống!");
            return false;
        }
        
        if (xuatKho.getSoLuongXuat() <= 0) {
            XDialog.alert("Số lượng xuất phải lớn hơn 0!");
            return false;
        }
        
        if (xuatKho.getDonGiaXuat() == null || xuatKho.getDonGiaXuat().compareTo(BigDecimal.ZERO) <= 0) {
            XDialog.alert("Đơn giá xuất phải lớn hơn 0!");
            return false;
        }
        
        return true;
    }
    
    /**
     * Lấy thông tin sản phẩm theo mã
     */
    private SanPham getSanPhamById(String maSanPham) {
        try {
            String sql = "SELECT * FROM SanPham WHERE MaSP = ?";
            return maytinh.util.XQuery.getSingleBean(SanPham.class, sql, maSanPham);
        } catch (Exception e) {
            return null;
        }
    }
    
    /**
     * Kiểm tra tồn kho
     */
    private boolean checkTonKho(String maSanPham, int soLuongXuat) {
        try {
            String sql = "SELECT SoLuongTon FROM SanPham WHERE MaSP = ?";
            java.sql.ResultSet rs = XJdbc.executeQuery(sql, maSanPham);
            if (rs.next()) {
                int tonKho = rs.getInt("SoLuongTon");
                return tonKho >= soLuongXuat;
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }
    
    /**
     * Cập nhật tồn kho sau khi nhập
     */
    private void updateTonKhoSauNhap(NhapKho nhapKho) {
        try {
            // 1. Cập nhật hoặc tạo mới TonKho
            updateOrCreateTonKho(nhapKho.getMaKho(), nhapKho.getMaSanPham(),
                               nhapKho.getTenSanPham(), nhapKho.getSoLuongNhap(),
                               0, nhapKho.getDonGiaNhap());

            // 2. Cập nhật SanPham (để tương thích với code cũ)
            String sql = "UPDATE SanPham SET SoLuongTon = SoLuongTon + ? WHERE MaSP = CAST(? AS INT)";
            XJdbc.executeUpdate(sql, nhapKho.getSoLuongNhap(), nhapKho.getMaSanPham());

            System.out.println("✅ Đã cập nhật tồn kho sau nhập: " + nhapKho.getMaSanPham() + " (+"+nhapKho.getSoLuongNhap()+")");
        } catch (Exception e) {
            System.err.println("❌ Lỗi cập nhật tồn kho sau nhập: " + e.getMessage());
        }
    }
    
    /**
     * Cập nhật tồn kho sau khi xuất
     */
    private void updateTonKhoSauXuat(String maSanPham, int soLuongXuat) {
        try {
            // 1. Cập nhật TonKho (trừ số lượng xuất)
            String updateTonKhoSql = """
                UPDATE TonKho
                SET SoLuongTon = SoLuongTon - ?,
                    SoLuongXuat = SoLuongXuat + ?,
                    GiaTriTon = (SoLuongTon - ?) * DonGiaTrungBinh,
                    NgayCapNhat = GETDATE(),
                    TrangThai = CASE WHEN SoLuongTon - ? > 0 THEN N'Còn hàng' ELSE N'Hết hàng' END
                WHERE MaSanPham = ? AND SoLuongTon >= ?
                """;
            XJdbc.executeUpdate(updateTonKhoSql, soLuongXuat, soLuongXuat, soLuongXuat, soLuongXuat, maSanPham, soLuongXuat);

            // 2. Cập nhật SanPham (để tương thích với code cũ)
            String sql = "UPDATE SanPham SET SoLuongTon = SoLuongTon - ? WHERE MaSP = CAST(? AS INT)";
            XJdbc.executeUpdate(sql, soLuongXuat, maSanPham);

            System.out.println("✅ Đã cập nhật tồn kho sau xuất: " + maSanPham + " (-"+soLuongXuat+")");
        } catch (Exception e) {
            System.err.println("❌ Lỗi cập nhật tồn kho sau xuất: " + e.getMessage());
        }
    }
    
    /**
     * Tạo mã phiếu nhập tự động
     */
    public String generateMaPhieuNhap() {
        try {
            long count = nhapKhoDAO.count();
            return String.format("PN%06d", count + 1);
        } catch (Exception e) {
            return "PN000001";
        }
    }
    
    /**
     * Tạo mã phiếu xuất tự động
     */
    public String generateMaPhieuXuat() {
        try {
            long count = xuatKhoDAO.count();
            return String.format("PX%06d", count + 1);
        } catch (Exception e) {
            return "PX000001";
        }
    }
    
    /**
     * Lấy danh sách kho hoạt động
     */
    public List<Kho> getActiveKho() {
        try {
            return khoDAO.findActiveKho();
        } catch (Exception e) {
            return null;
        }
    }
}
