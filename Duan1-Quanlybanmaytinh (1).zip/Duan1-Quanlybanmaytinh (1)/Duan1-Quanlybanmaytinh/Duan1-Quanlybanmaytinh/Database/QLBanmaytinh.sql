-- =====================================================
-- ✅ DATABASE HOÀN CHỈNH CHO HỆ THỐNG QUẢN LÝ BÁN MÁY TÍNH
-- Bao gồm: Chat 2 chiều, Hình ảnh sản phẩm, Giỏ hàng, Lịch sử, Laptops
-- =====================================================

-- XÓA VÀ TẠO LẠI DATABASE
USE master;
DROP DATABASE IF EXISTS QLBanmaytinh;
GO
CREATE DATABASE QLBanmaytinh;
GO
USE QLBanmaytinh;
GO

-- ===============================================
-- TẠO CÁC BẢNG
-- ===============================================

-- BẢNG NGƯỜI DÙNG
CREATE TABLE Users (
    Username NVARCHAR(20) NOT NULL PRIMARY KEY,
    Password NVARCHAR(50) NOT NULL,
    Enabled BIT NOT NULL,
    Manager BIT NOT NULL,
    Fullname NVARCHAR(50) NOT NULL,
    NgaySinh DATE,
    DiaChi NVARCHAR(100),
    SoDienThoai NVARCHAR(15),
    Email NVARCHAR(100),
    PhanLoai NVARCHAR(50),
    Photo NVARCHAR(50) NOT NULL,
    PhanLoaiTaiKhoan NVARCHAR(50)
);



-- BẢNG LOẠI SẢN PHẨM (✅ NÂNG CẤP: Thêm cột TrangThai và MoTa)
CREATE TABLE LoaiSanPham (
    MaLoai INT PRIMARY KEY IDENTITY,
    TenLoai NVARCHAR(50) NOT NULL,
    MoTa NVARCHAR(255) NULL,
    TrangThai BIT DEFAULT 1 NOT NULL -- ✅ Cột trạng thái cho soft delete
);

-- BẢNG SẢN PHẨM (có thêm cột HinhAnh)
CREATE TABLE SanPham (
    MaSP INT PRIMARY KEY IDENTITY,
    TenSP NVARCHAR(100) NOT NULL,
    MoTa NVARCHAR(255),
    Gia DECIMAL(18, 2) NOT NULL,
    SoLuongTon INT NOT NULL,
    NgayThem DATETIME DEFAULT GETDATE(),
    MaLoai INT,
    HinhAnh NVARCHAR(255), -- ✅ Cột hình ảnh
    FOREIGN KEY (MaLoai) REFERENCES LoaiSanPham(MaLoai)
);

-- BẢNG GIỎ HÀNG
CREATE TABLE GioHang (
    MaGioHang INT PRIMARY KEY IDENTITY,
    Username NVARCHAR(20),
    MaSP INT,
    SoLuong INT NOT NULL,
    NgayThem DATETIME DEFAULT GETDATE(),
    TrangThai BIT DEFAULT 1,
    FOREIGN KEY (Username) REFERENCES Users(Username),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);

-- BẢNG LỊCH SỬ MUA HÀNG
CREATE TABLE LichSu (
    MaDH INT PRIMARY KEY IDENTITY,
    MaDonHang NVARCHAR(50),
    Username NVARCHAR(20),
    TenSanPham NVARCHAR(255),
    SoLuong INT,
    DonGia DECIMAL(18,2),
    TrangThai NVARCHAR(50),
    NgayMua DATETIME DEFAULT GETDATE(),
    FOREIGN KEY (Username) REFERENCES Users(Username)
);

-- BẢNG ĐƠN HÀNG
CREATE TABLE DonHang (
    MaDH INT PRIMARY KEY IDENTITY,
    Username NVARCHAR(20),
    NgayLap DATETIME DEFAULT GETDATE(),
    TongTien DECIMAL(18,2),
    PhuongThucThanhToan NVARCHAR(50),
    TrangThai NVARCHAR(50),
    FOREIGN KEY (Username) REFERENCES Users(Username)
);

-- BẢNG CHI TIẾT ĐƠN HÀNG
CREATE TABLE ChiTietDonHang (
    MaCTDH INT PRIMARY KEY IDENTITY,
    MaDH INT,
    MaSP INT,
    SoLuong INT,
    DonGia DECIMAL(18,2),
    FOREIGN KEY (MaDH) REFERENCES DonHang(MaDH),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);

-- BẢNG ĐÁNH GIÁ
CREATE TABLE DanhGia (
    MaDG INT PRIMARY KEY IDENTITY,
    Username NVARCHAR(20),
    MaSP INT,
    NoiDung NVARCHAR(255),
    Diem INT CHECK (Diem BETWEEN 1 AND 5),
    NgayDanhGia DATETIME DEFAULT GETDATE(),
    TraLoi NVARCHAR(255),
    FOREIGN KEY (Username) REFERENCES Users(Username),
    FOREIGN KEY (MaSP) REFERENCES SanPham(MaSP)
);

-- ✅ BẢNG LIÊN HỆ (HỖ TRỢ CHAT 2 CHIỀU)
CREATE TABLE LienHe (
    ID INT PRIMARY KEY IDENTITY,
    Username NVARCHAR(20),
    NoiDung NVARCHAR(MAX),
    ThoiGian DATETIME DEFAULT GETDATE(),
    AdminReply NVARCHAR(MAX) NULL,
    AdminReplyTime DATETIME NULL,
    Status NVARCHAR(20) DEFAULT 'pending' NOT NULL,
    FOREIGN KEY (Username) REFERENCES Users(Username),
    CONSTRAINT CK_LienHe_Status CHECK (Status IN ('pending', 'replied', 'closed'))
);

-- Tạo index để tăng hiệu suất
CREATE INDEX IX_LienHe_Status ON LienHe(Status);
CREATE INDEX IX_LienHe_Username ON LienHe(Username);
CREATE INDEX IX_LienHe_ThoiGian ON LienHe(ThoiGian DESC);

-- ===============================================
-- BẢNG QUẢN LÝ KHO - CẬP NHẬT HOÀN CHỈNH
-- ===============================================

-- XÓA CÁC BẢNG CŨ NẾU TỒN TẠI (THEO THỨ TỰ ĐỂ TRÁNH LỖI FOREIGN KEY)
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'TonKho')
    DROP TABLE TonKho;
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'XuatKho')
    DROP TABLE XuatKho;
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'NhapKho')
    DROP TABLE NhapKho;
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Kho')
    DROP TABLE Kho;

-- BẢNG KHO
CREATE TABLE Kho (
    MaKho NVARCHAR(20) PRIMARY KEY,
    TenKho NVARCHAR(100) NOT NULL,
    DiaChi NVARCHAR(255) NOT NULL,
    NguoiQuanLy NVARCHAR(100) NOT NULL,
    SoDienThoai NVARCHAR(15),
    Email NVARCHAR(100),
    MoTa NVARCHAR(500),
    NgayTao DATETIME DEFAULT GETDATE(),
    NgayCapNhat DATETIME DEFAULT GETDATE(),
    TrangThai BIT DEFAULT 1, -- 1: Hoạt động, 0: Ngừng hoạt động
    TongSanPham INT DEFAULT 0,
    TongGiaTri DECIMAL(18,2) DEFAULT 0
);

-- BẢNG NHẬP KHO
CREATE TABLE NhapKho (
    MaPhieuNhap NVARCHAR(20) PRIMARY KEY,
    MaKho NVARCHAR(20) NOT NULL,
    MaSanPham NVARCHAR(10) NOT NULL, -- Đổi thành NVARCHAR để khớp với entity
    TenSanPham NVARCHAR(100),
    SoLuongNhap INT NOT NULL,
    DonGiaNhap DECIMAL(18,2) NOT NULL,
    ThanhTien DECIMAL(18,2) NOT NULL,
    NhaCungCap NVARCHAR(100),
    NguoiNhap NVARCHAR(100),
    NgayNhap DATETIME DEFAULT GETDATE(),
    GhiChu NVARCHAR(500),
    TrangThai NVARCHAR(20) DEFAULT N'Chờ xử lý', -- 'Đã nhập', 'Chờ xử lý', 'Hủy'
    NgayTao DATETIME DEFAULT GETDATE(),
    NgayCapNhat DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (MaKho) REFERENCES Kho(MaKho),
    -- Tạm thời bỏ foreign key với SanPham để tránh lỗi
    -- FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSP),
    CONSTRAINT CK_NhapKho_SoLuong CHECK (SoLuongNhap > 0),
    CONSTRAINT CK_NhapKho_DonGia CHECK (DonGiaNhap > 0)
);

-- BẢNG XUẤT KHO
CREATE TABLE XuatKho (
    MaPhieuXuat NVARCHAR(20) PRIMARY KEY,
    MaKho NVARCHAR(20) NOT NULL,
    MaSanPham NVARCHAR(10) NOT NULL, -- Đổi thành NVARCHAR để khớp với entity
    TenSanPham NVARCHAR(100),
    SoLuongXuat INT NOT NULL,
    DonGiaXuat DECIMAL(18,2) NOT NULL,
    ThanhTien DECIMAL(18,2) NOT NULL,
    KhachHang NVARCHAR(100),
    NguoiXuat NVARCHAR(100),
    NgayXuat DATETIME DEFAULT GETDATE(),
    LyDoXuat NVARCHAR(50) DEFAULT N'Bán hàng', -- 'Bán hàng', 'Chuyển kho', 'Hủy hàng', 'Khác'
    GhiChu NVARCHAR(500),
    TrangThai NVARCHAR(20) DEFAULT N'Chờ xử lý', -- 'Đã xuất', 'Chờ xử lý', 'Hủy'
    NgayTao DATETIME DEFAULT GETDATE(),
    NgayCapNhat DATETIME DEFAULT GETDATE(),

    FOREIGN KEY (MaKho) REFERENCES Kho(MaKho),
    -- Tạm thời bỏ foreign key với SanPham để tránh lỗi
    -- FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSP),
    CONSTRAINT CK_XuatKho_SoLuong CHECK (SoLuongXuat > 0),
    CONSTRAINT CK_XuatKho_DonGia CHECK (DonGiaXuat > 0)
);

-- BẢNG TỒN KHO
CREATE TABLE TonKho (
    MaKho NVARCHAR(20) NOT NULL,
    MaSanPham NVARCHAR(10) NOT NULL, -- Đổi thành NVARCHAR để khớp với entity
    TenSanPham NVARCHAR(100),
    SoLuongTon INT DEFAULT 0,
    SoLuongNhap INT DEFAULT 0,
    SoLuongXuat INT DEFAULT 0,
    GiaTriTon DECIMAL(18,2) DEFAULT 0,
    DonGiaTrungBinh DECIMAL(18,2) DEFAULT 0,
    NgayCapNhat DATETIME DEFAULT GETDATE(),
    TrangThai NVARCHAR(20) DEFAULT N'Hết hàng', -- 'Còn hàng', 'Hết hàng', 'Sắp hết'

    PRIMARY KEY (MaKho, MaSanPham),
    FOREIGN KEY (MaKho) REFERENCES Kho(MaKho),
    -- Tạm thời bỏ foreign key với SanPham để tránh lỗi
    -- FOREIGN KEY (MaSanPham) REFERENCES SanPham(MaSP),
    CONSTRAINT CK_TonKho_SoLuong CHECK (SoLuongTon >= 0)
);

-- Tạo các index để tối ưu hiệu suất cho bảng kho
CREATE NONCLUSTERED INDEX IX_NhapKho_MaKho ON NhapKho(MaKho);
CREATE NONCLUSTERED INDEX IX_NhapKho_MaSanPham ON NhapKho(MaSanPham);
CREATE NONCLUSTERED INDEX IX_NhapKho_NgayNhap ON NhapKho(NgayNhap);
CREATE NONCLUSTERED INDEX IX_NhapKho_TrangThai ON NhapKho(TrangThai);

CREATE NONCLUSTERED INDEX IX_XuatKho_MaKho ON XuatKho(MaKho);
CREATE NONCLUSTERED INDEX IX_XuatKho_MaSanPham ON XuatKho(MaSanPham);
CREATE NONCLUSTERED INDEX IX_XuatKho_NgayXuat ON XuatKho(NgayXuat);
CREATE NONCLUSTERED INDEX IX_XuatKho_TrangThai ON XuatKho(TrangThai);

CREATE NONCLUSTERED INDEX IX_Kho_TrangThai ON Kho(TrangThai);
CREATE NONCLUSTERED INDEX IX_TonKho_MaKho ON TonKho(MaKho);
CREATE NONCLUSTERED INDEX IX_TonKho_MaSanPham ON TonKho(MaSanPham);
CREATE NONCLUSTERED INDEX IX_TonKho_TrangThai ON TonKho(TrangThai);
CREATE NONCLUSTERED INDEX IX_TonKho_SoLuongTon ON TonKho(SoLuongTon);

-- ===============================================
-- DỮ LIỆU MẪU
-- ===============================================

-- DỮ LIỆU NGƯỜI DÙNG
INSERT INTO Users (Username, Password, Enabled, Manager, Fullname, NgaySinh, DiaChi, SoDienThoai, Email, PhanLoai, Photo, PhanLoaiTaiKhoan)
VALUES
('admin', 'admin123', 1, 1, N'Nguyễn Văn A', '1995-05-20', N'123 Lê Lợi, TP.HCM', '0912345678', 'admin@gmail.com', N'Thường', 'admin.jpg', N'Admin'),
('user1', '123456', 1, 0, N'Trần Thị B', '1998-08-15', N'45 Nguyễn Trãi, Hà Nội', '0909123456', 'user1@gmail.com', N'Vip', 'user1.jpg', N'Khách hàng'),
('user2', '654321', 1, 0, N'Lê Văn C', '2000-12-01', N'99 Pasteur, Đà Nẵng', '0987654321', 'user2@gmail.com', N'Thường', 'user2.jpg', N'Khách hàng'),
('khach1', 'abc123', 1, 0, N'Nguyễn Khách 1', '1990-01-01', N'Hà Nội', '0900000001', 'khach1@gmail.com', N'Vip', 'khach1.jpg', N'Khách hàng'),
('khach2', 'xyz789', 1, 0, N'Lê Khách 2', '1992-02-02', N'Sài Gòn', '0900000002', 'khach2@gmail.com', N'Vip', 'khach2.jpg', N'Khách hàng');



-- DỮ LIỆU LOẠI SẢN PHẨM (✅ NÂNG CẤP: Thêm MoTa và TrangThai)
INSERT INTO LoaiSanPham (TenLoai, MoTa, TrangThai)
VALUES
(N'Văn phòng', N'Laptop phù hợp cho công việc văn phòng, học tập', 1),
(N'Gaming', N'Laptop chuyên dụng cho game thủ với cấu hình mạnh', 1),
(N'Đồ họa', N'Laptop chuyên dụng cho thiết kế đồ họa, render', 1),
(N'Giá rẻ', N'Laptop phổ thông với giá cả hợp lý', 1);

-- DỮ LIỆU SẢN PHẨM (có hình ảnh)
INSERT INTO SanPham (TenSP, MoTa, Gia, SoLuongTon, MaLoai, HinhAnh)
VALUES
(N'Máy tính Dell OptiPlex 7090', N'Intel Core i5, 8GB RAM, 256GB SSD', 13500000, 12, 1, 'lap1.jpg'),
(N'Máy tính HP ProDesk 400 G7', N'Intel Core i7, 16GB RAM, 512GB SSD', 18500000, 8, 2, 'lap2.jpg'),
(N'Máy tính ASUS ExpertCenter D5', N'Ryzen 5, 8GB RAM, 256GB SSD', 12500000, 15, 1, 'lab3.png'),
(N'Máy tính Lenovo ThinkCentre M720s', N'Intel Core i5, 8GB RAM, 1TB HDD', 14500000, 10, 3, 'lab4.jpg'),
(N'Máy tính Acer Veriton X', N'Intel Core i3, 4GB RAM, 500GB HDD', 9500000, 20, 4, 'lab5.png'),
(N'Máy tính MSI Gaming Desktop', N'Intel Core i7, 32GB RAM, RTX 3070', 35000000, 5, 2, 'lab6.jpg'),
(N'Máy tính Apple iMac 24"', N'Apple M1 Chip, 8GB RAM, 256GB SSD', 32000000, 6, 3, 'lab7.png'),
(N'Máy tính HP Pavilion Desktop', N'AMD Ryzen 7, 16GB RAM, 512GB SSD', 16500000, 12, 1, 'lab8.png');

-- DỮ LIỆU ĐƠN HÀNG
INSERT INTO DonHang (Username, NgayLap, TongTien, PhuongThucThanhToan, TrangThai)
VALUES
('khach1', '2025-07-19', 14000000, N'Tiền mặt', N'Đã thanh toán'),
('khach2', '2025-07-20', 18500000, N'Chuyển khoản', N'Đang xử lý'),
('user1', '2025-07-19', 14000000, N'Tiền mặt', N'Đã thanh toán'),
('user2', '2025-07-20', 18500000, N'Chuyển khoản', N'Đang xử lý');

-- DỮ LIỆU CHI TIẾT ĐƠN HÀNG
INSERT INTO ChiTietDonHang (MaDH, MaSP, SoLuong, DonGia)
VALUES
(1, 1, 1, 13500000),
(1, 5, 1, 500000),
(2, 2, 1, 18500000),
(3, 3, 1, 14000000),
(4, 4, 1, 18500000);

-- DỮ LIỆU GIỎ HÀNG
INSERT INTO GioHang (Username, MaSP, SoLuong) VALUES
('user1', 1, 2),
('user1', 3, 1),
('user2', 2, 1);

-- DỮ LIỆU LỊCH SỬ
INSERT INTO LichSu (MaDonHang, Username, TenSanPham, SoLuong, DonGia, TrangThai) VALUES
('DH001', 'user1', N'Máy tính Dell OptiPlex 7090', 1, 13500000, N'Đã giao thành công'),
('DH002', 'user2', N'Máy tính HP ProDesk 400 G7', 1, 18500000, N'Đang giao hàng'),
('DH003', 'user1', N'Máy tính ASUS ExpertCenter D5', 2, 12500000, N'Đã thanh toán');

-- DỮ LIỆU ĐÁNH GIÁ
-- ⚠️ KHÔNG THÊM DỮ LIỆU TEST VÀO ĐÂY!
-- Dữ liệu đánh giá sẽ được tạo khi khách hàng thực sự đánh giá sản phẩm
-- Nếu thêm dữ liệu test, khách hàng sẽ không thể đánh giá được (báo "đã đánh giá")

-- INSERT INTO DanhGia (Username, MaSP, NoiDung, Diem)
-- VALUES
-- ('khach1', 1, N'Sản phẩm tốt, chạy mượt', 5),
-- ('khach2', 2, N'Đóng gói cẩn thận, hiệu năng ổn', 4),
-- ('user1', 1, N'Ổn nhưng hơi nóng máy', 3),        -- ← VẤN ĐỀ: user1 không thể đánh giá Dell OptiPlex
-- ('user2', 2, N'Sản phẩm chưa đúng mô tả', 2);

-- 🔧 FIX: Để bảng DanhGia trống ban đầu
-- Khách hàng sẽ tự đánh giá qua giao diện ứng dụng

-- DỮ LIỆU KHO
INSERT INTO Kho (MaKho, TenKho, DiaChi, NguoiQuanLy, SoDienThoai, Email, MoTa, TrangThai)
VALUES
    ('KHO001', N'Kho Chính', N'123 Đường ABC, Quận 1, TP.HCM', N'Nguyễn Văn A', '0901234567', 'khochinh@company.com', N'Kho chính lưu trữ laptop và phụ kiện', 1),
    ('KHO002', N'Kho Phụ', N'456 Đường XYZ, Quận 2, TP.HCM', N'Trần Thị B', '0907654321', 'khophu@company.com', N'Kho phụ lưu trữ hàng dự phòng', 1),
    ('KHO003', N'Kho Hà Nội', N'789 Đường DEF, Cầu Giấy, Hà Nội', N'Lê Văn C', '0912345678', 'khohanoi@company.com', N'Kho chi nhánh Hà Nội', 1);

-- DỮ LIỆU NHẬP KHO MẪU
INSERT INTO NhapKho (MaPhieuNhap, MaKho, MaSanPham, TenSanPham, SoLuongNhap, DonGiaNhap, ThanhTien, NhaCungCap, NguoiNhap, NgayNhap, TrangThai)
VALUES
    ('PN000001', 'KHO001', '1', N'Máy tính Dell OptiPlex 7090', 5, 12000000, 60000000, N'Dell Vietnam', N'Nguyễn Văn A', '2025-08-01', N'Đã nhập'),
    ('PN000002', 'KHO001', '2', N'Máy tính HP ProDesk 400 G7', 3, 17000000, 51000000, N'HP Vietnam', N'Nguyễn Văn A', '2025-08-02', N'Đã nhập'),
    ('PN000003', 'KHO002', '3', N'Máy tính ASUS ExpertCenter D5', 4, 11500000, 46000000, N'ASUS Vietnam', N'Trần Thị B', '2025-08-03', N'Đã nhập');

-- DỮ LIỆU XUẤT KHO MẪU
INSERT INTO XuatKho (MaPhieuXuat, MaKho, MaSanPham, TenSanPham, SoLuongXuat, DonGiaXuat, ThanhTien, KhachHang, NguoiXuat, NgayXuat, LyDoXuat, TrangThai)
VALUES
    ('PX000001', 'KHO001', '1', N'Máy tính Dell OptiPlex 7090', 2, 13500000, 27000000, N'Công ty ABC', N'Nguyễn Văn A', '2025-08-04', N'Bán hàng', N'Đã xuất'),
    ('PX000002', 'KHO001', '2', N'Máy tính HP ProDesk 400 G7', 1, 18500000, 18500000, N'Khách lẻ', N'Nguyễn Văn A', '2025-08-04', N'Bán hàng', N'Đã xuất');

-- ===============================================
-- TÍNH TOÁN VÀ TẠO DỮ LIỆU TỒN KHO CHÍNH XÁC
-- ===============================================

-- Xóa dữ liệu TonKho cũ nếu có
DELETE FROM TonKho;

-- Tạo TonKho từ dữ liệu nhập/xuất thực tế
INSERT INTO TonKho (MaKho, MaSanPham, TenSanPham, SoLuongTon, SoLuongNhap, SoLuongXuat, GiaTriTon, DonGiaTrungBinh, TrangThai)
SELECT
    k.MaKho,
    CAST(sp.MaSP AS NVARCHAR(10)) AS MaSanPham,
    sp.TenSP AS TenSanPham,
    -- Tồn kho = Nhập - Xuất theo từng kho
    ISNULL(SUM(CASE WHEN nk.TrangThai = N'Đã nhập' THEN nk.SoLuongNhap ELSE 0 END), 0) -
    ISNULL(SUM(CASE WHEN xk.TrangThai = N'Đã xuất' THEN xk.SoLuongXuat ELSE 0 END), 0) AS SoLuongTon,
    -- Tổng nhập theo kho
    ISNULL(SUM(CASE WHEN nk.TrangThai = N'Đã nhập' THEN nk.SoLuongNhap ELSE 0 END), 0) AS SoLuongNhap,
    -- Tổng xuất theo kho
    ISNULL(SUM(CASE WHEN xk.TrangThai = N'Đã xuất' THEN xk.SoLuongXuat ELSE 0 END), 0) AS SoLuongXuat,
    -- Giá trị tồn
    (ISNULL(SUM(CASE WHEN nk.TrangThai = N'Đã nhập' THEN nk.SoLuongNhap ELSE 0 END), 0) -
     ISNULL(SUM(CASE WHEN xk.TrangThai = N'Đã xuất' THEN xk.SoLuongXuat ELSE 0 END), 0)) * sp.Gia AS GiaTriTon,
    -- Đơn giá trung bình
    sp.Gia AS DonGiaTrungBinh,
    -- Trạng thái
    CASE
        WHEN (ISNULL(SUM(CASE WHEN nk.TrangThai = N'Đã nhập' THEN nk.SoLuongNhap ELSE 0 END), 0) -
              ISNULL(SUM(CASE WHEN xk.TrangThai = N'Đã xuất' THEN xk.SoLuongXuat ELSE 0 END), 0)) > 0
        THEN N'Còn hàng'
        ELSE N'Hết hàng'
    END AS TrangThai
FROM SanPham sp
CROSS JOIN Kho k
LEFT JOIN NhapKho nk ON CAST(nk.MaSanPham AS INT) = sp.MaSP AND nk.MaKho = k.MaKho
LEFT JOIN XuatKho xk ON CAST(xk.MaSanPham AS INT) = sp.MaSP AND xk.MaKho = k.MaKho
GROUP BY k.MaKho, sp.MaSP, sp.TenSP, sp.Gia
HAVING (ISNULL(SUM(CASE WHEN nk.TrangThai = N'Đã nhập' THEN nk.SoLuongNhap ELSE 0 END), 0) -
        ISNULL(SUM(CASE WHEN xk.TrangThai = N'Đã xuất' THEN xk.SoLuongXuat ELSE 0 END), 0)) >= 0;

-- ✅ DỮ LIỆU LIÊN HỆ (DEMO CHAT 2 CHIỀU)
INSERT INTO LienHe (Username, NoiDung, ThoiGian, AdminReply, AdminReplyTime, Status)
VALUES
-- Liên hệ đã được trả lời
('khach1', N'Cho mình hỏi về chế độ bảo hành của máy tính Dell OptiPlex 7090?', '2025-07-28 09:30:00',
 N'Chào bạn! Máy tính Dell OptiPlex 7090 có chế độ bảo hành 12 tháng chính hãng. Bảo hành bao gồm lỗi phần cứng và phần mềm. Bạn có thể mang máy đến các trung tâm bảo hành Dell hoặc liên hệ hotline để được hỗ trợ.',
 '2025-07-28 10:15:00', 'replied'),

-- Liên hệ chưa được trả lời
('user1', N'Mình muốn hỏi về việc nâng cấp RAM cho máy tính. Hiện tại máy có 8GB, có thể nâng lên 16GB được không?', '2025-07-29 14:20:00', NULL, NULL, 'pending'),

('khach2', N'Sản phẩm HP ProDesk 400 G7 có hỗ trợ card đồ họa rời không? Mình cần dùng cho thiết kế.', '2025-07-29 16:45:00', NULL, NULL, 'pending'),

-- Liên hệ đã đóng
('user2', N'Mình đặt hàng từ hôm qua nhưng chưa nhận được xác nhận. Cho mình hỏi tình trạng đơn hàng.', '2025-07-27 11:00:00',
 N'Chào bạn! Đơn hàng của bạn đã được xác nhận và đang trong quá trình chuẩn bị hàng. Dự kiến giao hàng trong 2-3 ngày làm việc. Cảm ơn bạn đã tin tưởng sản phẩm của chúng tôi.',
 '2025-07-27 11:30:00', 'closed'),

-- Thêm một số liên hệ khác
('khach1', N'Có chương trình khuyến mãi nào cho khách hàng VIP không?', '2025-07-30 08:00:00', NULL, NULL, 'pending'),

('user1', N'Cảm ơn shop đã tư vấn nhiệt tình. Sản phẩm rất tốt!', '2025-07-29 20:30:00',
 N'Cảm ơn bạn đã phản hồi tích cực! Chúng tôi rất vui khi sản phẩm làm bạn hài lòng. Chúc bạn sử dụng máy hiệu quả!',
 '2025-07-30 09:00:00', 'replied');

-- ===============================================
-- KIỂM TRA DỮ LIỆU
-- ===============================================

PRINT '=== KIỂM TRA DỮ LIỆU ===';

SELECT 'Users' AS TableName, COUNT(*) AS RecordCount FROM Users
UNION ALL
SELECT 'LoaiSanPham', COUNT(*) FROM LoaiSanPham
UNION ALL
SELECT 'SanPham', COUNT(*) FROM SanPham
UNION ALL
SELECT 'DonHang', COUNT(*) FROM DonHang
UNION ALL
SELECT 'ChiTietDonHang', COUNT(*) FROM ChiTietDonHang
UNION ALL
SELECT 'GioHang', COUNT(*) FROM GioHang
UNION ALL
SELECT 'LichSu', COUNT(*) FROM LichSu
UNION ALL
SELECT 'DanhGia', COUNT(*) FROM DanhGia
UNION ALL
SELECT 'LienHe', COUNT(*) FROM LienHe
UNION ALL
SELECT 'Kho', COUNT(*) FROM Kho
UNION ALL
SELECT 'NhapKho', COUNT(*) FROM NhapKho
UNION ALL
SELECT 'XuatKho', COUNT(*) FROM XuatKho
UNION ALL
SELECT 'TonKho', COUNT(*) FROM TonKho;

PRINT '=== CHI TIẾT BẢNG LIÊN HỆ ===';
SELECT
    ID,
    Username,
    LEFT(NoiDung, 50) + '...' AS NoiDung_Short,
    ThoiGian,
    CASE
        WHEN AdminReply IS NOT NULL THEN LEFT(AdminReply, 30) + '...'
        ELSE NULL
    END AS AdminReply_Short,
    AdminReplyTime,
    Status
FROM LienHe
ORDER BY ThoiGian DESC;

PRINT '=== THỐNG KÊ LIÊN HỆ THEO TRẠNG THÁI ===';
SELECT
    Status,
    COUNT(*) AS SoLuong,
    CAST(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM LienHe) AS DECIMAL(5,2)) AS PhanTram
FROM LienHe
GROUP BY Status
ORDER BY SoLuong DESC;

PRINT '=== DANH SÁCH SẢN PHẨM VỚI HÌNH ẢNH ===';
SELECT
    sp.MaSP,
    sp.TenSP,
    FORMAT(sp.Gia, 'N0') + ' VND' as Gia,
    sp.SoLuongTon,
    lsp.TenLoai,
    sp.HinhAnh
FROM SanPham sp
LEFT JOIN LoaiSanPham lsp ON sp.MaLoai = lsp.MaLoai
ORDER BY sp.MaSP;



-- ===============================================
-- KIỂM TRA VÀ XÁC NHẬN DATABASE
-- ===============================================

-- Kiểm tra các bảng kho đã được tạo
PRINT '=== KIỂM TRA CÁC BẢNG KHO ===';
IF EXISTS (SELECT * FROM sys.tables WHERE name = 'Kho')
    PRINT '✅ Bảng Kho: OK'
ELSE
    PRINT '❌ Bảng Kho: THIẾU';

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'NhapKho')
    PRINT '✅ Bảng NhapKho: OK'
ELSE
    PRINT '❌ Bảng NhapKho: THIẾU';

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'XuatKho')
    PRINT '✅ Bảng XuatKho: OK'
ELSE
    PRINT '❌ Bảng XuatKho: THIẾU';

IF EXISTS (SELECT * FROM sys.tables WHERE name = 'TonKho')
    PRINT '✅ Bảng TonKho: OK'
ELSE
    PRINT '❌ Bảng TonKho: THIẾU';

-- Kiểm tra cột TongGiaTri trong bảng Kho
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'Kho' AND COLUMN_NAME = 'TongGiaTri')
    PRINT '✅ Cột TongGiaTri trong Kho: OK'
ELSE
    PRINT '❌ Cột TongGiaTri trong Kho: THIẾU';

-- Kiểm tra cột MaSanPham trong bảng NhapKho
IF EXISTS (SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'NhapKho' AND COLUMN_NAME = 'MaSanPham')
    PRINT '✅ Cột MaSanPham trong NhapKho: OK'
ELSE
    PRINT '❌ Cột MaSanPham trong NhapKho: THIẾU';

PRINT '=== DATABASE ĐÃ SẴN SÀNG CHO HỆ THỐNG QUẢN LÝ BÁN MÁY TÍNH! ===';
PRINT 'Bao gồm:';
PRINT '✅ Bảng Users - Quản lý người dùng';
PRINT '✅ Bảng SanPham - Quản lý sản phẩm (8 sản phẩm mẫu)';
PRINT '✅ Bảng LoaiSanPham - Phân loại sản phẩm';
PRINT '✅ Bảng DonHang, ChiTietDonHang - Quản lý đơn hàng';
PRINT '✅ Bảng GioHang - Giỏ hàng';
PRINT '✅ Bảng LichSu - Lịch sử mua hàng';
PRINT '✅ Bảng DanhGia - Đánh giá sản phẩm';
PRINT '✅ Bảng LienHe - Chat 2 chiều';
PRINT '✅ Bảng Kho - Quản lý kho (3 kho mẫu)';
PRINT '✅ Bảng NhapKho - Phiếu nhập kho (3 phiếu mẫu)';
PRINT '✅ Bảng XuatKho - Phiếu xuất kho (2 phiếu mẫu)';
PRINT '✅ Bảng TonKho - Tồn kho theo sản phẩm (3 sản phẩm mẫu)';

-- ===============================================
-- ĐỒNG BỘ DỮ LIỆU GIỮA SẢN PHẨM VÀ KHO
-- ===============================================

PRINT '';
PRINT '🔗 ĐỒNG BỘ DỮ LIỆU GIỮA SẢN PHẨM VÀ KHO...';

-- Cập nhật tồn kho trong bảng SanPham từ bảng TonKho
UPDATE SanPham
SET SoLuongTon = (
    SELECT ISNULL(SUM(SoLuongTon), 0)
    FROM TonKho
    WHERE CAST(TonKho.MaSanPham AS INT) = SanPham.MaSP
);

PRINT '✅ Đã đồng bộ tồn kho từ TonKho sang SanPham';

-- Cập nhật tổng giá trị và số lượng sản phẩm trong kho
UPDATE Kho
SET TongSanPham = (
    SELECT ISNULL(SUM(SoLuongTon), 0)
    FROM TonKho
    WHERE TonKho.MaKho = Kho.MaKho
),
TongGiaTri = (
    SELECT ISNULL(SUM(GiaTriTon), 0)
    FROM TonKho
    WHERE TonKho.MaKho = Kho.MaKho
);

PRINT '✅ Đã cập nhật tổng sản phẩm và giá trị trong kho';

-- Kiểm tra kết quả đồng bộ
PRINT '';
PRINT '📊 KIỂM TRA KẾT QUẢ ĐỒNG BỘ:';
PRINT '============================';

-- Kiểm tra tính nhất quán giữa SanPham và TonKho
SELECT
    sp.MaSP AS [Mã SP],
    sp.TenSP AS [Tên sản phẩm],
    sp.SoLuongTon AS [Tồn SanPham],
    ISNULL(SUM(tk.SoLuongTon), 0) AS [Tổng TonKho],
    CASE
        WHEN sp.SoLuongTon = ISNULL(SUM(tk.SoLuongTon), 0) THEN '✅ Đồng nhất'
        ELSE '❌ Chưa đồng nhất'
    END AS [Trạng thái]
FROM SanPham sp
LEFT JOIN TonKho tk ON CAST(tk.MaSanPham AS INT) = sp.MaSP
GROUP BY sp.MaSP, sp.TenSP, sp.SoLuongTon
ORDER BY sp.MaSP;

PRINT '';
PRINT '📦 CHI TIẾT TỒN KHO THEO KHO:';
PRINT '============================';
SELECT
    tk.MaKho AS [Kho],
    tk.MaSanPham AS [Mã SP],
    tk.TenSanPham AS [Tên sản phẩm],
    tk.SoLuongTon AS [Tồn],
    tk.SoLuongNhap AS [Nhập],
    tk.SoLuongXuat AS [Xuất],
    tk.TrangThai AS [Trạng thái]
FROM TonKho tk
WHERE tk.SoLuongTon > 0
ORDER BY tk.MaSanPham, tk.MaKho;

PRINT '';
PRINT '🏪 TỔNG QUAN KHO:';
PRINT '================';
SELECT
    k.MaKho AS [Mã kho],
    k.TenKho AS [Tên kho],
    k.TongSanPham AS [Tổng SP],
    FORMAT(k.TongGiaTri, 'N0') + ' VNĐ' AS [Tổng giá trị],
    k.NguoiQuanLy AS [Quản lý]
FROM Kho k
ORDER BY k.MaKho;

PRINT '';
PRINT '🎯 HƯỚNG DẪN SỬ DỤNG:';
PRINT '1. Chạy ứng dụng Java: mvn exec:java -Dexec.mainClass="maytinh.ui.Quanlykho"';
PRINT '2. Sử dụng 4 tab: Quản Lý Kho → Nhập Kho → Xuất Kho → Tồn Kho';
PRINT '3. ComboBox sản phẩm sẽ hiển thị: "Tên sản phẩm (Tồn: X)"';
PRINT '4. Nhấn nút "Đồng bộ" trong tab Tồn Kho để đồng bộ thủ công';
PRINT '5. Test nhập/xuất kho → Tồn kho tự động cập nhật';
PRINT '';
PRINT '🔗 LIÊN KẾT SẢN PHẨM - KHO ĐÃ HOÀN THÀNH!';
PRINT '🚀 HỆ THỐNG QUẢN LÝ KHO ĐÃ SẴN SÀNG!';
PRINT '';
PRINT 'Bạn có thể đăng nhập với:';
PRINT '- Admin: username=admin, password=admin123 (Manager=1)';
PRINT '- User: username=user1, password=123456 (Manager=0)';
PRINT '- Khách: username=khach1, password=abc123 (Manager=0)';
PRINT '';
PRINT '🚀 Chạy ứng dụng manhinhchinhkhachhang để xem sản phẩm!';
PRINT '🛒 Chạy ứng dụng quản lý để thêm/sửa/xóa sản phẩm!';
GO
